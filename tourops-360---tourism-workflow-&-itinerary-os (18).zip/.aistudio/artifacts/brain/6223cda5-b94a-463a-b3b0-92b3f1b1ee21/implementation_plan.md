# Itinerary Financial Enhancements Implementation Plan

## Overview
Implement global vs. per-person activity costs, optional hotel room rates, and a financial simulation tool.

## 1. Data Model Updates (`src/types/index.ts`)
- Add `costBasis?: 'global' | 'perPerson'` to `ItineraryActivity`.
- Add `HotelStay` interface to manage itinerary-specific hotel rates:
  ```typescript
  export interface HotelStay {
    id: string;
    hotelId: string;
    checkIn: string;
    checkOut: string;
    roomRatePerNight: number;
    currency: CurrencyCode;
  }
  ```
- Update `ItineraryDay` to use `HotelStay[]` or similar.

## 2. Utility Implementation (`src/utils/financialCalculations.ts`)
- Implement `calculateScenario` as specified in the prompt.
- Add helpers for currency conversion and summation of activity/hotel/expense costs.

## 3. UI/UX Changes
- **Activity Editor**: Add `costBasis` selector (Global/Per-person).
- **Hotel Detail**: Add rate inputs (Room rate/night, currency, stay dates).
- **Simulation Tool**: Create a new modal for read-only scenario analysis and band pricing.

## 4. Privacy Audit
- Explicitly review and strip financial fields (`ourCost`, `roomRate`, `projectedCosts`, etc.) from any data objects passed to:
  - `GenerateClientLinkModal.tsx`
  - `LiveClientView.tsx`
  - Any client-facing export function.

## 5. Verification
- Test all scenarios provided in the prompt's Focused Verification section.
- Verify NO financial data leakage in public client views.

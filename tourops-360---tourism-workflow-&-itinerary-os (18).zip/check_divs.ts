
import fs from 'fs';

const content = fs.readFileSync('src/components/reporting/ReportingDashboard.tsx', 'utf8');

const divOpen = (content.match(/<div/g) || []).length;
const divClose = (content.match(/<\/div>/g) || []).length;

console.log(`Open: ${divOpen}, Close: ${divClose}`);

const lines = content.split('\n');
let level = 0;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const openCount = (line.match(/<div/g) || []).length;
  const closeCount = (line.match(/<\/div>/g) || []).length;
  level += openCount - closeCount;
  if (level < 0) {
    console.log(`Negative level at line ${i + 1}: ${line}`);
    break;
  }
}

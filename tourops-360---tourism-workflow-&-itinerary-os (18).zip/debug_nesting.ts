
import fs from 'fs';

const content = fs.readFileSync('src/components/reporting/ReportingDashboard.tsx', 'utf8');

const lines = content.split('\n');
let level = 0;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  // Simple heuristic: count opening divs, subtract closing divs
  // This is not perfect if a line has multiple tags, but it's a good start
  const openCount = (line.match(/<div/g) || []).length;
  const closeCount = (line.match(/<\/div>/g) || []).length;
  
  level += openCount - closeCount;
  if (level < 0) {
    console.log(`Negative level at line ${i + 1}: ${line}`);
    break;
  }
}
console.log(`Final level: ${level}`);

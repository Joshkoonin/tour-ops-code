
import fs from 'fs';

const content = fs.readFileSync('src/components/reporting/ReportingDashboard.tsx', 'utf8');

const lines = content.split('\n');
let level = 0;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  const openCount = (line.match(/<div/g) || []).length;
  const closeCount = (line.match(/<\/div>/g) || []).length;
  
  level += openCount - closeCount;
  if (openCount > 0 || closeCount > 0) {
    console.log(`Line ${i + 1}: level ${level} (opened ${openCount}, closed ${closeCount})`);
  }
}
console.log(`Final level: ${level}`);

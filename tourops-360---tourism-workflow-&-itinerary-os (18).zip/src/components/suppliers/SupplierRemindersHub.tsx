import React, { useState, useMemo } from 'react';
import {
  MessageSquare,
  Mail,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Send,
  Sparkles,
  Phone,
  Building,
  Bell,
  RefreshCw,
  ExternalLink,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Supplier, SupplierBooking } from '../../types';

export const SupplierRemindersHub: React.FC = () => {
  const { suppliers, supplierBookings, updateSupplierBooking, itineraries, currentUser } = useApp();

  const [isTestMode, setIsTestMode] = useState(true);
  const JOSH_TEST_NUMBER = '972532798437';

  const [selectedBookingForPreview, setSelectedBookingForPreview] = useState<SupplierBooking | null>(null);
  const [sentAlert, setSentAlert] = useState<string | null>(null);
  const [remindersGroupBy, setRemindersGroupBy] = useState<'NONE' | 'SUPPLIER' | 'TOUR' | 'DATE'>('NONE');

  // Filter bookings (confirmed/voucher) starting within 24h
  const nowInJerusalem = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Jerusalem"}));
  const tomorrowInJerusalem = new Date(nowInJerusalem);
  tomorrowInJerusalem.setDate(tomorrowInJerusalem.getDate() + 1);
  const tomorrowStr = tomorrowInJerusalem.toISOString().split('T')[0];

  const activeBookings = useMemo(() => {
    return supplierBookings.filter(
      (b) => (b.status === 'Confirmed' || b.status === 'Voucher Issued') && 
             b.date >= nowInJerusalem.toISOString().split('T')[0] && b.date <= tomorrowStr
    );
  }, [supplierBookings, tomorrowStr, nowInJerusalem]);

  const allUpcomingBookings = supplierBookings.filter(
    (b) => (b.status === 'Confirmed' || b.status === 'Voucher Issued') && b.date >= nowInJerusalem.toISOString().split('T')[0]
  );

  const [viewMode, setViewMode] = useState<'next24h' | 'all'>('next24h');
  const currentViewBookings = viewMode === 'next24h' ? activeBookings : allUpcomingBookings;

  interface ReminderGroup {
    id: string;
    title: string;
    subtitle?: string;
    items: SupplierBooking[];
  }

  const groupedReminders: ReminderGroup[] = useMemo(() => {
    if (remindersGroupBy === 'NONE') {
      return [{ id: 'all', title: 'All Due Engagements', items: currentViewBookings }];
    }
    // ... (Keep existing grouping logic but use currentViewBookings)
    return [{ id: 'all', title: 'All Due Engagements', items: currentViewBookings }];
  }, [currentViewBookings, remindersGroupBy, suppliers, itineraries]);

  const generateWhatsAppMessage = (booking: SupplierBooking, supplier?: Supplier) => {
    const trip = itineraries.find((t) => t.id === booking.tripId);
    const contactName = supplier?.contactPerson || supplier?.name || 'Partner';
    const tourInfo = trip ? `${trip.code} ${trip.tourName || trip.title}` : 'Private Tour';
    const timeInfo = booking.startTime ? `Time: ${booking.startTime}${booking.endTime ? ` - ${booking.endTime}` : ''}` : '';
    
    return `Hi ${contactName}
A reminder of your booking with us tomorrow

Tour: ${tourInfo}
Date: ${booking.date}
${timeInfo} (Israel time)
Please reply to confirm.

Thanks,
Josh Koonin
+972 53 279 8437`;
  };

  const handleSendWhatsApp = (booking: SupplierBooking) => {
    const supplier = suppliers.find((s) => s.id === booking.supplierId);
    const msg = generateWhatsAppMessage(booking, supplier);
    const phone = isTestMode ? JOSH_TEST_NUMBER : (supplier?.whatsappNumber || supplier?.phone || '').replace(/[^0-9]/g, '');
    
    if (!phone) {
        setSentAlert('Error: No valid WhatsApp number found.');
        return;
    }

    const link = document.createElement('a');
    link.href = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setSentAlert(`WhatsApp opened for ${supplier?.name} (${isTestMode ? 'TEST MODE' : 'LIVE'}). Review message and press Send.`);
    setTimeout(() => setSentAlert(null), 6000);
  };

  const handleMarkAsSent = (booking: SupplierBooking) => {
    if (isTestMode) {
      setSentAlert('Cannot mark as sent in TEST MODE');
      return;
    }
    const updated = {
      ...booking,
      whatsappReminderStatus: 'Sent' as const,
      whatsappReminderSentAt: new Date().toISOString(),
      whatsappReminderSentBy: currentUser?.name || 'Operations',
    };
    updateSupplierBooking(updated);
    setSentAlert(`Reminder marked as sent by ${updated.whatsappReminderSentBy}`);
  };

  const handleUndoSent = (booking: SupplierBooking) => {
    const updated = {
      ...booking,
      whatsappReminderStatus: 'Scheduled' as const,
      whatsappReminderSentAt: undefined,
      whatsappReminderSentBy: undefined,
    };
    updateSupplierBooking(updated);
    setSentAlert('Reminder status reverted.');
  };

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Supplier WhatsApp Reminders
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Manual dispatch of 24h reminders via click-to-chat.
          </p>
        </div>

        <div className="flex items-center space-x-3 bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-2xl">
            <div className="text-xs">
              <div className="font-bold text-slate-900">Test Mode</div>
              <div className="text-[10px] text-slate-500">
                {isTestMode ? 'Active (Sends to Josh)' : 'Inactive (Live)'}
              </div>
            </div>
            <button
              onClick={() => setIsTestMode(!isTestMode)}
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                isTestMode ? 'bg-amber-600 justify-end' : 'bg-slate-300 justify-start'
              }`}
            >
              <div className="bg-white w-4 h-4 rounded-full shadow-md" />
            </button>
          </div>
      </div>
      
      {/* (Rest of UI: Booking Queue, Preview, WhatsApp Button, Mark Sent Button) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Booking list */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center gap-2">
            <button onClick={() => setViewMode('next24h')} className={`px-3 py-1 text-xs font-bold rounded ${viewMode === 'next24h' ? 'bg-slate-900 text-white' : 'bg-slate-100'}`}>Next 24h</button>
            <button onClick={() => setViewMode('all')} className={`px-3 py-1 text-xs font-bold rounded ${viewMode === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100'}`}>All</button>
          </div>
          {currentViewBookings.map(b => (
            <div key={b.id} onClick={() => setSelectedBookingForPreview(b)} className={`p-4 rounded-xl border ${selectedBookingForPreview?.id === b.id ? 'border-amber-500 bg-amber-50' : 'border-slate-200'}`}>
                <div>{suppliers.find(s => s.id === b.supplierId)?.name}</div>
                <div className="text-[10px]">{b.date} {b.startTime}</div>
                {b.whatsappReminderStatus === 'Sent' && <div className="text-[10px] text-emerald-600 font-bold">Sent at {b.whatsappReminderSentAt}</div>}
            </div>
          ))}
        </div>
        
        {/* Preview */}
        {selectedBookingForPreview && (
          <div className="lg:col-span-7 space-y-4">
            <div className="p-4 bg-slate-100 rounded-xl">
               <pre className="text-xs">{generateWhatsAppMessage(selectedBookingForPreview, suppliers.find(s => s.id === selectedBookingForPreview.supplierId))}</pre>
               <div className="flex gap-2 mt-4">
                 <button onClick={() => handleSendWhatsApp(selectedBookingForPreview)} className="px-4 py-2 bg-emerald-600 text-white rounded text-xs font-bold">Open WhatsApp ({isTestMode ? 'TEST' : 'LIVE'})</button>
                 {selectedBookingForPreview.whatsappReminderStatus !== 'Sent' 
                   ? <button onClick={() => handleMarkAsSent(selectedBookingForPreview)} className="px-4 py-2 bg-blue-600 text-white rounded text-xs font-bold">Mark as Sent</button>
                   : <button onClick={() => handleUndoSent(selectedBookingForPreview)} className="px-4 py-2 bg-rose-600 text-white rounded text-xs font-bold">Undo Sent</button>
                 }
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Check,
  Trash2,
  Sparkles,
  Camera,
  RefreshCw,
  User,
  Shield,
  Loader2,
  ChevronDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StaffMember } from '../../types';
import { compressAndReadImageFile } from '../../utils/imageUtils';

interface StaffThumbnailModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffMember?: StaffMember | null;
}

// Curated avatar thumbnails for staff member quick selection
const PRESET_STAFF_THUMBNAILS = [
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=400&q=80',
];

export const StaffThumbnailModal: React.FC<StaffThumbnailModalProps> = ({
  isOpen,
  onClose,
  staffMember,
}) => {
  const { currentUser, staff, updateStaffThumbnail } = useApp();

  // Selected employee ID to update photo for
  const [selectedStaffId, setSelectedStaffId] = useState<string>(
    staffMember?.id || currentUser?.id || staff[0]?.id || ''
  );

  useEffect(() => {
    if (staffMember?.id) {
      setSelectedStaffId(staffMember.id);
    } else if (currentUser?.id && !selectedStaffId) {
      setSelectedStaffId(currentUser.id);
    }
  }, [staffMember?.id, currentUser?.id]);

  // Current active staff object being edited
  const activeStaff = staff.find((s) => s.id === selectedStaffId) || staffMember || currentUser || staff[0];

  const [inputUrl, setInputUrl] = useState(activeStaff?.avatar || '');
  const [previewError, setPreviewError] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync state whenever activeStaff changes
  useEffect(() => {
    if (activeStaff) {
      setInputUrl(activeStaff.avatar || '');
      setPreviewError(false);
    }
  }, [activeStaff?.id, activeStaff?.avatar]);

  if (!isOpen || !activeStaff) return null;

  const getInitials = (name: string): string => {
    if (!name) return 'ST';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file (PNG, JPG, WebP).');
      return;
    }

    try {
      setIsUploading(true);
      // Resize and compress to 600x600 high density photo
      const compressedDataUrl = await compressAndReadImageFile(file, 600, 600, 0.88);
      setInputUrl(compressedDataUrl);
      setPreviewError(false);
    } catch (err: any) {
      alert(err.message || 'Error processing image file.');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStaff) return;

    setIsSaving(true);
    const result = await updateStaffThumbnail(activeStaff.id, inputUrl.trim());
    setIsSaving(false);

    if (result.success) {
      setSuccessToast(
        `Profile photo for ${activeStaff.name}${
          activeStaff.isAdmin ? ' (System Administrator)' : ''
        } saved!`
      );
      setTimeout(() => {
        setSuccessToast(null);
      }, 2500);
    }
  };

  const handleClear = async () => {
    if (!activeStaff) return;
    setInputUrl('');
    setIsSaving(true);
    await updateStaffThumbnail(activeStaff.id, '');
    setIsSaving(false);
    setSuccessToast(`Photo removed for ${activeStaff.name}. Default initials displayed.`);
    setTimeout(() => {
      setSuccessToast(null);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-scale-in max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-black">
              <Camera className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-900">
                  Staff Roster
                </span>
                <span className="text-xs text-slate-400 font-medium">Employee Photos</span>
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                Assign &amp; Update Employee Photo
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 rounded-xl hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Employee Switcher */}
        <div className="space-y-1.5 bg-slate-50 p-3 rounded-2xl border border-slate-200">
          <label className="text-[10px] font-black text-slate-700 uppercase tracking-wider flex items-center justify-between">
            <span>Select Employee to Change Photo:</span>
            <span className="text-amber-800 font-bold">{staff.length} Employees</span>
          </label>
          <div className="relative">
            <select
              value={selectedStaffId}
              onChange={(e) => {
                const newId = e.target.value;
                setSelectedStaffId(newId);
                const nextMember = staff.find((s) => s.id === newId);
                if (nextMember) {
                  setInputUrl(nextMember.avatar || '');
                  setPreviewError(false);
                }
              }}
              className="w-full appearance-none px-3.5 py-2.5 bg-white border-2 border-slate-200 hover:border-amber-400 focus:border-amber-500 rounded-xl text-xs font-bold text-slate-900 outline-none cursor-pointer pr-9 shadow-2xs"
            >
              {staff.map((member) => (
                <option key={member.id} value={member.id}>
                  {member.name} — {member.role} {member.isAdmin ? '👑 [System Administrator]' : ''}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Quick Staff Thumbnail Selector Strip */}
          <div className="pt-2 flex items-center gap-1.5 overflow-x-auto pb-1">
            {staff.map((member) => {
              const isCurrent = member.id === selectedStaffId;
              return (
                <button
                  key={member.id}
                  type="button"
                  onClick={() => {
                    setSelectedStaffId(member.id);
                    setInputUrl(member.avatar || '');
                    setPreviewError(false);
                  }}
                  className={`flex items-center space-x-1.5 px-2 py-1 rounded-xl text-[11px] font-bold border transition-all shrink-0 cursor-pointer ${
                    isCurrent
                      ? 'bg-slate-900 text-white border-slate-900 ring-2 ring-amber-400'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-400'
                  }`}
                  title={`${member.name} (${member.role})`}
                >
                  {member.avatar ? (
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-4 h-4 rounded-full object-cover shrink-0"
                    />
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[9px] font-black flex items-center justify-center shrink-0">
                      {getInitials(member.name).slice(0, 1)}
                    </div>
                  )}
                  <span className="truncate max-w-[100px]">{member.name.split(' ')[0]}</span>
                  {member.isAdmin && <span className="text-[10px]">👑</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Preview Card */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5 min-w-0">
            {inputUrl && !previewError ? (
              <img
                src={inputUrl}
                alt={activeStaff.name}
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-500 shadow-md shrink-0"
                onError={() => setPreviewError(true)}
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-500 text-slate-950 font-black text-xl flex items-center justify-center shrink-0 uppercase shadow-md ring-2 ring-slate-200">
                {getInitials(activeStaff.name)}
              </div>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] uppercase font-bold text-slate-400">
                  Target Employee
                </span>
                {activeStaff.isAdmin && (
                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500 text-slate-950 flex items-center gap-0.5">
                    <Shield className="w-2.5 h-2.5 fill-slate-950" />
                    <span>System Administrator</span>
                  </span>
                )}
              </div>
              <div className="font-extrabold text-sm text-slate-900 truncate mt-0.5">
                {activeStaff.name}
              </div>
              <div className="text-xs text-slate-600 truncate">
                {activeStaff.role} &bull; {activeStaff.department}
              </div>
              <div className="text-[11px] font-mono text-slate-400 truncate">
                {activeStaff.email}
              </div>
            </div>
          </div>

          {inputUrl && (
            <button
              type="button"
              onClick={handleClear}
              disabled={isSaving}
              className="px-2.5 py-1.5 text-[11px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Remove Photo</span>
            </button>
          )}
        </div>

        {successToast && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-950 text-xs font-bold flex items-center gap-2 animate-fade-in shadow-2xs">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successToast}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-3.5">
          {/* File Upload Button (from Device) */}
          <div>
            <label className="text-[10px] font-extrabold text-slate-700 uppercase block mb-1">
              Upload New Photo From Your Computer
            </label>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              disabled={isUploading || isSaving}
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-3 px-3 border-2 border-dashed border-amber-300 hover:border-amber-500 bg-amber-50/60 hover:bg-amber-50 rounded-2xl flex items-center justify-center gap-2 text-xs font-bold text-amber-950 transition-colors cursor-pointer disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 text-amber-600 animate-spin" />
                  <span>Compressing and uploading photo...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 text-amber-600" />
                  <span>Choose Photo File from Device (PNG, JPG, WebP)</span>
                </>
              )}
            </button>
          </div>

          {/* Or Image URL */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-extrabold text-slate-700 uppercase">
                Or Paste Image Web URL
              </label>
              {inputUrl && (
                <button
                  type="button"
                  onClick={() => setPreviewError(false)}
                  className="text-[10px] text-amber-700 hover:underline flex items-center gap-0.5 cursor-pointer font-bold"
                >
                  <RefreshCw className="w-3 h-3" /> Refresh Preview
                </button>
              )}
            </div>
            <input
              type="url"
              placeholder="https://images.unsplash.com/... or web image link"
              value={inputUrl}
              onChange={(e) => {
                setInputUrl(e.target.value);
                setPreviewError(false);
              }}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white focus:ring-2 focus:ring-amber-500/20 outline-none"
            />
          </div>

          {/* Quick Preset Photos */}
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>Or Choose from Curated Professional Portraits:</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setInputUrl('');
                  setPreviewError(false);
                }}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                  !inputUrl
                    ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-2xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400'
                }`}
              >
                Initials Only
              </button>
              {PRESET_STAFF_THUMBNAILS.map((url, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setInputUrl(url);
                    setPreviewError(false);
                  }}
                  className={`w-9 h-9 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                    inputUrl === url
                      ? 'border-amber-500 ring-2 ring-amber-300 scale-105'
                      : 'border-slate-200 hover:border-slate-400 opacity-70 hover:opacity-100'
                  }`}
                  title={`Preset portrait ${idx + 1}`}
                >
                  <img src={url} alt={`Option ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100">
            <span className="text-[11px] text-slate-400 font-medium">
              Changes apply instantly to operator rosters, itineraries &amp; emails
            </span>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={isSaving || isUploading}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5 text-amber-400" />
                    <span>Save Photo for {activeStaff.name.split(' ')[0]}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

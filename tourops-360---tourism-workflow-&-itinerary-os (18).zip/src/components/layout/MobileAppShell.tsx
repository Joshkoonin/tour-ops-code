import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  Compass,
  Calendar,
  Briefcase,
  TrendingUp,
  MoreHorizontal,
  Plus,
  Share2,
  ExternalLink,
  DollarSign,
  Receipt,
  Users,
  Building2,
  AlertTriangle,
  FileText,
  Sparkles,
  CheckSquare,
  Shield,
  Download,
  CheckCircle2,
  RefreshCw,
  Coins,
  Key,
  LogOut,
  User,
  ShieldCheck,
  ChevronRight,
  Globe,
  Camera,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GenerateClientLinkModal } from '../itinerary/GenerateClientLinkModal';
import { FxRatesModal } from '../finance/FxRatesModal';
import { TeamAccessModal } from './TeamAccessModal';
import { StaffCredentialsModal } from '../tasks/StaffCredentialsModal';
import { StaffThumbnailModal } from './StaffThumbnailModal';

interface MobileAppShellProps {
  onNewItineraryClick: () => void;
  onNewTaskClick: () => void;
}

export const MobileAppShell: React.FC<MobileAppShellProps> = ({
  onNewItineraryClick,
  onNewTaskClick,
}) => {
  const {
    activeView,
    setActiveView,
    conflicts,
    tasks,
    itineraries,
    passports,
    activityCatalog,
    supplierInvoices,
    currentUser,
    isSystemAdmin,
    staff,
    switchUser,
    logoutUser,
    companyLogo,
    syncStatus,
    isSyncing,
    triggerManualSync,
    approvedMembers,
    openClientPortal,
  } = useApp();

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isMoreSheetOpen, setIsMoreSheetOpen] = useState(false);
  const [isQuickActionOpen, setIsQuickActionOpen] = useState(false);
  const [isUserSheetOpen, setIsUserSheetOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isFxModalOpen, setIsFxModalOpen] = useState(false);
  const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);
  const [isCredentialsModalOpen, setIsCredentialsModalOpen] = useState(false);
  const [isThumbnailModalOpen, setIsThumbnailModalOpen] = useState(false);

  // PWA install prompt state
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [showIosInstallGuide, setShowIosInstallGuide] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if already in standalone mode
    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true
    ) {
      setIsStandalone(true);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallClick = async () => {
    // Check if iOS
    const isIos = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    if (isIos && !isStandalone) {
      setShowIosInstallGuide(true);
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    } else {
      setShowIosInstallGuide(true);
    }
  };

  const urgentTasksCount = tasks.filter(
    (t) => t.status !== 'Completed' && (t.priority === 'Urgent' || t.priority === 'High')
  ).length;

  const criticalConflicts = conflicts.filter((c) => c.severity === 'CRITICAL');

  const mainTabs = [
    { id: 'itineraries', label: 'Tours', icon: Compass, count: itineraries.length },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'tour-management', label: 'Operations', icon: Briefcase },
    { id: 'tour-gross-profit', label: 'Profit', icon: TrendingUp },
  ];

  const allNavItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: TrendingUp },
    { id: 'calendar', label: 'Tours & Operations Calendar', icon: Calendar, highlight: true },
    { id: 'tour-gross-profit', label: 'Gross Profit per Tour', icon: TrendingUp },
    { id: 'itineraries', label: 'Itineraries & Trips', icon: Compass, count: itineraries.length },
    { id: 'tour-management', label: 'Tour Operations & P&L', icon: Briefcase, count: itineraries.length },
    { id: 'passports', label: 'Tour Passports', icon: FileText, count: passports.length },
    { id: 'activities', label: 'Activities Library', icon: Sparkles, count: activityCatalog.length },
    { id: 'tasks', label: 'Staff Tasks & Reminders', icon: CheckSquare, badge: urgentTasksCount > 0 ? urgentTasksCount : undefined, badgeColor: 'bg-amber-500' },
    { id: 'invoicing', label: 'Client Invoices', icon: DollarSign },
    { id: 'supplier-invoices', label: 'Supplier Invoices', icon: Receipt, count: supplierInvoices.length },
    { id: 'expenses', label: 'Expense Tracking', icon: Receipt },
    { id: 'general-expenses', label: 'General Expenses', icon: DollarSign },
    { id: 'crm', label: 'Client CRM & History', icon: Users },
    { id: 'suppliers', label: 'Suppliers & Bookings', icon: Building2 },
    { id: 'conflicts', label: 'Clash & Conflict Hub', icon: AlertTriangle, badge: conflicts.length > 0 ? conflicts.length : undefined, badgeColor: 'bg-red-500' },
  ];

  return (
    <>
      {/* Mobile Top App Bar (Only visible on screens < lg) */}
      <header className="lg:hidden sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 px-3.5 py-2.5 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-2.5 min-w-0">
          <button
            onClick={() => setIsDrawerOpen(true)}
            className="p-2 -ml-1 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Mobile Company Brand */}
          <div className="flex items-center space-x-2 truncate">
            {companyLogo ? (
              <img
                src={companyLogo}
                alt="Logo"
                className="w-7 h-7 object-contain rounded-lg bg-white p-0.5 shrink-0"
              />
            ) : (
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-slate-950 font-black shrink-0">
                <Globe className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              </div>
            )}
            <div className="truncate">
              <span className="text-sm font-black tracking-tight text-white">
                TourOps <span className="text-amber-400 font-serif italic text-xs">360</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center space-x-1.5 shrink-0">
          {/* Cloud Sync Status Icon */}
          <button
            type="button"
            onClick={triggerManualSync}
            title={syncStatus === 'synced' ? 'All changes saved to cloud' : 'Syncing changes'}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {isSyncing || syncStatus === 'saving' ? (
              <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
            ) : syncStatus === 'error' ? (
              <AlertTriangle className="w-4 h-4 text-rose-500" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
          </button>

          {/* Quick Action "+" Button */}
          <button
            type="button"
            onClick={() => setIsQuickActionOpen(!isQuickActionOpen)}
            className="p-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-all shadow-xs"
            title="Quick Actions"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
          </button>

          {/* User Avatar */}
          <button
            type="button"
            onClick={() => setIsUserSheetOpen(true)}
            className="relative p-0.5 rounded-xl border border-slate-700 hover:border-amber-400 transition-colors"
          >
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-lg object-cover"
              />
            ) : (
              <div className="w-7 h-7 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center">
                {currentUser?.name ? currentUser.name.slice(0, 2).toUpperCase() : 'SU'}
              </div>
            )}
          </button>
        </div>
      </header>

      {/* Mobile Install App Banner (if not installed yet) */}
      {!isStandalone && isInstallable && (
        <div className="lg:hidden bg-gradient-to-r from-amber-600 to-amber-500 text-slate-950 px-3.5 py-2 flex items-center justify-between text-xs font-bold shadow-xs">
          <div className="flex items-center space-x-2 truncate">
            <Download className="w-4 h-4 shrink-0 stroke-[2.5]" />
            <span className="truncate">Install TourOps 360 App on your phone</span>
          </div>
          <button
            onClick={handleInstallClick}
            className="px-2.5 py-1 bg-slate-950 text-white rounded-lg text-[11px] font-black shrink-0 hover:bg-slate-900 shadow-xs"
          >
            Install
          </button>
        </div>
      )}

      {/* Quick Mobile Action Sheet */}
      {isQuickActionOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-start justify-end p-3 pt-14"
          onClick={() => setIsQuickActionOpen(false)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-56 p-2 space-y-1 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => {
                setIsQuickActionOpen(false);
                setActiveView('calendar');
              }}
              className="w-full px-3 py-2 text-xs font-bold text-slate-800 hover:bg-amber-50 hover:text-amber-900 rounded-xl flex items-center space-x-2.5 transition-colors text-left"
            >
              <Calendar className="w-4 h-4 text-amber-500" />
              <span>Add Tour to Calendar</span>
            </button>
            <button
              onClick={() => {
                setIsQuickActionOpen(false);
                onNewItineraryClick();
              }}
              className="w-full px-3 py-2 text-xs font-bold text-slate-800 hover:bg-amber-50 hover:text-amber-900 rounded-xl flex items-center space-x-2.5 transition-colors text-left"
            >
              <Plus className="w-4 h-4 text-amber-500" />
              <span>Design New Itinerary</span>
            </button>
            <button
              onClick={() => {
                setIsQuickActionOpen(false);
                onNewTaskClick();
              }}
              className="w-full px-3 py-2 text-xs font-bold text-slate-800 hover:bg-amber-50 hover:text-amber-900 rounded-xl flex items-center space-x-2.5 transition-colors text-left"
            >
              <CheckSquare className="w-4 h-4 text-amber-500" />
              <span>Add Staff Task</span>
            </button>
            <button
              onClick={() => {
                setIsQuickActionOpen(false);
                setIsShareModalOpen(true);
              }}
              className="w-full px-3 py-2 text-xs font-bold text-slate-800 hover:bg-amber-50 hover:text-amber-900 rounded-xl flex items-center space-x-2.5 transition-colors text-left"
            >
              <Share2 className="w-4 h-4 text-amber-500" />
              <span>Share Client Link</span>
            </button>
          </div>
        </div>
      )}

      {/* Mobile Slide-Over Navigation Drawer */}
      {isDrawerOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex"
          onClick={() => setIsDrawerOpen(false)}
        >
          <div
            className="w-72 max-w-[85vw] bg-slate-900 text-slate-100 h-full flex flex-col shadow-2xl animate-slide-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                {companyLogo ? (
                  <img
                    src={companyLogo}
                    alt="Logo"
                    className="w-8 h-8 rounded-lg bg-white p-0.5 object-contain"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-slate-950 font-black">
                    <Globe className="w-4 h-4 stroke-[2.5]" />
                  </div>
                )}
                <div>
                  <div className="text-sm font-black text-white">TourOps 360</div>
                  <div className="text-[10px] text-slate-400 font-medium">Mobile Workspace</div>
                </div>
              </div>
              <button
                onClick={() => setIsDrawerOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current Staff Badge */}
            <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between">
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{currentUser?.name}</div>
                <div className="text-[10px] text-amber-400 font-semibold truncate">
                  {currentUser?.role} {currentUser?.isAdmin ? '• Admin' : ''}
                </div>
              </div>
              <button
                onClick={() => {
                  setIsDrawerOpen(false);
                  setIsUserSheetOpen(true);
                }}
                className="text-[10px] font-bold text-slate-400 hover:text-white underline"
              >
                Profile
              </button>
            </div>

            {/* Navigation Links */}
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              <div className="px-2 pb-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                Menu &amp; Operations
              </div>
              {allNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveView(item.id);
                      setIsDrawerOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-amber-500 text-slate-950 font-extrabold shadow-sm'
                        : item.highlight
                        ? 'bg-slate-800/80 text-amber-300 hover:bg-slate-800'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 truncate">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-slate-950' : item.highlight ? 'text-amber-400' : 'text-slate-400'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge !== undefined && (
                      <span className={`px-1.5 py-0.2 text-[10px] font-bold rounded-full text-white ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                    {item.count !== undefined && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                          isActive ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}

              <div className="pt-4 px-2 pb-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                Quick Shortcuts
              </div>
              <button
                onClick={() => {
                  setIsDrawerOpen(false);
                  setIsShareModalOpen(true);
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-amber-400 hover:bg-slate-800"
              >
                <Share2 className="w-4 h-4 text-amber-400" />
                <span>Share Client Link</span>
              </button>
              <button
                onClick={() => {
                  setIsDrawerOpen(false);
                  openClientPortal('trip-1');
                }}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-emerald-400 hover:bg-slate-800"
              >
                <ExternalLink className="w-4 h-4 text-emerald-400" />
                <span>Open Live Client View</span>
              </button>

              {/* Install Mobile App action */}
              {!isStandalone && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    handleInstallClick();
                  }}
                  className="w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 mt-2 transition-all shadow-xs"
                >
                  <Download className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                  <span>Install Mobile App</span>
                </button>
              )}
            </nav>

            {/* Drawer Footer */}
            <div className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
              <span>TourOps 360 Mobile</span>
              <button
                onClick={() => {
                  setIsDrawerOpen(false);
                  logoutUser();
                }}
                className="text-rose-400 hover:text-rose-300 flex items-center gap-1 font-bold"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Lock</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile User & Admin Sheet */}
      {isUserSheetOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setIsUserSheetOpen(false)}
        >
          <div
            className="w-full max-w-lg bg-white rounded-t-3xl p-5 space-y-4 shadow-2xl animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-3">
                {currentUser?.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-10 h-10 rounded-xl object-cover ring-2 ring-amber-400"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 font-black text-sm flex items-center justify-center">
                    {currentUser?.name ? currentUser.name.slice(0, 2).toUpperCase() : 'SU'}
                  </div>
                )}
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">{currentUser?.name}</h4>
                  <p className="text-xs text-slate-500">{currentUser?.role} {currentUser?.isAdmin ? '• Admin' : ''}</p>
                </div>
              </div>
              <button
                onClick={() => setIsUserSheetOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <button
                type="button"
                onClick={() => {
                  setIsUserSheetOpen(false);
                  setIsFxModalOpen(true);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center justify-between"
              >
                <div className="flex items-center space-x-2.5">
                  <Coins className="w-4 h-4 text-amber-600" />
                  <span>Update Foreign Exchange (FX) Rates</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsUserSheetOpen(false);
                  setIsThumbnailModalOpen(true);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center justify-between"
              >
                <div className="flex items-center space-x-2.5">
                  <Camera className="w-4 h-4 text-blue-600" />
                  <span>Employee &amp; Admin Photos</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {isSystemAdmin && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserSheetOpen(false);
                      setIsTeamModalOpen(true);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Google Team Approvals</span>
                    </div>
                    {approvedMembers.filter((m) => m.status === 'pending').length > 0 && (
                      <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 text-[10px] rounded-full font-black">
                        {approvedMembers.filter((m) => m.status === 'pending').length}
                      </span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsUserSheetOpen(false);
                      setIsCredentialsModalOpen(true);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2.5">
                      <Key className="w-4 h-4 text-amber-600" />
                      <span>Staff Logins &amp; Passwords</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                </>
              )}

              {/* Quick switch staff member */}
              <div className="pt-2">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Switch Active Staff Profile:
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {staff.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        switchUser(s.id);
                        setIsUserSheetOpen(false);
                      }}
                      className={`p-2 rounded-xl text-xs font-bold text-left truncate transition-colors ${
                        currentUser?.id === s.id
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      <div className="truncate">{s.name}</div>
                      <div className="text-[10px] opacity-70 truncate">{s.role}</div>
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsUserSheetOpen(false);
                  logoutUser();
                }}
                className="w-full mt-2 px-3.5 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold flex items-center justify-center space-x-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out / Lock Screen</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS Install Guide Modal */}
      {showIosInstallGuide && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowIosInstallGuide(false)}
        >
          <div
            className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/25">
              <Download className="w-7 h-7 stroke-[2.5]" />
            </div>
            <h3 className="text-lg font-black text-slate-900">Install TourOps 360</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              To install TourOps 360 on your iPhone or iPad:
            </p>
            <ol className="text-xs text-left text-slate-700 space-y-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-200 font-medium">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                  1
                </span>
                <span>Tap the <strong>Share</strong> button at the bottom of Safari (<span className="text-blue-600">⎋</span>)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                  2
                </span>
                <span>Scroll down and tap <strong>Add to Home Screen</strong></span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                  3
                </span>
                <span>Tap <strong>Add</strong> in the top-right corner</span>
              </li>
            </ol>
            <button
              onClick={() => setShowIosInstallGuide(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar (Tab Bar) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 text-slate-400 py-1 px-1.5 safe-area-pb shadow-2xl flex items-center justify-around">
        {mainTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeView === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveView(tab.id)}
              className={`flex-1 py-1.5 px-1 flex flex-col items-center justify-center rounded-xl transition-all ${
                isActive
                  ? 'text-amber-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="absolute -top-1 -right-2 px-1 text-[9px] font-black rounded-full bg-amber-500 text-slate-950">
                    {tab.count}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[64px]">
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* More Tab Button */}
        <button
          onClick={() => setIsMoreSheetOpen(true)}
          className={`flex-1 py-1.5 px-1 flex flex-col items-center justify-center rounded-xl transition-all ${
            isMoreSheetOpen ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MoreHorizontal className="w-5 h-5 stroke-[2]" />
          <span className="text-[10px] mt-0.5 tracking-tight">More</span>
        </button>
      </nav>

      {/* "More" Bottom Sheet Modal */}
      {isMoreSheetOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setIsMoreSheetOpen(false)}
        >
          <div
            className="w-full max-w-lg bg-white rounded-t-3xl p-5 space-y-4 shadow-2xl animate-slide-up max-h-[80vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">All Modules &amp; Tools</h3>
              <button
                onClick={() => setIsMoreSheetOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 overflow-y-auto py-1">
              {allNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveView(item.id);
                      setIsMoreSheetOpen(false);
                    }}
                    className={`p-3 rounded-2xl border text-left flex items-start space-x-2.5 transition-all ${
                      isActive
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-950 font-extrabold shadow-2xs'
                        : 'bg-slate-50 border-slate-200/80 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate leading-tight">{item.label}</div>
                      {item.count !== undefined && (
                        <div className="text-[10px] text-slate-400">{item.count} items</div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modals triggered from Mobile Shell */}
      <GenerateClientLinkModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      <FxRatesModal
        isOpen={isFxModalOpen}
        onClose={() => setIsFxModalOpen(false)}
      />

      <TeamAccessModal
        isOpen={isTeamModalOpen}
        onClose={() => setIsTeamModalOpen(false)}
      />

      <StaffCredentialsModal
        isOpen={isCredentialsModalOpen}
        onClose={() => setIsCredentialsModalOpen(false)}
      />

      <StaffThumbnailModal
        isOpen={isThumbnailModalOpen}
        onClose={() => setIsThumbnailModalOpen(false)}
      />
    </>
  );
};

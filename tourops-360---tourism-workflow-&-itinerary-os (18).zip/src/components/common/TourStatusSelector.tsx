import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  Play,
  RotateCw,
  AlertCircle,
  X,
  ChevronDown,
} from 'lucide-react';
import { Itinerary, TripStatus } from '../../types';
import { useApp } from '../../context/AppContext';

interface TourStatusSelectorProps {
  tour: Itinerary;
  size?: 'sm' | 'md';
  showQuickActions?: boolean;
  className?: string;
  onStatusChange?: (newStatus: TripStatus) => void;
}

const STATUS_COLORS: Record<
  TripStatus,
  {
    bg: string;
    text: string;
    border: string;
    dot: string;
    hover: string;
  }
> = {
  Proposed: {
    bg: 'bg-amber-100',
    text: 'text-amber-950',
    border: 'border-amber-300',
    dot: 'bg-amber-500',
    hover: 'hover:bg-amber-200/80',
  },
  Confirmed: {
    bg: 'bg-emerald-100',
    text: 'text-emerald-950',
    border: 'border-emerald-300',
    dot: 'bg-emerald-600',
    hover: 'hover:bg-emerald-200/80',
  },
  'In Progress': {
    bg: 'bg-blue-100',
    text: 'text-blue-950',
    border: 'border-blue-300',
    dot: 'bg-blue-600 animate-pulse',
    hover: 'hover:bg-blue-200/80',
  },
  'completed but not cost reconciled': {
    bg: 'bg-amber-100',
    text: 'text-amber-950',
    border: 'border-amber-300',
    dot: 'bg-amber-600',
    hover: 'hover:bg-amber-200/80',
  },
  'completed and reconciled': {
    bg: 'bg-emerald-100',
    text: 'text-emerald-950',
    border: 'border-emerald-300',
    dot: 'bg-emerald-600',
    hover: 'hover:bg-emerald-200/80',
  },
  Draft: {
    bg: 'bg-slate-100',
    text: 'text-slate-800',
    border: 'border-slate-300',
    dot: 'bg-slate-500',
    hover: 'hover:bg-slate-200/80',
  },
  Cancelled: {
    bg: 'bg-rose-100',
    text: 'text-rose-900',
    border: 'border-rose-300',
    dot: 'bg-rose-500',
    hover: 'hover:bg-rose-200/80',
  },
};

const ALL_STATUSES: TripStatus[] = [
  'Proposed',
  'Confirmed',
  'In Progress',
  'completed but not cost reconciled',
  'completed and reconciled',
  'Draft',
  'Cancelled',
];

export const TourStatusSelector: React.FC<TourStatusSelectorProps> = ({
  tour,
  size = 'md',
  showQuickActions = false,
  className = '',
  onStatusChange,
}) => {
  const {
    updateTourStatus,
    tourStatusWarning,
    clearTourStatusWarning,
    retryTourStatusUpdate,
  } = useApp();

  const [isUpdating, setIsUpdating] = useState(false);
  const [pendingStatus, setPendingStatus] = useState<TripStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  const colors = STATUS_COLORS[tour.status] || STATUS_COLORS.Draft;
  const isThisTourFailing =
    tourStatusWarning && tourStatusWarning.tripId === tour.id;

  const initiateChange = (newStatus: TripStatus) => {
    if (newStatus === tour.status) return;
    setPendingStatus(newStatus);
    setError(null);
  };

  const handleConfirm = async () => {
    if (!pendingStatus) return;
    setIsUpdating(true);
    setError(null);
    try {
      const res = await updateTourStatus(tour.id, pendingStatus);
      if (res.success) {
        setPendingStatus(null);
        if (onStatusChange) onStatusChange(pendingStatus);
      } else {
        setError(res.error || 'Failed to update status');
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleCancel = () => {
    setPendingStatus(null);
    setError(null);
  };

  const handleRetry = async () => {
    if (!tourStatusWarning) return;
    setIsUpdating(true);
    setError(null);
    try {
      const res = await retryTourStatusUpdate(
        tourStatusWarning.tripId,
        tourStatusWarning.status
      );
      if (res.success && onStatusChange) {
        onStatusChange(tourStatusWarning.status);
      } else {
        setError(res.error || 'Failed to retry status update');
      }
    } finally {
      setIsUpdating(false);
    }
  };

  const sizeClasses =
    size === 'sm'
      ? 'text-[11px] py-0.5 px-2 font-bold'
      : 'text-xs py-1 px-3 font-extrabold';

  return (
    <div
      className={`inline-flex flex-col gap-1.5 ${className}`}
      onClick={(e) => e.stopPropagation()}
    >
      {pendingStatus ? (
        <div className="flex flex-col gap-2 p-2 bg-white border border-slate-200 rounded-lg shadow-lg">
          <p className="text-xs text-slate-800">
            Confirm change to <span className="font-bold">{pendingStatus}</span>?
          </p>
          {error && <p className="text-xs text-rose-600">{error}</p>}
          <div className="flex gap-2">
            <button
              type="button"
              disabled={isUpdating}
              onClick={handleConfirm}
              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-md text-xs font-bold transition-colors cursor-pointer"
            >
              Save status
            </button>
            <button
              type="button"
              disabled={isUpdating}
              onClick={handleCancel}
              className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 disabled:opacity-50 text-slate-800 rounded-md text-xs font-bold transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Status Dropdown Pill */}
          <div className="relative inline-flex items-center">
            <select
              value={tour.status}
              disabled={isUpdating}
              onChange={(e) => initiateChange(e.target.value as TripStatus)}
              aria-label={`Tour status for ${tour.title}`}
              className={`appearance-none cursor-pointer rounded-full border shadow-2xs transition-colors pr-6 pl-2.5 ${sizeClasses} ${colors.bg} ${colors.text} ${colors.border} ${colors.hover} focus:outline-hidden focus:ring-2 focus:ring-offset-1 focus:ring-amber-500`}
            >
              {ALL_STATUSES.map((st) => (
                <option key={st} value={st} className="bg-white text-slate-900">
                  {st}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 absolute right-2 pointer-events-none opacity-60 text-slate-800" />
          </div>

          {/* 1-Click Transition Quick Actions */}
          {showQuickActions && (
            <div className="flex items-center gap-1">
              {tour.status === 'Proposed' && (
                <>
                  <button
                    type="button"
                    onClick={() => initiateChange('Confirmed')}
                    disabled={isUpdating}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    title="Accept proposal and mark tour as Confirmed"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Confirm</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => initiateChange('In Progress')}
                    disabled={isUpdating}
                    className="px-2 py-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    title="Mark tour as In Progress"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Start</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => initiateChange('completed but not cost reconciled')}
                    disabled={isUpdating}
                    className="px-2 py-1 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    title="Mark tour as Completed (Unreconciled)"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Complete</span>
                  </button>
                </>
              )}

              {tour.status === 'Confirmed' && (
                <>
                  <button
                    type="button"
                    onClick={() => initiateChange('In Progress')}
                    disabled={isUpdating}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    title="Begin active operations (In Progress)"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Start</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => initiateChange('completed but not cost reconciled')}
                    disabled={isUpdating}
                    className="px-2 py-1 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    title="Mark tour as Completed (Unreconciled)"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Complete</span>
                  </button>
                </>
              )}

              {tour.status === 'In Progress' && (
                <button
                  type="button"
                  onClick={() => initiateChange('completed but not cost reconciled')}
                  disabled={isUpdating}
                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                  title="Conclude tour and mark Completed"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Mark Completed</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Error Isolation Notice: Displayed if status update encounters an error */}
      {isThisTourFailing && (
        <div
          role="alert"
          className="flex items-center gap-2 p-1.5 px-2 bg-amber-50 border border-amber-300 rounded-lg text-amber-900 text-[11px] font-semibold animate-fade-in shadow-xs"
        >
          <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span className="truncate">{tourStatusWarning.message || 'Tour status update unavailable'}</span>
          <button
            type="button"
            onClick={handleRetry}
            disabled={isUpdating}
            className="px-2 py-0.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded text-[10px] flex items-center gap-1 cursor-pointer ml-auto shrink-0 transition-colors"
            title="Retry updating status"
          >
            <RotateCw className={`w-3 h-3 ${isUpdating ? 'animate-spin' : ''}`} />
            <span>Retry</span>
          </button>
          <button
            type="button"
            onClick={clearTourStatusWarning}
            className="p-0.5 text-amber-800 hover:text-amber-950 rounded shrink-0 cursor-pointer"
            title="Dismiss notice"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
    </div>
  );
};

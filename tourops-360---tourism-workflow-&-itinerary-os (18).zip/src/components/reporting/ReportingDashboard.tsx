import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import {
  PieChart,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Compass,
  Building,
  Printer,
  Calendar,
  Sparkles,
  BarChart3,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  FileText,
  Briefcase,
  Search,
  Filter,
  ChevronRight,
  X,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Receipt,
  Percent,
  Users,
  MapPin,
  Clock,
  Building2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, Itinerary, SupplierInvoice, Expense, Invoice, Client } from '../../types';
import { getTourContractRevenue } from '../../utils/financialCalculations';
import { isTourEligibleForProfitReporting, calculateManagementDirectCostsForTour } from '../../utils/financialCalculations';

interface ReportingDashboardProps {
  defaultTab?: 'overview' | 'tour-gross-profit';
}


export const ReportingDashboard: React.FC<ReportingDashboardProps> = ({ defaultTab = 'overview' }) => {
  const {
    itineraries,
    invoices,
    supplierInvoices,
    expenses,
    clients,
    suppliers,
    supplierBookings,
    convertCurrency,
    formatMoney,
    hasFullFinancialView,
    setActiveView,
    setSelectedTripId,
  } = useApp();

  const [currentDashboardTab, setDashboardTab] = useState<'overview' | 'tour-gross-profit'>(defaultTab);
  const [dateRange, setDateRange] = useState<'YTD' | 'Q4' | 'ALL' | 'CUSTOM'>('ALL');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [isCustomDateModalOpen, setIsCustomDateModalOpen] = useState(false);
  const [periodReportMode, setPeriodReportMode] = useState<'gross' | 'net' | null>(null);
  React.useEffect(() => {
    console.log('periodReportMode changed:', periodReportMode);
  }, [periodReportMode]);
  const [appliedPeriod, setAppliedPeriod] = useState<{ mode: 'gross' | 'net'; start: string; end: string; } | null>(null);

  // Search & Filter state for Gross Profit per Tour tab
  const [tourSearchQuery, setTourSearchQuery] = useState('');
  const [tourStatusFilter, setTourStatusFilter] = useState<string>('ALL');
  const [tourSortBy, setTourSortBy] = useState<'profit-desc' | 'margin-desc' | 'revenue-desc' | 'date-asc'>('profit-desc');
  const [selectedTourForBreakdown, setSelectedTourForBreakdown] = useState<string | null>(null);

  // ---------------------------------------------------------
  // FINANCIAL CALCULATIONS (INCLUDING SUPPLIER INVOICES & CREDITS)
  // ---------------------------------------------------------

  // Helper to filter by date
  const isWithinDateRange = (dateStr: string) => {
    if (dateRange === 'ALL' || !dateStr) return true;
    
    const year = new Date().getFullYear();
    let start = '';
    let end = '';

    if (dateRange === 'YTD') {
      start = `${year}-01-01`;
      end = new Date().toISOString().split('T')[0];
    } else if (dateRange === 'Q4') {
      start = `${year}-10-01`;
      end = `${year}-12-31`;
    } else if (dateRange === 'CUSTOM' && appliedPeriod) {
      start = appliedPeriod.start;
      end = appliedPeriod.end;
    } else {
      return true;
    }
    
    return dateStr >= start && dateStr <= end;
  };




  // ---------------------------------------------------------
  // SPEND CATEGORIES AGGREGATION (Expenses + Supplier Invoices)
  // ---------------------------------------------------------
  const combinedSpendByCategory = useMemo(() => {
    const acc: Record<string, number> = {};

    // From expenses
    expenses.forEach((exp) => {
      const usd = convertCurrency(exp.amount, exp.currency, 'USD');
      acc[exp.category] = (acc[exp.category] || 0) + usd;
    });

    // From supplier invoices
    supplierInvoices.forEach((inv) => {
      const sup = suppliers.find((s) => s.id === inv.supplierId);
      const cat = sup?.category || (inv.isGeneralOverhead ? 'Office & Admin' : 'Private Guide & Expert');
      const usd = convertCurrency(inv.amount, inv.currency, 'USD');
      const val = inv.isCredit ? -usd : usd;
      acc[cat] = (acc[cat] || 0) + val;
    });

    return acc;
  }, [expenses, supplierInvoices, suppliers, convertCurrency]);

  const categoryEntries = useMemo(() => {
    return Object.entries(combinedSpendByCategory)
      .filter(([_, amt]) => amt > 0)
      .sort((a, b) => b[1] - a[1]);
  }, [combinedSpendByCategory]);

  const maxCategorySpend = Math.max(...categoryEntries.map((c) => c[1]), 1);

  // Status breakdown
  const statusCounts = useMemo(() => {
    return itineraries.reduce((acc, t) => {
      if (isTourEligibleForProfitReporting(t)) {
        acc[t.status] = (acc[t.status] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);
  }, [itineraries]);

  // Lone Provider utilization
  const loneSuppliers = useMemo(() => suppliers.filter((s) => s.isLoneProvider), [suppliers]);
  const loneBookingsCount = useMemo(() => {
    return supplierBookings.filter((b) =>
      loneSuppliers.some((ls) => ls.id === b.supplierId)
    ).length;
  }, [supplierBookings, loneSuppliers]);

  // ---------------------------------------------------------
  // PER-TOUR GROSS PROFIT CALCULATION & DATA ENRICHMENT
  // ---------------------------------------------------------
  const toursGrossProfitData = useMemo(() => {
    return itineraries.map((tour) => {
      const client = clients.find((c) => c.id === tour.clientId);

      // Tour client invoices
      const tourInvoices = invoices.filter((inv) => inv.tripId === tour.id);
      const totalInvoicedUSD = tourInvoices.reduce((sum, inv) => {
        const usd = convertCurrency(inv.totalAmount, inv.currency, 'USD');
        return inv.isCreditNote ? sum - usd : sum + usd;
      }, 0);

      const totalPaidUSD = tourInvoices.reduce((sum, inv) => {
        return sum + convertCurrency(inv.amountPaid, inv.currency, 'USD');
      }, 0);

      // Tour package price converted to USD
      const packagePriceUSD = convertCurrency(getTourContractRevenue(tour), tour.currency || 'USD', 'USD');

      // Effective revenue: full agreed selling value
      const effectiveRevenueUSD = packagePriceUSD;

      // Tour supplier invoices (accounting for credits)
      const tourSupInvoices = supplierInvoices.filter(
        (inv) => inv.tripId === tour.id && !inv.isGeneralOverhead
      );

      const supplierInvoicesUSD = tourSupInvoices.reduce((sum, inv) => {
        const usd = convertCurrency(inv.amount, inv.currency, 'USD');
        return inv.isCredit ? sum - usd : sum + usd;
      }, 0);

      const supplierCreditsUSD = tourSupInvoices
        .filter((inv) => inv.isCredit)
        .reduce((sum, inv) => sum + convertCurrency(inv.amount, inv.currency, 'USD'), 0);

      // Tour direct expenses
      const tourExp = expenses.filter((e) => e.tripId === tour.id && !e.isGeneralOverhead);
      const directExpensesUSD = tourExp.reduce((sum, e) => {
        return sum + convertCurrency(e.amount, e.currency, 'USD');
      }, 0);

      // Projected Costs (Specific item estimates + General whole-tour costs like bus & guide)
      const specificProjectedUSD = tour.days.reduce((sum, day) => {
        return (
          sum +
          day.activities.reduce((actSum, act) => {
            const itemCost = act.ourCost ?? act.costEstimate ?? 0;
            if (itemCost <= 0) return actSum;
            return actSum + convertCurrency(itemCost, act.currency || tour.currency || 'USD', 'USD');
          }, 0)
        );
      }, 0);

      const generalProjectedUSD = (tour.generalProjectedCosts || []).reduce((sum, item) => {
        return sum + convertCurrency(item.estimatedAmount || 0, item.currency || tour.currency || 'USD', 'USD');
      }, 0);

      // Total direct costs = supplier invoices + direct expenses + general projected costs
      // Deduplicate using linkedCostId
      const totalDirectCostsUSD = calculateManagementDirectCostsForTour(
        tour,
        supplierInvoices,
        expenses,
        convertCurrency,
        'USD'
      );

      // Gross profit & margin based on actual invoices/expenses + general costs
      const grossProfitUSD = effectiveRevenueUSD - totalDirectCostsUSD;
      const grossMarginPercent =
        effectiveRevenueUSD > 0
          ? Math.round((grossProfitUSD / effectiveRevenueUSD) * 1000) / 10
          : 0;

      const totalProjectedCostsUSD = specificProjectedUSD + generalProjectedUSD;
      const isProposed = tour.status === 'Proposed';
      const isEligible = isTourEligibleForProfitReporting(tour);
      const hasActualBills = tourSupInvoices.length > 0 || tourExp.length > 0;
      // Displayed cost and profit based on actual total costs
      const displayedCostUSD = totalDirectCostsUSD;
      const displayedProfitUSD = effectiveRevenueUSD - displayedCostUSD;
      const displayedMarginPercent =
        effectiveRevenueUSD > 0
          ? Math.round((displayedProfitUSD / effectiveRevenueUSD) * 1000) / 10
          : 0;

      return {
        tour,
        client,
        packagePriceUSD,
        totalInvoicedUSD,
        totalPaidUSD,
        effectiveRevenueUSD,
        supplierInvoicesUSD,
        supplierInvoicesCount: tourSupInvoices.length,
        supplierCreditsUSD,
        directExpensesUSD,
        directExpensesCount: tourExp.length,
        totalDirectCostsUSD,
        grossProfitUSD,
        grossMarginPercent,
        totalProjectedCostsUSD,
        specificProjectedUSD,
        generalProjectedUSD,
        isProposed,
        isEligible,
        hasActualBills,
        displayedCostUSD,
        displayedProfitUSD,
        displayedMarginPercent,
        tourSupplierInvoices: tourSupInvoices,
        tourExpenses: tourExp,
        tourInvoices,
        debugInfo: { totalDirectCostsUSD, directExpensesUSD, supplierInvoicesUSD, generalProjectedUSD },
      };
    });
  }, [itineraries, clients, invoices, supplierInvoices, expenses, convertCurrency]);

  const executiveSummary = useMemo(() => {
    // A. Commenced/completed tours (Eligible status + started in period)
    const groupA = toursGrossProfitData.filter(
      (t) => isTourEligibleForProfitReporting(t.tour) && 
             ['In Progress', 'completed but not cost reconciled', 'completed and reconciled', 'Completed'].includes(t.tour.status) &&
             isWithinDateRange(t.tour.startDate)
    );
    
    // B. Confirmed future tours
    const groupB = toursGrossProfitData.filter(
      (t) => t.tour.status === 'Confirmed' && isWithinDateRange(t.tour.startDate)
    );

    const revA = groupA.reduce((sum, t) => sum + t.packagePriceUSD, 0);
    const costsA = groupA.reduce((sum, t) => sum + t.totalDirectCostsUSD, 0);
    const grossProfitA = revA - costsA;
    
    const revB = groupB.reduce((sum, t) => sum + t.packagePriceUSD, 0);
    const costsB = groupB.reduce((sum, t) => sum + t.totalDirectCostsUSD, 0);
    const grossProfitB = revB - costsB;

    // Overhead
    const overheadSupplierInvoicesUSD = supplierInvoices
      .filter((inv) => (inv.isGeneralOverhead || !inv.tripId || inv.tripId === 'general-overhead') && isWithinDateRange(inv.issueDate))
      .reduce((sum, inv) => {
        const usd = convertCurrency(inv.amount, inv.currency, 'USD');
        return inv.isCredit ? sum - usd : sum + usd;
      }, 0);

    const overheadExpensesUSD = expenses
      .filter((e) => (e.isGeneralOverhead || !e.tripId) && isWithinDateRange(e.date))
      .reduce((sum, e) => sum + convertCurrency(e.amount, e.currency, 'USD'), 0);
      
    const totalOverheadUSD = overheadSupplierInvoicesUSD + overheadExpensesUSD;
    
    return {
      grossProfitUSD: grossProfitA,
      projectedGrossProfitUSD: grossProfitA + grossProfitB,
      projectedAdditionalGrossProfitUSD: grossProfitB,
      confirmedNetProfitUSD: grossProfitA - totalOverheadUSD,
      projectedNetProfitUSD: (grossProfitA + grossProfitB) - totalOverheadUSD,
      totalOverheadUSD,
      overheadSupplierInvoicesUSD,
      overheadExpensesUSD
    };
  }, [toursGrossProfitData, supplierInvoices, expenses, convertCurrency, dateRange, appliedPeriod]);


  // Filtered and sorted tours for Gross Profit tab
  const filteredToursGrossProfit = useMemo(() => {
    return toursGrossProfitData
      .filter((item) => {
        const tourName = item.tour.tourName || item.tour.title;
        const matchesSearch =
          !tourSearchQuery.trim() ||
          tourName.toLowerCase().includes(tourSearchQuery.toLowerCase()) ||
          item.tour.code.toLowerCase().includes(tourSearchQuery.toLowerCase()) ||
          item.tour.destination.toLowerCase().includes(tourSearchQuery.toLowerCase()) ||
          (item.client && item.client.name.toLowerCase().includes(tourSearchQuery.toLowerCase()));

        const matchesStatus =
          tourStatusFilter === 'ALL' || item.tour.status === tourStatusFilter;

        return item.isEligible && matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        if (tourSortBy === 'profit-desc') return b.grossProfitUSD - a.grossProfitUSD;
        if (tourSortBy === 'margin-desc') return b.grossMarginPercent - a.grossMarginPercent;
        if (tourSortBy === 'revenue-desc') return b.effectiveRevenueUSD - a.effectiveRevenueUSD;
        if (tourSortBy === 'date-asc') return a.tour.startDate.localeCompare(b.tour.startDate);
        return 0;
      });
  }, [toursGrossProfitData, tourSearchQuery, tourStatusFilter, tourSortBy]);

  // Aggregate stats across tours
  const toursGrossProfitSummary = useMemo(() => {
    const eligibleTours = toursGrossProfitData.filter(t => t.isEligible);
    const totalToursRevenue = eligibleTours.reduce((sum, t) => sum + t.effectiveRevenueUSD, 0);
    const totalToursCosts = eligibleTours.reduce((sum, t) => sum + t.totalDirectCostsUSD, 0);
    const totalSupplierInvoices = eligibleTours.reduce((sum, t) => sum + t.supplierInvoicesUSD, 0);
    const totalDirectExpenses = eligibleTours.reduce((sum, t) => sum + t.directExpensesUSD, 0);
    const totalToursGrossProfit = eligibleTours.reduce((sum, t) => sum + t.grossProfitUSD, 0);
    const avgTourGrossMargin =
      totalToursRevenue > 0 ? Math.round((totalToursGrossProfit / totalToursRevenue) * 1000) / 10 : 0;
    const topTour = [...eligibleTours].sort((a, b) => b.grossProfitUSD - a.grossProfitUSD)[0];

    return {
      totalToursRevenue,
      totalToursCosts,
      totalSupplierInvoices,
      totalDirectExpenses,
      totalToursGrossProfit,
      avgTourGrossMargin,
      topTour,
    };
  }, [toursGrossProfitData]);

  // Currently active tour for detail modal/drawer
  const activeBreakdownTour = useMemo(() => {
    if (!selectedTourForBreakdown) return null;
    return toursGrossProfitData.find((t) => t.tour.id === selectedTourForBreakdown) || null;
  }, [selectedTourForBreakdown, toursGrossProfitData]);

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100 text-amber-800">
              Module 6: Business Intelligence
            </span>
            <span className="text-xs text-slate-500 font-medium">Analytics &amp; Financial Reporting</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            Executive Performance &amp; Profit Analytics
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Real-time visual reporting on gross tour margins, supplier expenditure allocation, and profitability per tour.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <div className="flex bg-white border border-slate-200 rounded-xl p-1 text-xs font-semibold shadow-2xs">
            {(['ALL', 'YTD', 'Q4'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setDateRange(r)}
                className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                  dateRange === r ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {r === 'ALL' ? 'All Time' : r === 'YTD' ? `${new Date().getFullYear()} YTD` : `Q4 ${new Date().getFullYear()}`}
              </button>
            ))}
          </div>

          <button
            onClick={() => setActiveView('pnl-statement')}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Generate monthly or 2-month P&L statements across entire database"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Monthly P&amp;L Statement</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Primary Navigation Tabs: Executive Overview vs Gross Profit per Tour */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setDashboardTab('overview')}
          className={`flex items-center gap-2 px-5 py-3 border-b-2 font-bold text-xs transition-all cursor-pointer ${
            currentDashboardTab === 'overview'
              ? 'border-amber-500 text-amber-700 bg-amber-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Executive Overview &amp; Margins</span>
        </button>

        <button
          onClick={() => setDashboardTab('tour-gross-profit')}
          className={`flex items-center gap-2 px-5 py-3 border-b-2 font-bold text-xs transition-all cursor-pointer ${
            currentDashboardTab === 'tour-gross-profit'
              ? 'border-amber-500 text-amber-700 bg-amber-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          <span>Gross Profit per Tour</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 ml-1">
            {itineraries.length} Tours
          </span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: EXECUTIVE OVERVIEW */}
      {/* ========================================================= */}
      {currentDashboardTab === 'overview' && (
        <div className="space-y-6">
          {/* KPI Cards and Report Buttons (Only for Full Financial View) */}
          {/* KPI Cards (Only for Full Financial View) */}
          {/* KPI Cards (Only for Full Financial View) */}
          {hasFullFinancialView && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Gross Profit */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Gross profit</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{formatMoney(executiveSummary.grossProfitUSD, 'USD')}</div>
                  <div className="text-xs text-slate-500 mt-1">Commenced/completed tours revenue less direct costs.</div>
                </div>

                {/* 2. Projected gross profit */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Projected gross profit</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{formatMoney(executiveSummary.projectedGrossProfitUSD, 'USD')}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    {formatMoney(executiveSummary.grossProfitUSD, 'USD')} commenced + {formatMoney(executiveSummary.projectedAdditionalGrossProfitUSD, 'USD')} future confirmed.
                  </div>
                </div>

                {/* 3. Confirmed net profit */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Confirmed net profit</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{formatMoney(executiveSummary.confirmedNetProfitUSD, 'USD')}</div>
                  <div className="text-xs text-slate-500 mt-1">Commenced/completed profit less period overhead.</div>
                </div>

                {/* 4. Projected net profit */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Projected net profit</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{formatMoney(executiveSummary.projectedNetProfitUSD, 'USD')}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    {formatMoney(executiveSummary.confirmedNetProfitUSD, 'USD')} confirmed + {formatMoney(executiveSummary.projectedAdditionalGrossProfitUSD, 'USD')} future.
                  </div>
                </div>

                {/* Period Reporting Actions */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => setPeriodReportMode('gross')}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 text-white hover:bg-amber-600 transition-colors cursor-pointer"
                  >
                    Gross Profit for Period
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodReportMode('net')}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 text-white hover:bg-slate-900 transition-colors cursor-pointer"
                  >
                    Net Agency Profit for Period
                  </button>
                </div>
              </div>

              {/* Modal for Date Selection */}
              {periodReportMode !== null && createPortal(
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
                  <div className="bg-white p-6 rounded-2xl shadow-xl w-96 space-y-4">
                    <h3 className="font-bold text-lg">
                      {periodReportMode === 'gross' ? 'Gross Profit for Period' : 'Net Agency Profit for Period'}
                    </h3>
                    <div className="space-y-2">
                      <label className="text-xs font-bold">Start Date</label>
                      <input type="date" value={customStartDate} onChange={(e) => setCustomStartDate(e.target.value)} className="w-full p-2 border rounded" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold">End Date</label>
                      <input type="date" value={customEndDate} onChange={(e) => setCustomEndDate(e.target.value)} className="w-full p-2 border rounded" />
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                      <button type="button" onClick={() => setPeriodReportMode(null)} className="px-3 py-1 bg-slate-200 rounded cursor-pointer">Cancel</button>
                      <button 
                        type="button" 
                        onClick={() => {
                          if (customStartDate && customEndDate && customEndDate >= customStartDate) {
                            setAppliedPeriod({ mode: periodReportMode, start: customStartDate, end: customEndDate });
                            setPeriodReportMode(null);
                          } else {
                            alert('Please select a valid date range.');
                          }
                        }} 
                        className="px-3 py-1 bg-amber-500 text-white rounded cursor-pointer"
                      >
                        Calculate
                      </button>
                    </div>
                  </div>
                </div>,
                document.body
              )}
            </div>
          )}
          
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Confirmed Bookings
                  </span>
                  <span className="text-xs font-bold text-blue-600">Locked</span>
                </div>
                <div className="text-2xl font-black text-slate-900 mt-1">
                  {supplierBookings.filter((b) => b.status === 'Confirmed' || b.status === 'Voucher Issued').length}
                </div>
                <div className="text-xs text-slate-500 mt-1">Partner suppliers confirmed</div>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Total Tour Days
                  </span>
                  <span className="text-xs font-bold text-emerald-600">Curated</span>
                </div>
                <div className="text-2xl font-black text-slate-900 mt-1">
                  {itineraries.reduce((sum, t) => sum + (t.days?.length || 0), 0)}
                </div>
                <div className="text-xs text-slate-500 mt-1">Full-day activity schedules</div>
              </div>

          {/* Cost Composition Breakdown Notice (Explaining Direct Tour Costs vs General Overhead) */}
          {hasFullFinancialView && (
            <div className="bg-slate-900 text-slate-200 rounded-3xl p-5 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-amber-400 text-slate-950">
                    Supplier Invoice Integration
                  </span>
                  <span className="text-xs font-bold text-white">Full Cost Ledger Active</span>
                </div>
                <p className="text-xs text-slate-300 max-w-2xl">
                  Total management direct costs include the full cost result used by Gross Profit per Tour. Supplier bill ({formatMoney(toursGrossProfitSummary.totalSupplierInvoices, 'USD')}) and direct expense ({formatMoney(toursGrossProfitSummary.totalDirectExpenses, 'USD')}) amounts may appear as subtotals, not as the entire cost basis. General overhead supplier invoices ({formatMoney(executiveSummary.overheadSupplierInvoicesUSD, 'USD')}) are categorized under administrative overhead.
                </p>
              </div>

              <button
                onClick={() => setDashboardTab('tour-gross-profit')}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <span>View Gross Profit per Tour</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Main Visualizations Grid */}
          
          {hasFullFinancialView && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Visual Chart 1: Revenue vs Cost Comparison */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-amber-600" />
                      <span>Financial Composition &amp; Profit Retention</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Proportion of client revenue converted into net operating margin.
                    </p>
                  </div>
                </div>

                {/* Stacked Composition Bar */}
                <div className="space-y-3 pt-2">
                  <div className="h-6 w-full rounded-xl overflow-hidden flex shadow-inner bg-slate-100">
                    <div
                      className="bg-rose-500 transition-all duration-500"
                      title="Direct Tour Costs (Supplier Invoices + Direct Expenses)"
                      style={{ width: `${Math.round((executiveSummary.projectedGrossProfitUSD > 0 ? (executiveSummary.projectedGrossProfitUSD - executiveSummary.projectedNetProfitUSD) / executiveSummary.projectedGrossProfitUSD * 100 : 0))}%` }}
                    />
                    <div
                      style={{ width: `${Math.round((executiveSummary.totalOverheadUSD / (executiveSummary.projectedGrossProfitUSD || 1)) * 100)}%` }}
                      className="bg-slate-700 transition-all duration-500"
                      title="General Corporate Overhead"
                    />
                    <div
                      style={{ width: `${Math.max(0, executiveSummary.projectedNetProfitUSD > 0 ? (executiveSummary.projectedNetProfitUSD / (executiveSummary.projectedGrossProfitUSD || 1)) * 100 : 0)}%` }}
                      className="bg-emerald-500 transition-all duration-500"
                      title="Net Operating Profit"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                    <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                      <span className="text-[10px] font-bold text-rose-800 uppercase block">Direct Costs</span>
                      <span className="font-bold text-rose-950 text-sm">
                        {formatMoney(executiveSummary.projectedGrossProfitUSD - executiveSummary.grossProfitUSD, 'USD')}
                      </span>
                      <span className="text-[10px] text-rose-700 block mt-0.5">
                        % of revenue
                      </span>
                    </div>

                    <div className="p-3 bg-slate-100 rounded-xl border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-700 uppercase block">Overhead</span>
                      <span className="font-bold text-slate-900 text-sm">
                        {formatMoney(executiveSummary.totalOverheadUSD, 'USD')}
                      </span>
                      <span className="text-[10px] text-slate-600 block mt-0.5">
                        {Math.round((executiveSummary.totalOverheadUSD / (executiveSummary.projectedGrossProfitUSD || 1)) * 100)}% of revenue
                      </span>
                      <span className="text-[9px] text-slate-500 block mt-0.5">
                        Bills: {formatMoney(executiveSummary.overheadSupplierInvoicesUSD, 'USD')}
                      </span>
                    </div>

                    <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                      <span className="text-[10px] font-bold text-emerald-800 uppercase block">Net Margin</span>
                      <span className="font-bold text-emerald-950 text-sm">
                        {formatMoney(executiveSummary.projectedNetProfitUSD, 'USD')}
                      </span>
                      <span className="text-[10px] text-emerald-700 block mt-0.5">
                        {Math.round((executiveSummary.projectedNetProfitUSD / (executiveSummary.projectedGrossProfitUSD || 1)) * 100)}% net retention
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Visual Chart 2: Expenditure by Category */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <PieChart className="w-4 h-4 text-amber-600" />
                      <span>Operational Spend by Category</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Distribution across accommodations, private guides, yachts, fleet, and admin.
                    </p>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  {categoryEntries.slice(0, 5).map(([category, amount]) => {
                    const pct = Math.round((amount / (maxCategorySpend || 1)) * 100);

                    return (
                      <div key={category} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-semibold text-slate-800">{category}</span>
                          <span className="font-mono font-bold text-slate-900">
                            {formatMoney(amount, 'USD')}
                          </span>
                        </div>
                        <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-500 rounded-full transition-all duration-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Pipeline Stages & Lone Provider Monitoring */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-600" />
                <span>Itinerary Pipeline Stages</span>
              </h3>

              <div className="space-y-2.5">
                {['Confirmed', 'In Progress', 'Proposed', 'Draft', 'Completed'].map((stage) => {
                  const count = statusCounts[stage] || 0;
                  return (
                    <div
                      key={stage}
                      className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs"
                    >
                      <span className="font-semibold text-slate-800">{stage}</span>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900">{count} Tours</span>
                        <span className="text-slate-400">
                          ({Math.round((count / (itineraries.length || 1)) * 100)}%)
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-600" />
                    <span>Lone Provider Capacity &amp; Booking Allocation</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Exclusive specialist guides and private vessels can only service 1 client at a time.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {loneSuppliers.map((ls) => {
                  const assignedBookings = supplierBookings.filter(
                    (b) => b.supplierId === ls.id && b.status !== 'Cancelled'
                  );

                  return (
                    <div
                      key={ls.id}
                      className="p-4 rounded-2xl bg-amber-50/40 border border-amber-200 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{ls.name}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900">
                          {assignedBookings.length} Active {assignedBookings.length === 1 ? 'Date' : 'Dates'}
                        </span>
                      </div>
                      <div className="text-amber-900 font-medium text-[11px]">{ls.loneProviderType}</div>
                      <div className="text-slate-600 text-[11px]">
                        City: {ls.city} &bull; Rating: {ls.rating}&#9733;
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

      )}
      {currentDashboardTab === 'tour-gross-profit' && (
        <div className="space-y-6">
          {/* Summary KPI Cards across all tours */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Total Tour Gross Profit
              </span>
              <div className="text-2xl font-black text-emerald-700 mt-1">
                {formatMoney(toursGrossProfitSummary.totalToursGrossProfit, 'USD')}
              </div>
              <div className="text-xs text-slate-500 mt-1">
                From {itineraries.length} active registered tours
              </div>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Average Tour Gross Margin
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">
                {toursGrossProfitSummary.avgTourGrossMargin}%
              </div>
              <div className="text-xs text-slate-500 mt-1">
                Target threshold: &gt; 35% margin
              </div>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Total Direct Tour Costs
              </span>
              <div className="text-2xl font-black text-rose-700 mt-1">
                {formatMoney(toursGrossProfitSummary.totalToursCosts, 'USD')}
              </div>
              <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
                <span>Bills: {formatMoney(toursGrossProfitSummary.totalSupplierInvoices, 'USD')}</span>
                <span>Expenses: {formatMoney(toursGrossProfitSummary.totalDirectExpenses, 'USD')}</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-3xl shadow-md border border-slate-800">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block">
                Top Performing Tour
              </span>
              {toursGrossProfitSummary.topTour ? (
                <>
                  <div className="text-lg font-black text-white mt-1 truncate">
                    {toursGrossProfitSummary.topTour.tour.tourName || toursGrossProfitSummary.topTour.tour.title}
                  </div>
                  <div className="text-xs text-emerald-400 font-bold mt-1">
                    {formatMoney(toursGrossProfitSummary.topTour.grossProfitUSD, 'USD')} profit ({toursGrossProfitSummary.topTour.grossMarginPercent}%)
                  </div>
                </>
              ) : (
                <div className="text-sm text-slate-400 mt-2">No tour data available</div>
              )}
            </div>
          </div>

          {/* Search, Filter & Sort Toolbar */}
          <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center flex-wrap gap-2.5 flex-1">
              {/* Search Bar */}
              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search by tour name, tour code, client, destination..."
                  value={tourSearchQuery}
                  onChange={(e) => setTourSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white outline-none"
                />
              </div>

              {/* Status Filter */}
              <select
                value={tourStatusFilter}
                onChange={(e) => setTourStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700 outline-none cursor-pointer"
              >
                <option value="ALL">All Eligible Statuses</option>
                <option value="Confirmed">Confirmed</option>
                <option value="In Progress">In Progress</option>
                <option value="completed but not cost reconciled">Completed (not cost reconciled)</option>
                <option value="completed and reconciled">Completed and reconciled</option>
              </select>

              {/* Sort By */}
              <select
                value={tourSortBy}
                onChange={(e) => setTourSortBy(e.target.value as any)}
                className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none cursor-pointer"
              >
                <option value="profit-desc">Sort: Highest Gross Profit ($)</option>
                <option value="margin-desc">Sort: Highest Gross Margin (%)</option>
                <option value="revenue-desc">Sort: Highest Tour Revenue ($)</option>
                <option value="date-asc">Sort: Departure Date (Earliest)</option>
              </select>

              {(tourSearchQuery || tourStatusFilter !== 'ALL') && (
                <button
                  onClick={() => {
                    setTourSearchQuery('');
                    setTourStatusFilter('ALL');
                  }}
                  className="text-xs text-amber-700 font-bold hover:underline cursor-pointer"
                >
                  Reset
                </button>
              )}
            </div>

            <div className="text-xs text-slate-500 font-medium shrink-0">
              Showing {filteredToursGrossProfit.length} of {itineraries.length} tours &bull; Click any tour for full breakdown
            </div>
          </div>

          {/* Table / List of Tours with Gross Profit & Margins */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50/80 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="px-5 py-3.5">Tour Name &amp; Code</th>
                    <th className="px-4 py-3.5">Client &amp; Destination</th>
                    <th className="px-4 py-3.5">Dates / Status</th>
                    <th className="px-4 py-3.5 text-right">Revenue (USD)</th>
                    <th className="px-4 py-3.5 text-right">Supplier Bills</th>
                    <th className="px-4 py-3.5 text-right">Direct Expenses</th>
                    <th className="px-4 py-3.5 text-right">Total Direct Cost</th>
                    <th className="px-4 py-3.5 text-right">Gross Profit</th>
                    <th className="px-4 py-3.5 text-right">Gross Margin</th>
                    <th className="px-4 py-3.5 text-center">Action</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredToursGrossProfit.map((item) => {
                    const isProposedPreInvoice = item.isProposed && !item.hasActualBills;
                    const profitValue = isProposedPreInvoice ? item.displayedProfitUSD : item.grossProfitUSD;
                    const isProfitable = profitValue >= 0;
                    const margin = isProposedPreInvoice ? item.displayedMarginPercent : item.grossMarginPercent;
                    const isSelected = selectedTourForBreakdown === item.tour.id;

                    return (
                      <tr
                        key={item.tour.id}
                        onClick={() => setSelectedTourForBreakdown(item.tour.id)}
                        className={`hover:bg-amber-50/40 transition-colors cursor-pointer ${
                          isSelected ? 'bg-amber-50/80 ring-2 ring-inset ring-amber-400' : ''
                        }`}
                      >
                        {/* Tour Name & Code */}
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-900 text-amber-400 shrink-0">
                              {item.tour.code}
                            </span>
                          </div>
                          <div className="font-extrabold text-slate-900 text-sm mt-1 max-w-xs line-clamp-1">
                            {item.tour.tourName || item.tour.title}
                          </div>
                          <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                            {item.tour.title}
                          </div>
                        </td>

                        {/* Client & Destination */}
                        <td className="px-4 py-4">
                          <div className="font-bold text-slate-800 flex items-center gap-1">
                            <Users className="w-3.5 h-3.5 text-slate-400" />
                            <span>{item.client?.name || 'Assigned Client'}</span>
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            <span>{item.tour.destination}</span>
                          </div>
                        </td>

                        {/* Dates & Status */}
                        <td className="px-4 py-4">
                          <div className="text-slate-800 font-medium">
                            {item.tour.startDate} &rarr; {item.tour.endDate}
                          </div>
                          <span
                            className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                              item.tour.status === 'Confirmed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.tour.status === 'In Progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {item.tour.status}
                          </span>
                        </td>

                        {/* Revenue */}
                        <td className="px-4 py-4 text-right">
                          <div className="font-extrabold text-slate-900 text-sm">
                            {formatMoney(item.effectiveRevenueUSD, 'USD')}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {item.totalInvoicedUSD > 0 ? 'Invoiced' : 'Package Price'}
                          </div>
                        </td>

                        {/* Supplier Bills */}
                        <td className="px-4 py-4 text-right">
                          <div className="font-bold text-slate-800">
                            {formatMoney(item.supplierInvoicesUSD, 'USD')}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {item.supplierInvoicesCount} {item.supplierInvoicesCount === 1 ? 'bill' : 'bills'}
                            {item.supplierCreditsUSD > 0 && ` (-${formatMoney(item.supplierCreditsUSD, 'USD')} cr)`}
                          </div>
                        </td>

                        {/* Direct Expenses */}
                        <td className="px-4 py-4 text-right">
                          <div className="font-bold text-slate-700">
                            {formatMoney(item.directExpensesUSD, 'USD')}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {item.directExpensesCount} {item.directExpensesCount === 1 ? 'item' : 'items'}
                          </div>
                        </td>

                        {/* Total Cost (Actual Invoiced or Projected) */}
                        <td className="px-4 py-4 text-right">
                          <div className={`font-extrabold ${isProposedPreInvoice ? 'text-amber-800' : 'text-rose-700'}`}>
                            {formatMoney(item.displayedCostUSD, 'USD')}
                          </div>
                          <div className="text-[10px] mt-0.5">
                            {isProposedPreInvoice ? (
                              <span className="px-1.5 py-0.2 rounded font-black text-[9px] bg-amber-100 text-amber-900 uppercase">
                                Projected (Quote)
                              </span>
                            ) : item.effectiveRevenueUSD > 0 ? (
                              <span className="text-slate-400">
                                {Math.round((item.totalDirectCostsUSD / item.effectiveRevenueUSD) * 100)}% of rev
                              </span>
                            ) : (
                              <span className="text-slate-400">0%</span>
                            )}
                          </div>
                        </td>

                        {/* Gross Profit ($) */}
                        <td className="px-4 py-4 text-right">
                          <div
                            className={`font-black text-sm ${
                              isProfitable ? 'text-emerald-700' : 'text-rose-700'
                            }`}
                          >
                            {isProfitable ? '+' : ''}{formatMoney(profitValue, 'USD')}
                          </div>
                          <div className="text-[10px] font-semibold mt-0.5">
                            {isProposedPreInvoice ? (
                              <span className="text-amber-800 font-bold">Projected Profit</span>
                            ) : (
                              <span className="text-slate-400">{isProfitable ? 'Gross Profit' : 'Gross Loss'}</span>
                            )}
                          </div>
                        </td>

                        {/* Gross Margin (%) */}
                        <td className="px-4 py-4 text-right">
                          <div
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black ${
                              margin >= 35
                                ? 'bg-emerald-100 text-emerald-800'
                                : margin >= 20
                                ? 'bg-amber-100 text-amber-800'
                                : margin > 0
                                ? 'bg-orange-100 text-orange-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {margin}%
                          </div>
                          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden ml-auto mt-1">
                            <div
                              className={`h-full rounded-full ${
                                margin >= 35
                                  ? 'bg-emerald-500'
                                  : margin >= 20
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${Math.max(0, Math.min(100, margin))}%` }}
                            />
                          </div>
                        </td>

                        {/* Action CTA */}
                        <td className="px-4 py-4 text-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedTourForBreakdown(item.tour.id);
                            }}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
                            title="View tour gross profit breakdown"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredToursGrossProfit.length === 0 && (
              <div className="p-12 text-center space-y-3">
                <Compass className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="text-base font-bold text-slate-900">No matching tours found</h4>
                <p className="text-xs text-slate-500">
                  Try adjusting your search criteria or resetting filters to see all tour gross profit reports.
                </p>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* DETAILED TOUR GROSS PROFIT SLIDE-OVER / MODAL BREAKDOWN */}
          {/* ========================================================= */}
          {activeBreakdownTour && (
            <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 space-y-6 max-h-[90vh] overflow-y-auto animate-fade-in">
                {/* Header */}
                <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-slate-900 text-amber-400">
                        {activeBreakdownTour.tour.code}
                      </span>
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        Gross Profit Analysis
                      </span>
                    </div>
                    <h2 className="text-xl font-black text-slate-900">
                      {activeBreakdownTour.tour.tourName || activeBreakdownTour.tour.title}
                    </h2>
                    <p className="text-xs text-slate-500 flex items-center gap-2">
                      <span>Client: <strong>{activeBreakdownTour.client?.name || 'Unassigned'}</strong></span>
                      <span>&bull;</span>
                      <span>Destination: <strong>{activeBreakdownTour.tour.destination}</strong></span>
                      <span>&bull;</span>
                      <span>Dates: <strong>{activeBreakdownTour.tour.startDate} &rarr; {activeBreakdownTour.tour.endDate}</strong></span>
                    </p>
                  </div>

                  <button
                    onClick={() => setSelectedTourForBreakdown(null)}
                    className="p-1 text-slate-400 hover:text-slate-600 rounded-lg text-xl cursor-pointer"
                  >
                    &times;
                  </button>
                </div>

                {/* KPI Summary Row for this specific tour */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Tour Revenue</span>
                    <span className="text-lg font-black text-slate-900 block mt-0.5">
                      {formatMoney(activeBreakdownTour.effectiveRevenueUSD, 'USD')}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {activeBreakdownTour.totalInvoicedUSD > 0 ? 'Client Invoiced' : 'Catalog Package'}
                    </span>
                  </div>

                  <div className="p-3.5 bg-rose-50 rounded-2xl border border-rose-100">
                    <span className="text-[10px] font-bold text-rose-800 uppercase block">Total Direct Costs</span>
                    <span className="text-lg font-black text-rose-950 block mt-0.5">
                      {formatMoney(activeBreakdownTour.totalDirectCostsUSD, 'USD')}
                    </span>
                    <span className="text-[10px] text-rose-700">
                      Bills + Direct Expenses
                    </span>
                  </div>

                  <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-100">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase block">Gross Profit</span>
                    <span className="text-lg font-black text-emerald-950 block mt-0.5">
                      {formatMoney(activeBreakdownTour.grossProfitUSD, 'USD')}
                    </span>
                    <span className="text-[10px] text-emerald-700">
                      Net retainable
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-900 text-white rounded-2xl">
                    <span className="text-[10px] font-bold text-amber-400 uppercase block">Gross Margin</span>
                    <span className="text-lg font-black text-white block mt-0.5">
                      {activeBreakdownTour.grossMarginPercent}%
                    </span>
                    <span className="text-[10px] text-slate-300">
                      {activeBreakdownTour.grossMarginPercent >= 35 ? 'Above target' : 'Below target'}
                    </span>
                  </div>
                </div>

                {/* Itemized Supplier Invoices Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Receipt className="w-4 h-4 text-amber-600" />
                      <span>Assigned Supplier Invoices &amp; Vendor Credits ({activeBreakdownTour.tourSupplierInvoices.length})</span>
                    </h3>
                    <span className="text-xs font-extrabold text-slate-800">
                      Net: {formatMoney(activeBreakdownTour.supplierInvoicesUSD, 'USD')}
                    </span>
                  </div>

                  {activeBreakdownTour.tourSupplierInvoices.length > 0 ? (
                    <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
                      {activeBreakdownTour.tourSupplierInvoices.map((inv) => {
                        const sup = suppliers.find((s) => s.id === inv.supplierId);
                        const invUSD = convertCurrency(inv.amount, inv.currency, 'USD');

                        return (
                          <div key={inv.id} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-slate-900">{inv.invoiceNumber}</span>
                                {inv.isCredit && (
                                  <span className="px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-emerald-100 text-emerald-800">
                                    Supplier Credit
                                  </span>
                                )}
                                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-slate-100 text-slate-700">
                                  {inv.status}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-600 font-medium">
                                {sup?.name || 'Vendor'} &bull; {inv.description}
                              </div>
                              <div className="text-[10px] text-slate-400">
                                Issue Date: {inv.issueDate} &bull; Due Date: {inv.dueDate}
                              </div>
                            </div>

                            <div className="text-right">
                              <div className={`font-black text-sm ${inv.isCredit ? 'text-emerald-700' : 'text-slate-900'}`}>
                                {inv.isCredit ? '-' : ''}{formatMoney(inv.amount, inv.currency)}
                              </div>
                              {inv.currency !== 'USD' && (
                                <div className="text-[10px] text-slate-400 font-semibold">
                                  ≈ {inv.isCredit ? '-' : ''}${invUSD.toLocaleString()} USD
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-slate-50 text-slate-500 text-xs text-center border border-slate-100">
                      No supplier invoices assigned to this tour yet. You can add one in the Tour Operations Hub or Supplier Invoices desk.
                    </div>
                  )}
                </div>

                {/* Itemized Direct Expenses Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-rose-600" />
                      <span>Direct Project Expenses ({activeBreakdownTour.tourExpenses.length})</span>
                    </h3>
                    <span className="text-xs font-extrabold text-slate-800">
                      Total: {formatMoney(activeBreakdownTour.directExpensesUSD, 'USD')}
                    </span>
                  </div>

                  {activeBreakdownTour.tourExpenses.length > 0 ? (
                    <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
                      {activeBreakdownTour.tourExpenses.map((exp) => (
                        <div key={exp.id} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                          <div>
                            <div className="font-bold text-slate-900">{exp.title}</div>
                            <div className="text-[11px] text-slate-500">
                              {exp.category} &bull; {exp.date} &bull; {exp.paymentMethod}
                            </div>
                          </div>
                          <div className="font-bold text-slate-900 text-sm">
                            {formatMoney(exp.amount, exp.currency)}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-slate-50 text-slate-500 text-xs text-center border border-slate-100">
                      No ad-hoc direct project expenses logged for this tour.
                    </div>
                  )}
                </div>

                {/* Modal Footer with 1-Click Navigation to Tour Operations Workspace */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <button
                    onClick={() => setSelectedTourForBreakdown(null)}
                    className="px-4 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Close Breakdown
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedTripId(activeBreakdownTour.tour.id);
                        setActiveView('tour-management');
                      }}
                      className="px-4 py-2 bg-slate-900 hover:bg-black text-amber-400 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>Open Tour Operations &amp; Running P&amp;L Hub</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

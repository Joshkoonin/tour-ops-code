import React, { useState, useMemo } from 'react';
import {
  FileText,
  Calendar,
  Printer,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Receipt,
  Building,
  Filter,
  CheckCircle2,
  ChevronDown,
  Percent,
  Download,
  Layers,
  ArrowRight,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, Invoice, SupplierInvoice, Expense } from '../../types';
import { isTourEligibleForProfitReporting, getTourContractRevenue, calculateManagementDirectCostsForTour } from '../../utils/financialCalculations';

export const GlobalPnLStatement: React.FC = () => {
  const {
    invoices,
    supplierInvoices,
    expenses,
    itineraries,
    clients,
    suppliers,
    convertCurrency,
    formatMoney,
    hasFullFinancialView,
    companyLogo,
  } = useApp();

  // Time Period Settings
  const [periodMode, setPeriodMode] = useState<'1-month' | '2-months'>('2-months');
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [selectedStartMonth, setSelectedStartMonth] = useState<number>(9); // 1 = Jan, 9 = Sept, 10 = Oct

  // Available Years
  const availableYears = [2026, 2025, 2024];

  // Month names
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  // Compute exact Date Range (YYYY-MM-DD)
  const { startDateStr, endDateStr, periodLabel } = useMemo(() => {
    const startM = selectedStartMonth;
    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);

    const startDate = `${selectedYear}-${pad(startM)}-01`;

    let endM = startM;
    let endYear = selectedYear;

    if (periodMode === '2-months') {
      endM = startM + 1;
      if (endM > 12) {
        endM = 1;
        endYear = selectedYear + 1;
      }
    }

    // Days in end month
    const daysInEndMonth = new Date(endYear, endM, 0).getDate();
    const endDate = `${endYear}-${pad(endM)}-${pad(daysInEndMonth)}`;

    const label =
      periodMode === '1-month'
        ? `${monthNames[startM - 1]} ${selectedYear}`
        : `${monthNames[startM - 1]} – ${monthNames[endM - 1]} ${selectedYear} (2 Calendar Months)`;

    return {
      startDateStr: startDate,
      endDateStr: endDate,
      periodLabel: label,
    };
  }, [periodMode, selectedYear, selectedStartMonth]);

  // 1. FILTER CLIENT INVOICES & CREDITS BY ISSUE DATE AND TRIP STATUS
  const periodClientInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const trip = itineraries.find(t => t.id === inv.tripId);
      if (trip && !isTourEligibleForProfitReporting(trip)) return false;
      return inv.issueDate >= startDateStr && inv.issueDate <= endDateStr;
    });
  }, [invoices, itineraries, startDateStr, endDateStr]);

  const grossInvoicedRevenueUSD = periodClientInvoices
    .filter((inv) => !inv.isCreditNote)
    .reduce((sum, inv) => sum + convertCurrency(inv.totalAmount, inv.currency, 'USD'), 0);

  const clientCreditNotesUSD = periodClientInvoices
    .filter((inv) => inv.isCreditNote)
    .reduce((sum, inv) => sum + convertCurrency(inv.totalAmount, inv.currency, 'USD'), 0);

  // 1b. TOTAL AGREED REVENUE FOR ELIGIBLE TOURS IN PERIOD
  const netOperatingRevenueUSD = useMemo(() => {
    return itineraries
      .filter((t) => isTourEligibleForProfitReporting(t) && t.startDate >= startDateStr && t.startDate <= endDateStr)
      .reduce((sum, t) => sum + convertCurrency(getTourContractRevenue(t), t.currency, 'USD'), 0);
  }, [itineraries, convertCurrency, startDateStr, endDateStr]);

  // Actual cash collections in this period (payments dated in period)
  const cashPaymentsCollectedUSD = useMemo(() => {
    let total = 0;
    invoices.forEach((inv) => {
      const trip = itineraries.find(t => t.id === inv.tripId);
      if (trip && !isTourEligibleForProfitReporting(trip)) return;
      inv.payments?.forEach((p) => {
        if (p.date >= startDateStr && p.date <= endDateStr) {
          total += convertCurrency(p.amount, p.currency, 'USD');
        }
      });
    });
    return total;
  }, [invoices, itineraries, startDateStr, endDateStr]);

  // 2. FILTER SUPPLIER INVOICES & CREDITS BY ISSUE DATE AND TRIP STATUS
  const periodSupplierInvoices = useMemo(() => {
    return supplierInvoices.filter((inv) => {
      const trip = itineraries.find(t => t.id === inv.tripId);
      if (trip && !isTourEligibleForProfitReporting(trip)) return false;
      return inv.issueDate >= startDateStr && inv.issueDate <= endDateStr;
    });
  }, [supplierInvoices, itineraries, startDateStr, endDateStr]);

  // Direct Tour Supplier Invoices (Cost of Sales)
  const periodDirectSupplierInvoices = useMemo(() => {
    return periodSupplierInvoices.filter(
      (inv) => !inv.isGeneralOverhead && inv.tripId && inv.tripId !== 'general-overhead'
    );
  }, [periodSupplierInvoices]);

  const grossDirectSupplierBillsUSD = periodDirectSupplierInvoices
    .filter((inv) => !inv.isCredit)
    .reduce((sum, inv) => sum + convertCurrency(inv.amount, inv.currency, 'USD'), 0);

  const directSupplierCreditsUSD = periodDirectSupplierInvoices
    .filter((inv) => inv.isCredit)
    .reduce((sum, inv) => sum + convertCurrency(inv.amount, inv.currency, 'USD'), 0);

  const netDirectSupplierCostUSD = grossDirectSupplierBillsUSD - directSupplierCreditsUSD;

  // General Overhead Supplier Invoices (Operating Expenses)
  const periodOverheadSupplierInvoices = useMemo(() => {
    return periodSupplierInvoices.filter(
      (inv) => inv.isGeneralOverhead || !inv.tripId || inv.tripId === 'general-overhead'
    );
  }, [periodSupplierInvoices]);

  const overheadSupplierInvoicesUSD = periodOverheadSupplierInvoices.reduce((sum, inv) => {
    const usd = convertCurrency(inv.amount, inv.currency, 'USD');
    return inv.isCredit ? sum - usd : sum + usd;
  }, 0);

  const totalPeriodSupplierNetUSD = netDirectSupplierCostUSD + overheadSupplierInvoicesUSD;

  // 3. FILTER DIRECT PROJECT EXPENSES DATED IN PERIOD AND TRIP STATUS
  const periodDirectExpenses = useMemo(() => {
    return expenses.filter((e) => {
      const trip = e.tripId ? itineraries.find(t => t.id === e.tripId) : null;
      if (trip && !isTourEligibleForProfitReporting(trip)) return false;
      return !e.isGeneralOverhead && e.date >= startDateStr && e.date <= endDateStr;
    });
  }, [expenses, itineraries, startDateStr, endDateStr]);

  const directExpensesCostUSD = periodDirectExpenses.reduce(
    (sum, e) => sum + convertCurrency(e.amount, e.currency, 'USD'),
    0
  );

  // TOTAL COST OF SALES / DIRECT COSTS (Eligible Tour-linked costs based on Start Date + Direct Expenses)
  const totalCostOfSalesUSD = useMemo(() => {
    const eligibleTours = itineraries.filter(t => isTourEligibleForProfitReporting(t) && t.startDate >= startDateStr && t.startDate <= endDateStr);
    
    const tourLinkedCosts = eligibleTours.reduce((sum, tour) => {
      return sum + calculateManagementDirectCostsForTour(tour, supplierInvoices, expenses, convertCurrency, 'USD');
    }, 0);
    
    // Add expenses not linked to any tour (e.g. general tour-direct expenses)
    const unlinkedDirectExpenses = expenses.filter(e => !e.isGeneralOverhead && !e.tripId && e.date >= startDateStr && e.date <= endDateStr);
    const unlinkedDirectExpensesUSD = unlinkedDirectExpenses.reduce((sum, e) => sum + convertCurrency(e.amount, e.currency, 'USD'), 0);
    
    return tourLinkedCosts + unlinkedDirectExpensesUSD;
  }, [itineraries, supplierInvoices, expenses, convertCurrency, startDateStr, endDateStr]);

  // GROSS PROFIT
  const grossProfitUSD = netOperatingRevenueUSD - totalCostOfSalesUSD;
  const grossProfitMarginPercent =
    netOperatingRevenueUSD > 0
      ? Math.round((grossProfitUSD / netOperatingRevenueUSD) * 1000) / 10
      : 0;

  // 4. FILTER GENERAL OPERATING OVERHEAD EXPENSES DATED IN PERIOD
  const periodOverheadExpenses = useMemo(() => {
    return expenses.filter((e) => {
      return e.isGeneralOverhead && e.date >= startDateStr && e.date <= endDateStr;
    });
  }, [expenses, startDateStr, endDateStr]);

  const overheadExpensesCostUSD = periodOverheadExpenses.reduce(
    (sum, e) => sum + convertCurrency(e.amount, e.currency, 'USD'),
    0
  );

  // Total Operating Overhead (Expenses + Overhead Supplier Bills)
  const totalOverheadExpensesUSD = overheadExpensesCostUSD + overheadSupplierInvoicesUSD;

  // NET PROFIT / (LOSS)
  const netProfitUSD = grossProfitUSD - totalOverheadExpensesUSD;
  const netProfitMarginPercent =
    netOperatingRevenueUSD > 0
      ? Math.round((netProfitUSD / netOperatingRevenueUSD) * 1000) / 10
      : 0;

  // Expense categories breakdown for period
  const costsByCategory = useMemo(() => {
    const map: Record<string, number> = {};

    // From supplier invoices
    periodSupplierInvoices.forEach((inv) => {
      const sup = suppliers.find((s) => s.id === inv.supplierId);
      const cat = sup ? `Supplier: ${sup.category}` : 'Supplier Services';
      const usd = convertCurrency(inv.amount, inv.currency, 'USD') * (inv.isCredit ? -1 : 1);
      map[cat] = (map[cat] || 0) + usd;
    });

    // From direct expenses
    periodDirectExpenses.forEach((exp) => {
      const usd = convertCurrency(exp.amount, exp.currency, 'USD');
      map[exp.category] = (map[exp.category] || 0) + usd;
    });

    return map;
  }, [periodSupplierInvoices, periodDirectExpenses, suppliers, convertCurrency]);

  const [activeTab, setActiveTab] = useState<'statement' | 'revenue-schedule' | 'supplier-schedule' | 'overhead-schedule'>('statement');

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100 text-amber-900 flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span>Financial Intelligence</span>
            </span>
            <span className="text-xs text-slate-500 font-medium">Database-Wide P&amp;L Engine</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            Global Profit &amp; Loss Statement
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Accrual-based statement generated across all database records by date of invoices and credits.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            onClick={() => window.print()}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Financial Statement</span>
          </button>
        </div>
      </div>

      {/* Period Selection Controls */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Mode Switcher */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Statement Period:</span>
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setPeriodMode('1-month')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  periodMode === '1-month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1 Calendar Month
              </button>
              <button
                onClick={() => setPeriodMode('2-months')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  periodMode === '2-months' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2 Calendar Months
              </button>
            </div>
          </div>

          {/* Month & Year Selectors */}
          <div className="flex items-center flex-wrap gap-3">
            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                {periodMode === '2-months' ? 'Starting Month' : 'Calendar Month'}
              </label>
              <select
                value={selectedStartMonth}
                onChange={(e) => setSelectedStartMonth(Number(e.target.value))}
                className="px-3 py-1.5 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl text-slate-800 outline-none cursor-pointer"
              >
                {monthNames.map((m, idx) => (
                  <option key={idx + 1} value={idx + 1}>
                    {m}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">Year</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="px-3 py-1.5 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl text-slate-800 outline-none cursor-pointer"
              >
                {availableYears.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>

            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-950 text-xs font-bold flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-amber-600" />
              <span>
                {startDateStr} &rarr; {endDateStr}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Net Operating Revenue */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider">Net Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">
            ${netOperatingRevenueUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex justify-between pt-2 border-t border-slate-100">
            <span>Gross Invoiced:</span>
            <span className="font-bold text-slate-900">${grossInvoicedRevenueUSD.toLocaleString()}</span>
          </div>
          <div className="text-[11px] text-red-600 flex justify-between">
            <span>Credit Notes Deducted:</span>
            <span>-${clientCreditNotesUSD.toLocaleString()}</span>
          </div>
        </div>

        {/* KPI 2: Cost of Sales */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider">Direct Tour Costs</span>
            <Receipt className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">
            ${totalCostOfSalesUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex justify-between pt-2 border-t border-slate-100">
            <span>Direct Tour Supplier Invoices Net:</span>
            <span className="font-bold text-slate-900">${netDirectSupplierCostUSD.toLocaleString()}</span>
          </div>
          <div className="text-[11px] text-slate-500 flex justify-between">
            <span>Direct Project Expenses:</span>
            <span>${directExpensesCostUSD.toLocaleString()}</span>
          </div>
        </div>

        {/* KPI 3: Gross Profit */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider">Gross Profit</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div
            className={`text-2xl font-black ${
              grossProfitUSD >= 0 ? 'text-emerald-700' : 'text-red-600'
            }`}
          >
            ${grossProfitUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex justify-between pt-2 border-t border-slate-100">
            <span>Gross Margin:</span>
            <span className="font-extrabold text-emerald-700">{grossProfitMarginPercent}%</span>
          </div>
          <div className="text-[11px] text-slate-500 flex justify-between">
            <span>Period Cash Collections:</span>
            <span className="font-semibold text-slate-700">${cashPaymentsCollectedUSD.toLocaleString()}</span>
          </div>
        </div>

        {/* KPI 4: Net Profit */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider">Net Profit</span>
            <Percent className="w-4 h-4 text-blue-600" />
          </div>
          <div
            className={`text-2xl font-black ${
              netProfitUSD >= 0 ? 'text-blue-700' : 'text-red-600'
            }`}
          >
            ${netProfitUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 flex justify-between pt-2 border-t border-slate-100">
            <span>Overhead Costs:</span>
            <span className="font-bold text-slate-900">${totalOverheadExpensesUSD.toLocaleString()}</span>
          </div>
          <div className="text-[11px] text-slate-500 flex justify-between">
            <span>Net Margin:</span>
            <span className="font-extrabold text-blue-700">{netProfitMarginPercent}%</span>
          </div>
        </div>
      </div>

      {/* Tab Selectors */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('statement')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all cursor-pointer ${
            activeTab === 'statement'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Executive Financial Statement
        </button>
        <button
          onClick={() => setActiveTab('revenue-schedule')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'revenue-schedule'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Schedule A: Client Invoices &amp; Credits</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-100 text-slate-700">
            {periodClientInvoices.length}
          </span>
        </button>
        <button
          onClick={() => setActiveTab('supplier-schedule')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'supplier-schedule'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Schedule B: Supplier Invoices &amp; Direct Costs</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-100 text-slate-700">
            {periodSupplierInvoices.length}
          </span>
        </button>
        <button
          onClick={() => setActiveTab('overhead-schedule')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'overhead-schedule'
              ? 'border-amber-600 text-amber-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Schedule C: Overhead Expenses</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-100 text-slate-700">
            {periodOverheadExpenses.length}
          </span>
        </button>
      </div>

      {/* TAB 1: FORMAL EXECUTIVE FINANCIAL STATEMENT */}
      {activeTab === 'statement' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6 print:border-none print:shadow-none print:p-0">
          {/* Statement Header */}
          <div className="border-b-2 border-slate-900 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xl font-black tracking-tight text-slate-950 uppercase">
                TourOps 360 &bull; Private Travel Operations
              </div>
              <h2 className="text-lg font-serif-display font-extrabold text-slate-800 mt-1">
                Statement of Profit and Loss
              </h2>
              <div className="text-xs font-bold text-amber-800 mt-0.5">
                For the Period: {periodLabel}
              </div>
              <div className="text-[11px] text-slate-400">
                Inclusive Date Filter: {startDateStr} through {endDateStr} &bull; Currency: USD Equivalent
              </div>
            </div>

            {companyLogo && (
              <img src={companyLogo} alt="Logo" className="h-12 w-auto object-contain shrink-0" />
            )}
          </div>

          {/* Master Accounting Table */}
          <div className="space-y-6 text-xs">
            {/* 1. Operating Revenue */}
            <div className="space-y-1.5">
              <div className="font-extrabold text-slate-900 uppercase tracking-wider text-xs flex justify-between border-b border-slate-300 pb-1">
                <span>Operating Revenue</span>
                <span>USD</span>
              </div>
              <div className="flex justify-between pl-4 py-1 text-slate-700">
                <span>Gross Invoiced Tour Billing (Schedule A)</span>
                <span className="font-mono font-medium">${grossInvoicedRevenueUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pl-4 py-1 text-red-600">
                <span>Less: Client Credit Notes &amp; Concessions</span>
                <span className="font-mono font-medium">(${clientCreditNotesUSD.toLocaleString()})</span>
              </div>
              <div className="flex justify-between font-extrabold text-slate-900 pt-1.5 border-t border-slate-200 bg-slate-50/70 px-2 py-1.5 rounded-lg">
                <span>Total Net Operating Revenue</span>
                <span className="font-mono text-sm">${netOperatingRevenueUSD.toLocaleString()}</span>
              </div>
            </div>

            {/* 2. Cost of Goods Sold (Direct Costs) */}
            <div className="space-y-1.5">
              <div className="font-extrabold text-slate-900 uppercase tracking-wider text-xs flex justify-between border-b border-slate-300 pb-1">
                <span>Cost of Sales &amp; Direct Tour Costs</span>
                <span>USD</span>
              </div>
              <div className="flex justify-between pl-4 py-1 text-slate-700">
                <span>Gross Direct Tour Supplier Invoices (Schedule B)</span>
                <span className="font-mono font-medium">${grossDirectSupplierBillsUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pl-4 py-1 text-emerald-700">
                <span>Less: Direct Tour Vendor Credit Notes &amp; Refunds</span>
                <span className="font-mono font-medium">(${directSupplierCreditsUSD.toLocaleString()})</span>
              </div>
              <div className="flex justify-between pl-4 py-1 text-slate-700">
                <span>Direct Tour Logistics &amp; Field Disbursements</span>
                <span className="font-mono font-medium">${directExpensesCostUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-extrabold text-slate-900 pt-1.5 border-t border-slate-200 bg-slate-50/70 px-2 py-1.5 rounded-lg">
                <span>Total Cost of Sales</span>
                <span className="font-mono text-sm">${totalCostOfSalesUSD.toLocaleString()}</span>
              </div>
            </div>

            {/* Gross Profit Subtotal */}
            <div className="flex justify-between font-extrabold text-sm text-slate-950 py-2.5 px-3 bg-emerald-50/80 border border-emerald-200 rounded-xl">
              <span>GROSS PROFIT (Gross Margin: {grossProfitMarginPercent}%)</span>
              <span className="font-mono">${grossProfitUSD.toLocaleString()}</span>
            </div>

            {/* 3. Operating Overheads */}
            <div className="space-y-1.5">
              <div className="font-extrabold text-slate-900 uppercase tracking-wider text-xs flex justify-between border-b border-slate-300 pb-1">
                <span>Operating Overhead Expenses</span>
                <span>USD</span>
              </div>
              {periodOverheadExpenses.length > 0 ? (
                periodOverheadExpenses.map((exp) => (
                  <div key={exp.id} className="flex justify-between pl-4 py-1 text-slate-700">
                    <span>
                      {exp.title} ({exp.category})
                    </span>
                    <span className="font-mono font-medium">
                      ${convertCurrency(exp.amount, exp.currency, 'USD').toLocaleString()}
                    </span>
                  </div>
                ))
              ) : (
                <div className="pl-4 py-1 text-slate-400 italic">No general overhead expenses in this period.</div>
              )}
              <div className="flex justify-between font-extrabold text-slate-900 pt-1.5 border-t border-slate-200 bg-slate-50/70 px-2 py-1.5 rounded-lg">
                <span>Total Operating Overhead Expenses (Schedule C)</span>
                <span className="font-mono text-sm">${totalOverheadExpensesUSD.toLocaleString()}</span>
              </div>
            </div>

            {/* NET OPERATING PROFIT TOTAL */}
            <div className="flex justify-between font-black text-base text-slate-950 py-3.5 px-4 bg-slate-900 text-white rounded-2xl shadow-xs">
              <div className="flex flex-col">
                <span>NET OPERATING PROFIT / (LOSS)</span>
                <span className="text-[11px] text-amber-300 font-bold">
                  Net Margin: {netProfitMarginPercent}% of Net Invoiced Revenue
                </span>
              </div>
              <span className="font-mono text-xl text-amber-300">
                ${netProfitUSD.toLocaleString()} USD
              </span>
            </div>

            {/* Supplementary Memo Note */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] text-slate-600 space-y-1">
              <div className="font-bold uppercase tracking-wider text-slate-900">
                Accounting Notes &amp; Cash Supplementary Schedule:
              </div>
              <p>
                &bull; <strong>Revenue Recognition:</strong> Revenue and Supplier costs are recognized on an accrual basis matching the official invoice and credit issue dates.
              </p>
              <p>
                &bull; <strong>Cash Collections in Period:</strong> Actual cash received during this timeframe totaled{' '}
                <strong>${cashPaymentsCollectedUSD.toLocaleString()} USD</strong>.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SCHEDULE A - CLIENT INVOICES & CREDITS */}
      {activeTab === 'revenue-schedule' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Schedule A: Client Invoices &amp; Credit Notes
              </h3>
              <p className="text-xs text-slate-500">
                Filter criteria: Issue Date between {startDateStr} and {endDateStr}
              </p>
            </div>
            <span className="text-xs font-bold text-slate-700">
              Total Net: ${netOperatingRevenueUSD.toLocaleString()} USD
            </span>
          </div>

          {periodClientInvoices.length === 0 ? (
            <div className="p-8 text-center text-slate-400 italic">
              No client invoices or credit notes issued within this date range.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Invoice #</th>
                    <th className="px-4 py-3">Issue Date</th>
                    <th className="px-4 py-3">Client</th>
                    <th className="px-4 py-3">Tour / Itinerary</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Total Amount</th>
                    <th className="px-4 py-3">USD Equivalent</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {periodClientInvoices.map((inv) => {
                    const cl = clients.find((c) => c.id === inv.clientId);
                    const tour = itineraries.find((t) => t.id === inv.tripId);
                    const usd = convertCurrency(inv.totalAmount, inv.currency, 'USD');
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                        <td className="px-4 py-3 text-slate-700">{inv.issueDate}</td>
                        <td className="px-4 py-3 font-semibold text-slate-900">{cl?.name || 'VIP Client'}</td>
                        <td className="px-4 py-3 text-slate-700 truncate max-w-xs">{tour?.tourName || tour?.title || 'Tour'}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                              inv.isCreditNote ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {inv.isCreditNote ? 'Credit Note' : 'Invoice'}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-bold">{formatMoney(inv.totalAmount, inv.currency)}</td>
                        <td className={`px-4 py-3 font-mono font-bold ${inv.isCreditNote ? 'text-red-600' : 'text-slate-900'}`}>
                          {inv.isCreditNote ? '-' : ''}${usd.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 font-bold text-[10px] uppercase text-slate-600">{inv.status}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SCHEDULE B - SUPPLIER INVOICES & DIRECT COSTS */}
      {activeTab === 'supplier-schedule' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Schedule B: Supplier Invoices &amp; Direct Vendor Costs
              </h3>
              <p className="text-xs text-slate-500">
                Filter criteria: Issue Date between {startDateStr} and {endDateStr}
              </p>
            </div>
            <span className="text-xs font-bold text-slate-700">
              Total Net: ${totalPeriodSupplierNetUSD.toLocaleString()} USD
            </span>
          </div>

          {periodSupplierInvoices.length === 0 ? (
            <div className="p-8 text-center text-slate-400 italic">
              No supplier invoices or vendor credits issued within this date range.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Invoice #</th>
                    <th className="px-4 py-3">Issue Date</th>
                    <th className="px-4 py-3">Supplier</th>
                    <th className="px-4 py-3">Tour Link</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">USD Equivalent</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {periodSupplierInvoices.map((inv) => {
                    const sup = suppliers.find((s) => s.id === inv.supplierId);
                    const tour = itineraries.find((t) => t.id === inv.tripId);
                    const usd = convertCurrency(inv.amount, inv.currency, 'USD');
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                        <td className="px-4 py-3 text-slate-700">{inv.issueDate}</td>
                        <td className="px-4 py-3 font-semibold text-slate-900">{sup?.name || 'Vendor'}</td>
                        <td className="px-4 py-3 text-slate-700 truncate max-w-xs">{tour ? (tour.tourName || tour.title) : 'General Overhead'}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                              inv.isCredit ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {inv.isCredit ? 'Credit / Return' : 'Supplier Bill'}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-bold">{formatMoney(inv.amount, inv.currency)}</td>
                        <td className={`px-4 py-3 font-mono font-bold ${inv.isCredit ? 'text-emerald-700' : 'text-slate-900'}`}>
                          {inv.isCredit ? '-' : ''}${usd.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 font-bold text-[10px] uppercase text-slate-600">{inv.status}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SCHEDULE C - OVERHEAD EXPENSES */}
      {activeTab === 'overhead-schedule' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Schedule C: Operating Overhead Expenses
              </h3>
              <p className="text-xs text-slate-500">
                General company expenses dated between {startDateStr} and {endDateStr}
              </p>
            </div>
            <span className="text-xs font-bold text-slate-700">
              Total: ${totalOverheadExpensesUSD.toLocaleString()} USD
            </span>
          </div>

          {periodOverheadExpenses.length === 0 ? (
            <div className="p-8 text-center text-slate-400 italic">
              No overhead expenses recorded within this date range.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Expense Title</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">USD Equivalent</th>
                    <th className="px-4 py-3">Payment Method</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {periodOverheadExpenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-bold text-slate-900">{exp.title}</td>
                      <td className="px-4 py-3 text-slate-700">{exp.date}</td>
                      <td className="px-4 py-3 text-slate-700">{exp.category}</td>
                      <td className="px-4 py-3 font-mono font-bold">{formatMoney(exp.amount, exp.currency)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">
                        ${convertCurrency(exp.amount, exp.currency, 'USD').toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-slate-600">{exp.paymentMethod}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

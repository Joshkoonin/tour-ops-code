import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  MapPin,
  Users,
  Compass,
  Check,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Briefcase,
  TrendingUp,
  Search,
  Filter,
  DollarSign,
  User,
  Layers,
  Building2,
  X,
  CalendarDays,
  ListFilter,
  ChevronDown,
  Sparkles,
  Edit3,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Itinerary, TripStatus, CurrencyCode, Client } from '../../types';
import { TourStatusSelector } from '../common/TourStatusSelector';
import { getTourContractRevenue } from '../../utils/financialCalculations';

type CalendarViewMode = 'month' | 'week' | 'day' | 'agenda';

interface AddTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDate?: string;
  onCreated?: (tripId: string) => void;
}

export const AddTourCalendarModal: React.FC<AddTourModalProps> = ({
  isOpen,
  onClose,
  initialDate,
  onCreated,
}) => {
  const { clients, staff, addClient, addItinerary } = useApp();

  const [tourName, setTourName] = useState('');
  const [destination, setDestination] = useState('Jerusalem & Galilee, Israel');
  const [startDate, setStartDate] = useState(
    initialDate || new Date().toISOString().split('T')[0]
  );
  const [durationDays, setDurationDays] = useState(7);
  const [clientId, setClientId] = useState(clients[0]?.id || '');
  const [isNewClient, setIsNewClient] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientEmail, setNewClientEmail] = useState('');
  const [leadStaffId, setLeadStaffId] = useState(staff[0]?.id || '');
  const [guideName, setGuideName] = useState('Dr. Avi Ron');
  const [driverName, setDriverName] = useState('Ehud VIP Chauffeur');
  const [partySize, setPartySize] = useState(4);
  const [pricingMode, setPricingMode] = useState<'package' | 'perPerson'>('package');
  const [totalPrice, setTotalPrice] = useState(14500);
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [status, setStatus] = useState<TripStatus>('Confirmed');
  const [overview, setOverview] = useState('');

  // Update startDate if initialDate changes
  React.useEffect(() => {
    if (initialDate) {
      setStartDate(initialDate);
    }
  }, [initialDate]);

  if (!isOpen) return null;

  const calculateEndDate = (start: string, days: number) => {
    try {
      const d = new Date(start);
      d.setDate(d.getDate() + (days - 1));
      return d.toISOString().split('T')[0];
    } catch {
      return start;
    }
  };

  const calculatedEndDate = calculateEndDate(startDate, durationDays);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveName = tourName.trim() || `Tour to ${destination}`;
    if (!effectiveName) return;

    let finalClientId = clientId;
    if (isNewClient && newClientName.trim()) {
      const newCl: Client = {
        id: `client-${Date.now()}`,
        name: newClientName.trim(),
        email: newClientEmail.trim() || 'client@example.com',
        phone: '+1 555-0199',
        vipTier: 'Gold VIP',
        nationality: 'International',
        dietaryRestrictions: [],
        preferences: [],
        emergencyContact: { name: 'Family Office', phone: '', relationship: 'Emergency' },
        notes: 'Created via Calendar Hub',
        createdAt: new Date().toISOString(),
      };
      await addClient(newCl);
      finalClientId = newCl.id;
    } else if (!finalClientId && clients.length > 0) {
      finalClientId = clients[0].id;
    }

    // Build day items
    const days = [];
    const startObj = new Date(startDate);
    for (let i = 1; i <= durationDays; i++) {
      const d = new Date(startObj);
      d.setDate(d.getDate() + (i - 1));
      const dateStr = d.toISOString().split('T')[0];

      days.push({
        id: `day-${Date.now()}-${i}`,
        dayNumber: i,
        date: dateStr,
        title: `Day ${i}: ${i === 1 ? 'Arrival & Welcome Dinner' : i === durationDays ? 'Departure & Farewell Seminar' : 'Guided Exploration & Sightseeing'}`,
        summary: `Full day scheduled operations for ${effectiveName}.`,
        activities: [
          {
            id: `act-${Date.now()}-${i}-1`,
            timeSlot: '09:30 - 13:00',
            startTime: '09:30',
            endTime: '13:00',
            title: `Curated Escorted Touring - Day ${i}`,
            description: `Private guided experience in ${destination}.`,
            location: destination,
            included: true,
            costEstimate: 0,
            currency,
            category: 'Sightseeing',
            bookingStatus: 'confirmed' as const,
          },
          {
            id: `act-${Date.now()}-${i}-2`,
            timeSlot: '14:30 - 18:00',
            startTime: '14:30',
            endTime: '18:00',
            title: `Afternoon Cultural Visit & Seminar`,
            description: `Exclusive access and local curator session.`,
            location: destination,
            included: true,
            costEstimate: 0,
            currency,
            category: 'Culture',
            bookingStatus: 'confirmed' as const,
          },
        ],
      });
    }

    const newItinerary: Itinerary = {
      id: `trip-${Date.now()}`,
      code: `TO-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      tourName: effectiveName,
      title: effectiveName,
      destination: destination.trim(),
      startDate,
      endDate: calculatedEndDate,
      clientId: finalClientId,
      leadStaffId: leadStaffId || staff[0]?.id || '',
      partySize: Number(partySize) || 2,
      pricingMode: pricingMode,
      currency,
      totalClientPrice: Number(totalPrice) || 0,
      depositRequired: Math.round((Number(totalPrice) || 0) * 0.4),
      heroImage: 'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1200&auto=format&fit=crop&q=80',
      guideName: guideName.trim() || undefined,
      driverName: driverName.trim() || undefined,
      status,
      overview: overview.trim() || `Comprehensive tour across ${destination} scheduled from ${startDate} to ${calculatedEndDate}.`,
      highlights: ['Private escorted touring', 'VIP local curators', 'Chauffeur service'],
      inclusions: [],
      exclusions: ['International flights', 'Discretionary gratuities'],
      days,
      lastUpdated: new Date().toISOString(),
    };

    await addItinerary(newItinerary);
    if (onCreated) {
      onCreated(newItinerary.id);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 my-auto animate-scale-in">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">Schedule Tour on Calendar</h3>
              <p className="text-xs text-slate-500">Add an operating tour to show all work across your operations schedule</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Tour Name / Code *
              </label>
              <input
                type="text"
                required
                value={tourName}
                onChange={(e) => setTourName(e.target.value)}
                placeholder="e.g. Autumn Holy Land Delegation 2026"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Destination *
              </label>
              <input
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="e.g. Jerusalem, Galilee & Dead Sea"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Operational Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as TripStatus)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              >
                <option value="Confirmed">Confirmed (Active Operation)</option>
                <option value="In Progress">In Progress (Currently Running)</option>
                <option value="Proposed">Proposed / Under Review</option>
                <option value="Draft">Draft Outline</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Start Date *
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Duration (Days) &bull; End Date: {calculatedEndDate}
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  min="1"
                  max="45"
                  value={durationDays}
                  onChange={(e) => setDurationDays(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-24 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all text-center"
                />
                <span className="text-xs text-slate-500 font-medium">
                  {durationDays} {durationDays === 1 ? 'day' : 'days'} (until {calculatedEndDate})
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Client / Delegation
                </label>
                <button
                  type="button"
                  onClick={() => setIsNewClient(!isNewClient)}
                  className="text-[11px] text-amber-600 font-bold hover:underline"
                >
                  {isNewClient ? 'Pick Existing Client' : '+ New Client'}
                </button>
              </div>

              {isNewClient ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    placeholder="Client or Group Name"
                    value={newClientName}
                    onChange={(e) => setNewClientName(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900"
                  />
                  <input
                    type="email"
                    placeholder="Client Contact Email"
                    value={newClientEmail}
                    onChange={(e) => setNewClientEmail(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900"
                  />
                </div>
              ) : (
                <select
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.companyOrFamily ? `(${c.companyOrFamily})` : ''}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Lead Directing Staff
              </label>
              <select
                value={leadStaffId}
                onChange={(e) => setLeadStaffId(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              >
                {staff.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.role})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Designated Tour Guide
              </label>
              <input
                type="text"
                value={guideName}
                onChange={(e) => setGuideName(e.target.value)}
                placeholder="e.g. Dr. Avi Ron"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                VIP Driver / Chauffeur
              </label>
              <input
                type="text"
                value={driverName}
                onChange={(e) => setDriverName(e.target.value)}
                placeholder="e.g. Ehud Mercedes Fleet"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Party Size
                </label>
                <input
                  type="number"
                  min="1"
                  value={partySize}
                  onChange={(e) => setPartySize(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 text-center"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Currency
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 text-center"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="ILS">ILS (₪)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Total Tour Contract Price ({currency})
              </label>
              <input
                type="number"
                min="0"
                step="100"
                value={totalPrice}
                onChange={(e) => setTotalPrice(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Operational Notes / Work Directives
            </label>
            <textarea
              rows={2}
              value={overview}
              onChange={(e) => setOverview(e.target.value)}
              placeholder="Special arrangements, VIP flight arrivals, dietary considerations, or specific supplier coordination..."
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all resize-none"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/25 transition-all flex items-center space-x-2"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add Tour to Operations Calendar</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const CalendarHub: React.FC = () => {
  const {
    itineraries,
    clients,
    staff,
    supplierInvoices,
    suppliers,
    supplierBookings,
    setSelectedTripId,
    setActiveView,
    formatMoney,
    convertCurrency,
    updateItinerary,
    hasFullFinancialView,
  } = useApp();

  const [viewMode, setViewMode] = useState<CalendarViewMode>('month');
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [selectedTour, setSelectedTour] = useState<Itinerary | null>(null);
  const [selectedDayDetailDate, setSelectedDayDetailDate] = useState<string | null>(null);
  const [isAddTourModalOpen, setIsAddTourModalOpen] = useState(false);
  const [addTourPresetDate, setAddTourPresetDate] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [guideFilter, setGuideFilter] = useState<string>('ALL');

  // Month navigation helpers
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const handleUpdateTourStatus = (tour: Itinerary, newStatus: TripStatus) => {
    const updated: Itinerary = {
      ...tour,
      status: newStatus,
      lastUpdated: new Date().toISOString(),
    };
    updateItinerary(updated);
    setSelectedTour(updated);
  };

  // Month name formatting
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const currentMonthLabel = `${monthNames[month]} ${year}`;

  // Filtered itineraries
  const filteredItineraries = useMemo(() => {
    return itineraries.filter((tour) => {
      const matchSearch =
        searchQuery === '' ||
        tour.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tour.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tour.tourName && tour.tourName.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchStatus = statusFilter === 'ALL' || tour.status === statusFilter;

      const matchGuide =
        guideFilter === 'ALL' ||
        (tour.guideName && tour.guideName.toLowerCase().includes(guideFilter.toLowerCase()));

      return matchSearch && matchStatus && matchGuide;
    });
  }, [itineraries, searchQuery, statusFilter, guideFilter]);

  // Calendar grid calculations for Month View
  const calendarGrid = useMemo(() => {
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 for Sunday
    const totalDaysInMonth = lastDayOfMonth.getDate();

    // Previous month filler days
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    const prevDays: { dateStr: string; dayNumber: number; isCurrentMonth: boolean }[] = [];
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const dayNum = prevMonthLastDay - i;
      const d = new Date(year, month - 1, dayNum);
      prevDays.push({
        dateStr: d.toISOString().split('T')[0],
        dayNumber: dayNum,
        isCurrentMonth: false,
      });
    }

    // Current month days
    const currentDays: { dateStr: string; dayNumber: number; isCurrentMonth: boolean }[] = [];
    for (let i = 1; i <= totalDaysInMonth; i++) {
      const d = new Date(year, month, i);
      currentDays.push({
        dateStr: d.toISOString().split('T')[0],
        dayNumber: i,
        isCurrentMonth: true,
      });
    }

    // Next month filler days (fill up to multiple of 7)
    const totalRendered = prevDays.length + currentDays.length;
    const remaining = totalRendered % 7 === 0 ? 0 : 7 - (totalRendered % 7);
    const nextDays: { dateStr: string; dayNumber: number; isCurrentMonth: boolean }[] = [];
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(year, month + 1, i);
      nextDays.push({
        dateStr: d.toISOString().split('T')[0],
        dayNumber: i,
        isCurrentMonth: false,
      });
    }

    return [...prevDays, ...currentDays, ...nextDays];
  }, [year, month]);

  // Check if a tour runs on a specific date (inclusive)
  const getToursOnDate = (dateStr: string) => {
    return filteredItineraries.filter((tour) => {
      if (!tour.startDate || !tour.endDate) return false;
      return dateStr >= tour.startDate && dateStr <= tour.endDate;
    });
  };

  // Color palette assignment for distinct tours
  const getTourColorTheme = (tourId: string, index: number) => {
    const themes = [
      {
        bg: 'bg-amber-500/15 border-amber-500/40 text-amber-900 hover:bg-amber-500/25',
        bar: 'bg-amber-500',
        badge: 'bg-amber-100 text-amber-800',
        card: 'border-l-amber-500',
      },
      {
        bg: 'bg-blue-500/15 border-blue-500/40 text-blue-900 hover:bg-blue-500/25',
        bar: 'bg-blue-500',
        badge: 'bg-blue-100 text-blue-800',
        card: 'border-l-blue-500',
      },
      {
        bg: 'bg-emerald-500/15 border-emerald-500/40 text-emerald-900 hover:bg-emerald-500/25',
        bar: 'bg-emerald-500',
        badge: 'bg-emerald-100 text-emerald-800',
        card: 'border-l-emerald-500',
      },
      {
        bg: 'bg-purple-500/15 border-purple-500/40 text-purple-900 hover:bg-purple-500/25',
        bar: 'bg-purple-500',
        badge: 'bg-purple-100 text-purple-800',
        card: 'border-l-purple-500',
      },
      {
        bg: 'bg-rose-500/15 border-rose-500/40 text-rose-900 hover:bg-rose-500/25',
        bar: 'bg-rose-500',
        badge: 'bg-rose-100 text-rose-800',
        card: 'border-l-rose-500',
      },
      {
        bg: 'bg-teal-500/15 border-teal-500/40 text-teal-900 hover:bg-teal-500/25',
        bar: 'bg-teal-500',
        badge: 'bg-teal-100 text-teal-800',
        card: 'border-l-teal-500',
      },
    ];
    // Hash id or use index
    let charSum = 0;
    for (let i = 0; i < tourId.length; i++) charSum += tourId.charCodeAt(i);
    return themes[(charSum + index) % themes.length];
  };

  const todayStr = new Date().toISOString().split('T')[0];

  // Tour Financial details
  const getTourFinancials = (tour: Itinerary) => {
    const assignedInvoices = supplierInvoices.filter((inv) => inv.tripId === tour.id);
    const totalExpensesUSD = assignedInvoices.reduce(
      (sum, inv) => sum + convertCurrency(inv.amount || 0, inv.currency, 'USD'),
      0
    );
    const revenueUSD = convertCurrency(tour.totalClientPrice || 0, tour.currency, 'USD');
    const grossProfitUSD = revenueUSD - totalExpensesUSD;
    const marginPercent = revenueUSD > 0 ? (grossProfitUSD / revenueUSD) * 100 : 0;

    // Projected costs for proposals
    const specificProjectedUSD = tour.days.reduce((sum, day) => {
      return (
        sum +
        day.activities.reduce((actSum, act) => {
          if (!act.costEstimate || act.costEstimate <= 0) return actSum;
          return actSum + convertCurrency(act.costEstimate, act.currency || tour.currency || 'USD', 'USD');
        }, 0)
      );
    }, 0);

    const generalProjectedUSD = (tour.generalProjectedCosts || []).reduce((sum, item) => {
      return sum + convertCurrency(item.costEstimate || 0, item.currency || tour.currency || 'USD', 'USD');
    }, 0);

    const totalProjectedCostsUSD = specificProjectedUSD + generalProjectedUSD;
    const isProposed = tour.status === 'Proposed';
    const isPreInvoice = isProposed && assignedInvoices.length === 0;

    const displayedCostUSD = isPreInvoice ? totalProjectedCostsUSD : totalExpensesUSD;
    const displayedProfitUSD = isPreInvoice ? revenueUSD - totalProjectedCostsUSD : grossProfitUSD;
    const displayedMarginPercent = revenueUSD > 0 ? (displayedProfitUSD / revenueUSD) * 100 : 0;

    return {
      assignedInvoices,
      totalExpensesUSD,
      revenueUSD,
      grossProfitUSD,
      marginPercent,
      totalProjectedCostsUSD,
      isPreInvoice,
      displayedCostUSD,
      displayedProfitUSD,
      displayedMarginPercent,
    };
  };

  // Week View dates (7 days starting from currentDate's week)
  const weekDays = useMemo(() => {
    const curr = new Date(currentDate);
    const dayOfWeek = curr.getDay();
    const sunday = new Date(curr);
    sunday.setDate(curr.getDate() - dayOfWeek);

    const days: { dateStr: string; dayName: string; dayNum: number; dateObj: Date }[] = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    for (let i = 0; i < 7; i++) {
      const d = new Date(sunday);
      d.setDate(sunday.getDate() + i);
      days.push({
        dateStr: d.toISOString().split('T')[0],
        dayName: dayNames[i],
        dayNum: d.getDate(),
        dateObj: d,
      });
    }
    return days;
  }, [currentDate]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-600 shadow-xs">
              <CalendarDays className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                Tours &amp; Operations Calendar
              </h1>
              <p className="text-xs sm:text-sm text-slate-500">
                Master schedule to coordinate tours, supplier bookings, guides, and daily operations work
              </p>
            </div>
          </div>
        </div>

        {/* Action button to schedule tour */}
        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => {
              setAddTourPresetDate(undefined);
              setIsAddTourModalOpen(true);
            }}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-amber-500/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add Tour to Calendar</span>
          </button>
        </div>
      </div>

      {/* Overview Stat Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Scheduled Tours</div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">{filteredItineraries.length}</div>
            <div className="text-[11px] text-amber-600 font-medium">All active itineraries</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
            <Compass className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Tours Running Today</div>
            <div className="text-xl sm:text-2xl font-black text-emerald-700 mt-0.5">
              {getToursOnDate(todayStr).length}
            </div>
            <div className="text-[11px] text-emerald-600 font-medium">
              {getToursOnDate(todayStr).length > 0 ? 'Live operations in progress' : 'No tours active today'}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Guests / Pax</div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
              {filteredItineraries.reduce((sum, t) => sum + (t.partySize || 0), 0)}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">Across all scheduled tours</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Gross Contract Value</div>
            <div className="text-xl sm:text-2xl font-black text-amber-700 mt-0.5">
              ${formatMoney(
                filteredItineraries.reduce(
                  (sum, t) => sum + convertCurrency(getTourContractRevenue(t) || 0, t.currency, 'USD'),
                  0
                ),
                'USD'
              )}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">Confirmed work pipeline</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Calendar Controls & Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Month / Period Navigation */}
          <div className="flex items-center space-x-2">
            <button
              onClick={prevMonth}
              className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <h2 className="text-base sm:text-lg font-black text-slate-900 min-w-[170px] text-center">
              {currentMonthLabel}
            </h2>
            <button
              onClick={nextMonth}
              className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={goToToday}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Today
            </button>
          </div>

          {/* View Mode Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                viewMode === 'month'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Month Grid
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                viewMode === 'week'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Week View
            </button>
            <button
              onClick={() => {
                setViewMode('day');
                setSelectedDayDetailDate(todayStr);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                viewMode === 'day'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Day Operations
            </button>
            <button
              onClick={() => setViewMode('agenda')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                viewMode === 'agenda'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Agenda
            </button>
          </div>
        </div>

        {/* Search & Quick Filters */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tours by name, destination, code..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center space-x-1.5 text-xs">
            <span className="text-slate-400 font-semibold text-[11px] hidden sm:inline">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-semibold"
            >
              <option value="ALL">All Statuses</option>
              <option value="Confirmed">Confirmed</option>
              <option value="In Progress">In Progress</option>
              <option value="Proposed">Proposed</option>
              <option value="Draft">Draft</option>
            </select>
          </div>

          <div className="flex items-center space-x-1.5 text-xs">
            <span className="text-slate-400 font-semibold text-[11px] hidden sm:inline">Guide:</span>
            <select
              value={guideFilter}
              onChange={(e) => setGuideFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-semibold"
            >
              <option value="ALL">All Guides</option>
              {Array.from(
                new Set(
                  itineraries
                    .map((i) => i.guideName)
                    .filter((g): g is string => Boolean(g && g.trim()))
                )
              ).map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          {(searchQuery || statusFilter !== 'ALL' || guideFilter !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('ALL');
                setGuideFilter('ALL');
              }}
              className="text-xs text-amber-700 hover:text-amber-900 font-bold underline px-1"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Main Calendar View Rendering */}
      {viewMode === 'month' && (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
          {/* Day of Week Header */}
          <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50/80 text-center py-2.5">
            {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(
              (dayName, i) => (
                <div key={dayName} className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                  <span className="hidden md:inline">{dayName}</span>
                  <span className="md:hidden">{dayName.slice(0, 3)}</span>
                </div>
              )
            )}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-slate-100 bg-slate-100/40">
            {calendarGrid.map((day, idx) => {
              const toursToday = getToursOnDate(day.dateStr);
              const isToday = day.dateStr === todayStr;

              return (
                <div
                  key={`${day.dateStr}-${idx}`}
                  className={`min-h-[110px] sm:min-h-[135px] p-1.5 sm:p-2 bg-white transition-colors relative flex flex-col group ${
                    !day.isCurrentMonth ? 'bg-slate-50/50 text-slate-400' : 'text-slate-900'
                  } ${isToday ? 'ring-2 ring-amber-500/80 ring-inset bg-amber-50/20' : ''}`}
                >
                  {/* Day cell header */}
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className={`text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center ${
                        isToday
                          ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                          : day.isCurrentMonth
                          ? 'text-slate-700 group-hover:text-amber-600'
                          : 'text-slate-400'
                      }`}
                    >
                      {day.dayNumber}
                    </span>

                    {/* Quick Add Tour on this Date Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setAddTourPresetDate(day.dateStr);
                        setIsAddTourModalOpen(true);
                      }}
                      title={`Add tour starting on ${day.dateStr}`}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded-md text-amber-600 hover:bg-amber-100 hover:text-amber-900 transition-all cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                    </button>
                  </div>

                  {/* Tours Chips */}
                  <div className="flex-1 space-y-1 overflow-y-auto max-h-[85px] sm:max-h-[105px] pr-0.5">
                    {toursToday.map((tour, tIdx) => {
                      const theme = getTourColorTheme(tour.id, tIdx);
                      const isStart = tour.startDate === day.dateStr;
                      const isEnd = tour.endDate === day.dateStr;

                      return (
                        <div
                          key={tour.id}
                          onClick={() => setSelectedTour(tour)}
                          className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition-all cursor-pointer truncate flex items-center justify-between shadow-2xs ${theme.bg}`}
                          title={`${tour.title} • ${tour.destination} (${tour.status})`}
                        >
                          <div className="flex items-center space-x-1.5 truncate">
                            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${theme.bar}`} />
                            <span className="truncate">{tour.tourName || tour.title}</span>
                          </div>
                          {isStart && (
                            <span className="text-[9px] font-mono bg-white/70 px-1 rounded text-slate-800 shrink-0 font-extrabold ml-1">
                              Start
                            </span>
                          )}
                          {isEnd && (
                            <span className="text-[9px] font-mono bg-slate-900 text-white px-1 rounded shrink-0 font-extrabold ml-1">
                              End
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Week View */}
      {viewMode === 'week' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-4 sm:p-6 overflow-x-auto">
          <div className="min-w-[850px] grid grid-cols-7 gap-3">
            {weekDays.map((wDay) => {
              const toursOnThisDay = getToursOnDate(wDay.dateStr);
              const isToday = wDay.dateStr === todayStr;

              return (
                <div
                  key={wDay.dateStr}
                  className={`rounded-2xl border p-3.5 flex flex-col min-h-[380px] ${
                    isToday ? 'border-amber-400 bg-amber-50/20' : 'border-slate-200 bg-slate-50/40'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200/80 mb-3">
                    <div>
                      <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                        {wDay.dayName}
                      </div>
                      <div className="text-base font-black text-slate-900">{wDay.dayNum}</div>
                    </div>
                    <button
                      onClick={() => {
                        setAddTourPresetDate(wDay.dateStr);
                        setIsAddTourModalOpen(true);
                      }}
                      className="p-1 rounded-lg text-slate-500 hover:text-amber-700 hover:bg-amber-100 transition-colors"
                      title="Add tour on this date"
                    >
                      <Plus className="w-4 h-4 stroke-[2.2]" />
                    </button>
                  </div>

                  <div className="space-y-2.5 flex-1 overflow-y-auto">
                    {toursOnThisDay.length === 0 ? (
                      <div className="text-center py-6 text-slate-400 text-xs italic">
                        No active tour work
                      </div>
                    ) : (
                      toursOnThisDay.map((tour, tIdx) => {
                        const theme = getTourColorTheme(tour.id, tIdx);
                        // Find this day in the tour days
                        const dayItem = tour.days?.find((d) => d.date === wDay.dateStr);

                        return (
                          <div
                            key={tour.id}
                            onClick={() => setSelectedTour(tour)}
                            className={`p-2.5 rounded-xl border bg-white shadow-2xs hover:shadow-md transition-all cursor-pointer ${theme.card} border-l-4`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-mono font-bold text-slate-500">
                                {tour.code}
                              </span>
                              <span
                                className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                                  tour.status === 'Confirmed'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {tour.status}
                              </span>
                            </div>
                            <h4 className="text-xs font-black text-slate-900 mt-1 line-clamp-1">
                              {tour.tourName || tour.title}
                            </h4>

                            {dayItem && (
                              <div className="mt-1.5 pt-1.5 border-t border-slate-100 text-[11px] text-slate-600">
                                <div className="font-semibold text-slate-800 line-clamp-1">
                                  {dayItem.title}
                                </div>
                                <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                                  <Clock className="w-3 h-3 text-amber-500" />
                                  <span>{dayItem.activities?.length || 0} scheduled bookings</span>
                                </div>
                              </div>
                            )}

                            {tour.guideName && (
                              <div className="mt-2 text-[10px] text-slate-500 flex items-center gap-1">
                                <User className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{tour.guideName}</span>
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Day Operations View */}
      {viewMode === 'day' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 sm:p-7 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-amber-600">
                Daily Operations Manifest
              </div>
              <h3 className="text-xl font-black text-slate-900 mt-0.5">
                Work Scheduled for {selectedDayDetailDate || todayStr}
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="date"
                value={selectedDayDetailDate || todayStr}
                onChange={(e) => setSelectedDayDetailDate(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl"
              />
              <button
                onClick={() => {
                  setAddTourPresetDate(selectedDayDetailDate || todayStr);
                  setIsAddTourModalOpen(true);
                }}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Tour on This Day</span>
              </button>
            </div>
          </div>

          {/* List of active tours on this selected day */}
          {getToursOnDate(selectedDayDetailDate || todayStr).length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <CalendarDays className="w-10 h-10 text-slate-400 mx-auto mb-2 opacity-50" />
              <h4 className="text-sm font-bold text-slate-700">No Tours Operating on this Date</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                You can add a new tour starting on this date to schedule itineraries, supplier reservations, and guides.
              </p>
              <button
                onClick={() => {
                  setAddTourPresetDate(selectedDayDetailDate || todayStr);
                  setIsAddTourModalOpen(true);
                }}
                className="mt-3 inline-flex items-center space-x-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>Schedule New Tour</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {getToursOnDate(selectedDayDetailDate || todayStr).map((tour) => {
                const dayItem = tour.days?.find((d) => d.date === (selectedDayDetailDate || todayStr));
                const client = clients.find((c) => c.id === tour.clientId);

                return (
                  <div
                    key={tour.id}
                    className="p-4 sm:p-5 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                            {tour.code}
                          </span>
                          <span className="text-xs font-bold text-slate-500">&bull;</span>
                          <span className="text-xs font-bold text-slate-700">{client?.name}</span>
                          <span className="text-xs font-bold text-slate-500">&bull;</span>
                          <span className="text-xs text-slate-500">{tour.partySize} Guests</span>
                        </div>
                        <h4 className="text-base font-black text-slate-900 mt-1">
                          {tour.tourName || tour.title}
                        </h4>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedTour(tour)}
                          className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-800 hover:bg-slate-100 flex items-center space-x-1"
                        >
                          <span>Tour Work &amp; Profit</span>
                        </button>
                        <button
                          onClick={() => {
                            setSelectedTripId(tour.id);
                            setActiveView('builder');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center space-x-1"
                        >
                          <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                          <span>Open Builder</span>
                        </button>
                      </div>
                    </div>

                    {/* Day Itinerary & Bookings Work */}
                    {dayItem ? (
                      <div className="mt-3 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold text-slate-900">
                            {dayItem.title}
                          </span>
                          {dayItem.hotelName && (
                            <span className="text-xs text-slate-600 flex items-center gap-1 font-semibold">
                              <Building2 className="w-3.5 h-3.5 text-blue-600" />
                              <span>Hotel: {dayItem.hotelName}</span>
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {dayItem.activities?.map((act) => (
                            <div
                              key={act.id}
                              className="p-3 rounded-xl bg-white border border-slate-200 flex items-start justify-between text-xs"
                            >
                              <div className="space-y-0.5">
                                <div className="font-bold text-slate-900">{act.title}</div>
                                <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                                  <Clock className="w-3 h-3 text-amber-600" />
                                  <span>{act.timeSlot}</span>
                                  {act.location && (
                                    <>
                                      <span>&bull;</span>
                                      <MapPin className="w-3 h-3 text-slate-400" />
                                      <span className="truncate">{act.location}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                                  act.bookingStatus === 'confirmed'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {act.bookingStatus || 'To Book'}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 text-xs text-slate-500 italic">
                        No specific day sub-items configured for this date.
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Agenda View */}
      {viewMode === 'agenda' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 sm:p-7 space-y-4">
          <h3 className="text-lg font-black text-slate-900">Operations Agenda &amp; Tour Work List</h3>
          <div className="divide-y divide-slate-100">
            {filteredItineraries.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-sm">
                No tours matching current filter.
              </div>
            ) : (
              filteredItineraries.map((tour) => {
                const fin = getTourFinancials(tour);
                const client = clients.find((c) => c.id === tour.clientId);

                return (
                  <div
                    key={tour.id}
                    className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/70 p-3 rounded-2xl transition-colors cursor-pointer"
                    onClick={() => setSelectedTour(tour)}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          {tour.code}
                        </span>
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            tour.status === 'Confirmed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {tour.status}
                        </span>
                        <span className="text-xs text-slate-500">&bull;</span>
                        <span className="text-xs font-semibold text-slate-700">{client?.name}</span>
                      </div>
                      <h4 className="text-base font-extrabold text-slate-900">
                        {tour.tourName || tour.title}
                      </h4>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-3">
                        <span className="flex items-center gap-1">
                          <CalendarIcon className="w-3.5 h-3.5 text-amber-600" />
                          <span>
                            {tour.startDate} &rarr; {tour.endDate}
                          </span>
                        </span>
                        <span>&bull;</span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <span>{tour.destination}</span>
                        </span>
                        {tour.guideName && (
                          <>
                            <span>&bull;</span>
                            <span className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              <span>Guide: {tour.guideName}</span>
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      {hasFullFinancialView && (
                        <div className="text-right">
                          <div className="text-xs text-slate-400 font-semibold">Contract / Profit</div>
                          <div className="text-sm font-black text-slate-900">
                            ${formatMoney(fin.revenueUSD, 'USD')}
                          </div>
                          <div className="text-[11px] font-bold text-emerald-600">
                            +${formatMoney(fin.grossProfitUSD, 'USD')} ({fin.marginPercent.toFixed(1)}%)
                          </div>
                        </div>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedTour(tour);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors"
                      >
                        View All Work
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Tour Work & Operations Detail Drawer / Modal */}
      {selectedTour && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-auto animate-scale-in max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {selectedTour.code}
                  </span>
                  <TourStatusSelector
                    tour={selectedTour}
                    size="sm"
                    showQuickActions={true}
                    onStatusChange={(newStatus) =>
                      setSelectedTour((prev) => (prev ? { ...prev, status: newStatus } : null))
                    }
                  />
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                  {selectedTour.tourName || selectedTour.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  {selectedTour.destination} &bull; {selectedTour.startDate} to {selectedTour.endDate} ({selectedTour.partySize} Guests)
                </p>
              </div>

              <button
                onClick={() => setSelectedTour(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable content */}
            <div className="flex-1 overflow-y-auto py-4 space-y-5">
              {/* Financial Snapshot */}
              {hasFullFinancialView && (() => {
                const fin = getTourFinancials(selectedTour);
                return (
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Client Revenue</div>
                        <div className="text-base font-black text-slate-900 mt-0.5">
                          ${formatMoney(fin.revenueUSD, 'USD')}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          {fin.isPreInvoice ? 'Projected Costs' : 'Supplier Invoices'}
                        </div>
                        <div className={`text-base font-black mt-0.5 ${fin.isPreInvoice ? 'text-amber-700' : 'text-rose-700'}`}>
                          ${formatMoney(fin.displayedCostUSD, 'USD')}
                        </div>
                        {fin.isPreInvoice && (
                          <div className="text-[9px] font-bold text-amber-800">
                            Items + Bus/Guide
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          {fin.isPreInvoice ? 'Projected Profit' : 'Gross Profit'}
                        </div>
                        <div className={`text-base font-black mt-0.5 ${fin.displayedProfitUSD >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {fin.displayedProfitUSD >= 0 ? '+' : '-'}${formatMoney(Math.abs(fin.displayedProfitUSD), 'USD')}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          {fin.isPreInvoice ? 'Projected Margin' : 'Profit Margin'}
                        </div>
                        <div className="text-base font-black text-amber-600 mt-0.5">
                          {fin.displayedMarginPercent.toFixed(1)}%
                        </div>
                      </div>
                    </div>

                    {fin.isPreInvoice && (
                      <div className="text-[10px] text-slate-500 pt-1.5 border-t border-slate-200/80 flex items-center justify-between">
                        <span>Quoted proposal costs. Does not affect company ledger until confirmed and invoices added.</span>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTripId(selectedTour.id);
                            setActiveView('builder');
                          }}
                          className="text-amber-700 font-bold hover:underline shrink-0 ml-2"
                        >
                          Configure in Builder &rarr;
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Operations Personnel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase">Designated Guide</div>
                    <div className="font-extrabold text-slate-900">{selectedTour.guideName || 'Unassigned'}</div>
                  </div>
                </div>

                <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase">Chauffeur / Driver</div>
                    <div className="font-extrabold text-slate-900">{selectedTour.driverName || 'Standard Fleet'}</div>
                  </div>
                </div>
              </div>

              {/* Day-by-Day Work Schedule */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-extrabold text-slate-900">
                    Day-by-Day Scheduled Work &amp; Bookings ({selectedTour.days?.length || 0} Days)
                  </h4>
                  <button
                    onClick={() => {
                      setSelectedTripId(selectedTour.id);
                      setActiveView('builder');
                    }}
                    className="text-xs text-amber-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Edit in Itinerary Builder</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>

                <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                  {selectedTour.days?.map((day) => (
                    <div
                      key={day.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-black text-slate-900 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-md bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">
                            {day.dayNumber}
                          </span>
                          <span>{day.title}</span>
                        </div>
                        <span className="font-mono text-slate-500 text-[11px] font-semibold">{day.date}</span>
                      </div>

                      {day.activities?.length > 0 && (
                        <div className="space-y-1.5 pl-7">
                          {day.activities.map((act) => (
                            <div
                              key={act.id}
                              className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between"
                            >
                              <div>
                                <span className="font-bold text-slate-800">{act.title}</span>
                                <span className="text-slate-400 text-[11px] ml-2">({act.timeSlot})</span>
                              </div>
                              <span
                                className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                                  act.bookingStatus === 'confirmed'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {act.bookingStatus || 'To Book'}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Assigned Supplier Invoices */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-extrabold text-slate-900">
                    Assigned Supplier Invoices ({getTourFinancials(selectedTour).assignedInvoices.length})
                  </h4>
                  <button
                    onClick={() => {
                      setSelectedTripId(selectedTour.id);
                      setActiveView('tour-management');
                    }}
                    className="text-xs text-amber-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Tour Operations Hub</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>

                {getTourFinancials(selectedTour).assignedInvoices.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No supplier invoices assigned to this tour yet.</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {getTourFinancials(selectedTour).assignedInvoices.map((inv) => (
                      <div
                        key={inv.id}
                        className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-900">{inv.invoiceNumber}</div>
                          <div className="text-[11px] text-slate-500">
                            {suppliers.find((s) => s.id === inv.supplierId)?.name || 'Supplier'}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-black text-slate-900">
                            ${formatMoney(convertCurrency(inv.amount || 0, inv.currency, 'USD'), 'USD')}
                          </div>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                              inv.status === 'Paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setSelectedTripId(selectedTour.id);
                    setActiveView('tour-gross-profit');
                  }}
                  className="px-3 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5"
                >
                  <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
                  <span>Gross Profit Details</span>
                </button>
                <button
                  onClick={() => {
                    setSelectedTripId(selectedTour.id);
                    setActiveView('tour-management');
                  }}
                  className="px-3 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5"
                >
                  <Briefcase className="w-3.5 h-3.5 text-blue-600" />
                  <span>Operations &amp; P&amp;L</span>
                </button>
              </div>

              <button
                onClick={() => {
                  setSelectedTripId(selectedTour.id);
                  setActiveView('builder');
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center space-x-2 shadow-md shadow-slate-900/10"
              >
                <Compass className="w-4 h-4 text-amber-400" />
                <span>Open in Itinerary Builder</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Tour Modal */}
      <AddTourCalendarModal
        isOpen={isAddTourModalOpen}
        onClose={() => {
          setIsAddTourModalOpen(false);
          setAddTourPresetDate(undefined);
        }}
        initialDate={addTourPresetDate}
        onCreated={(tripId) => {
          setSelectedTripId(tripId);
        }}
      />
    </div>
  );
};

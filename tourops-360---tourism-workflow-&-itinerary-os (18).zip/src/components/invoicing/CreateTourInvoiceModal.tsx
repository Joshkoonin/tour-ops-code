import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  FileText,
  DollarSign,
  Calendar,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  Receipt,
  AlertCircle,
  HelpCircle,
  Check,
  Building,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, Invoice, Itinerary } from '../../types';

interface CreateTourInvoiceModalProps {
  isOpen: boolean;
  preselectedTripId?: string;
  defaultInvoiceType?: 'full' | 'part' | 'balance';
  onClose: () => void;
  onInvoiceCreated?: (invoice: Invoice) => void;
}

export const CreateTourInvoiceModal: React.FC<CreateTourInvoiceModalProps> = ({
  isOpen,
  preselectedTripId,
  defaultInvoiceType,
  onClose,
  onInvoiceCreated,
}) => {
  const {
    itineraries,
    clients,
    invoices,
    addInvoice,
    exchangeRates,
    formatMoney,
    convertCurrency,
  } = useApp();

  // Selected tour ID
  const [selectedTripId, setSelectedTripId] = useState<string>(
    preselectedTripId || itineraries[0]?.id || ''
  );

  const selectedTrip = useMemo(() => {
    return itineraries.find((t) => t.id === selectedTripId) || itineraries[0];
  }, [itineraries, selectedTripId]);

  const client = useMemo(() => {
    return clients.find((c) => c.id === selectedTrip?.clientId);
  }, [clients, selectedTrip]);

  // Existing invoices for this tour
  const existingTourInvoices = useMemo(() => {
    if (!selectedTrip) return [];
    return invoices.filter((inv) => inv.tripId === selectedTrip.id);
  }, [invoices, selectedTrip]);

  // Total already invoiced in trip currency
  const totalInvoicedToDate = useMemo(() => {
    return existingTourInvoices.reduce((sum, inv) => {
      // Convert to trip currency if needed
      const amtInTripCurr =
        inv.currency === selectedTrip?.currency
          ? inv.totalAmount
          : convertCurrency(inv.totalAmount, inv.currency, selectedTrip?.currency || 'USD');
      return sum + (inv.isCreditNote ? -amtInTripCurr : amtInTripCurr);
    }, 0);
  }, [existingTourInvoices, selectedTrip, convertCurrency]);

  const totalTourPrice = selectedTrip?.totalClientPrice || 0;
  const remainingUninvoiced = Math.max(0, totalTourPrice - totalInvoicedToDate);

  // Invoicing Mode: 'full' | 'part' | 'balance'
  const [invoiceType, setInvoiceType] = useState<'full' | 'part' | 'balance'>(() => {
    if (defaultInvoiceType) return defaultInvoiceType;
    if (existingTourInvoices.length > 0 && remainingUninvoiced > 0) return 'balance';
    return 'full';
  });

  // Part payment parameters
  const [partPaymentMode, setPartPaymentMode] = useState<'percentage' | 'custom' | 'deposit'>('percentage');
  const [percentageInput, setPercentageInput] = useState<number>(30); // 30% default deposit
  const [customAmountInput, setCustomAmountInput] = useState<number>(() => {
    return Math.round(totalTourPrice * 0.3) || 1000;
  });

  // Invoice Fields
  const [invoiceNumber, setInvoiceNumber] = useState<string>('');
  const [issueDate, setIssueDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [customItemDescription, setCustomItemDescription] = useState<string>('');
  const [paymentTerms, setPaymentTerms] = useState<string>('Due within 14 calendar days via international wire transfer.');
  const [invoiceNotes, setInvoiceNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Initialize or reset form when trip or type changes
  useEffect(() => {
    if (!selectedTrip) return;
    const year = new Date().getFullYear();
    const rand = Math.floor(1000 + Math.random() * 9000);
    setInvoiceNumber(`INV-${year}-${rand}`);

    if (preselectedTripId) {
      setSelectedTripId(preselectedTripId);
    }
  }, [selectedTripId, preselectedTripId, selectedTrip]);

  // Sync default type when existing invoices change
  useEffect(() => {
    if (defaultInvoiceType) {
      setInvoiceType(defaultInvoiceType);
    } else if (existingTourInvoices.length > 0 && remainingUninvoiced > 0) {
      setInvoiceType('balance');
    } else {
      setInvoiceType('full');
    }
  }, [selectedTripId, existingTourInvoices.length, remainingUninvoiced, defaultInvoiceType]);

  // Calculate actual amount to invoice
  const calculatedInvoiceAmount = useMemo(() => {
    if (!selectedTrip) return 0;

    if (invoiceType === 'full') {
      // If there are existing invoices, "full" covers whatever remaining balance is left to make it 100%
      return remainingUninvoiced > 0 ? remainingUninvoiced : totalTourPrice;
    }

    if (invoiceType === 'balance') {
      return remainingUninvoiced;
    }

    // Part payment / Deposit
    if (partPaymentMode === 'percentage') {
      const pct = Math.max(1, Math.min(99, percentageInput));
      return Math.round((totalTourPrice * pct) / 100);
    }

    if (partPaymentMode === 'deposit') {
      return selectedTrip.depositRequired || Math.round(totalTourPrice * 0.3);
    }

    // Custom
    return Number(customAmountInput) || 0;
  }, [
    selectedTrip,
    invoiceType,
    remainingUninvoiced,
    totalTourPrice,
    partPaymentMode,
    percentageInput,
    customAmountInput,
  ]);

  // Calculate what balance will remain AFTER this invoice
  const balanceAfterThisInvoice = Math.max(0, remainingUninvoiced - calculatedInvoiceAmount);
  const percentCoveredByThisInvoice =
    totalTourPrice > 0 ? Math.round((calculatedInvoiceAmount / totalTourPrice) * 1000) / 10 : 0;

  // Auto-generate sensible default description when inputs change
  useEffect(() => {
    if (!selectedTrip) return;
    const tourTitle = selectedTrip.tourName || selectedTrip.title;

    if (invoiceType === 'part') {
      setCustomItemDescription(
        `Tour Deposit & Part Payment (${percentCoveredByThisInvoice}%): ${tourTitle} (${selectedTrip.days.length} Days)`
      );
      setPaymentTerms('Deposit required within 7 calendar days to confirm suppliers and reservations.');
    } else if (invoiceType === 'balance') {
      const parentNum = existingTourInvoices.map((i) => i.invoiceNumber).join(', ');
      setCustomItemDescription(
        `Final Tour Balance Payment: ${tourTitle} (${percentCoveredByThisInvoice}% balance remaining following Invoice #${parentNum})`
      );
      setPaymentTerms('Final balance due 30 days prior to tour commencement via wire transfer.');
    } else {
      setCustomItemDescription(
        `Complete Private Tour Package: ${tourTitle} (${selectedTrip.days.length} Days, ${selectedTrip.partySize} Guests)`
      );
      setPaymentTerms('Due within 14 calendar days via international wire transfer.');
    }
  }, [selectedTrip, invoiceType, percentCoveredByThisInvoice, existingTourInvoices]);

  if (!isOpen || !selectedTrip) return null;

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (calculatedInvoiceAmount <= 0) {
      setFormError('Invoice amount must be greater than 0.');
      return;
    }

    if (invoiceType === 'part' && calculatedInvoiceAmount >= totalTourPrice) {
      setFormError(
        'A part payment invoice cannot be equal to or greater than the total tour price. Please select "Full Payment" instead.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const currency = selectedTrip.currency || 'USD';
      const fxRate = exchangeRates[currency]?.rateAgainstUSD || 1;
      const parentInvoices = existingTourInvoices.map((i) => i.invoiceNumber).join(', ');

      const newInvoice: Invoice = {
        id: `inv-${Date.now()}`,
        invoiceNumber: invoiceNumber.trim() || `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        tripId: selectedTrip.id,
        clientId: client?.id || selectedTrip.clientId,
        issueDate,
        dueDate,
        currency,
        exchangeRateApplied: fxRate,
        subtotal: calculatedInvoiceAmount,
        taxRatePercent: 0,
        taxAmount: 0,
        totalAmount: calculatedInvoiceAmount,
        amountPaid: 0,
        balanceDue: calculatedInvoiceAmount,
        status: 'Sent',
        invoiceType: invoiceType === 'part' ? 'deposit' : invoiceType,
        partPaymentPercentage: percentCoveredByThisInvoice,
        parentInvoiceNumber: parentInvoices || undefined,
        totalTourPriceSnapshot: totalTourPrice,
        items: [
          {
            id: `item-${Date.now()}`,
            description: customItemDescription.trim(),
            quantity: 1,
            unitPrice: calculatedInvoiceAmount,
            amount: calculatedInvoiceAmount,
          },
        ],
        paymentTerms: paymentTerms.trim(),
        payments: [],
        notes: invoiceNotes.trim() || undefined,
      };

      await addInvoice(newInvoice);

      if (onInvoiceCreated) {
        onInvoiceCreated(newInvoice);
      }
      onClose();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create invoice.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 my-auto space-y-5 animate-scale-in max-h-[92vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 font-bold">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Create Tour Invoice
              </h3>
              <p className="text-xs text-slate-500">
                Issue full payment, part payment / deposit, or remaining balance invoices.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {formError && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleCreateInvoice} className="space-y-5">
          {/* 1. Tour Selection */}
          <div>
            <label className="text-xs font-extrabold uppercase tracking-wider text-slate-700 block mb-1.5">
              Select Tour / Itinerary
            </label>
            <select
              value={selectedTripId}
              onChange={(e) => setSelectedTripId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
            >
              {itineraries.map((trip) => {
                const c = clients.find((cl) => cl.id === trip.clientId);
                return (
                  <option key={trip.id} value={trip.id}>
                    {trip.code} &bull; {trip.tourName || trip.title} ({formatMoney(trip.totalClientPrice, trip.currency)}) - Client: {c?.name || 'Client'}
                  </option>
                );
              })}
            </select>
          </div>

          {/* Tour Invoicing Status Overview Card */}
          <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/60 pb-2.5">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  {selectedTrip.destination} &bull; {selectedTrip.days.length} Days
                </span>
                <h4 className="text-base font-black text-white">
                  {selectedTrip.tourName || selectedTrip.title}
                </h4>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">Client</span>
                <span className="text-xs font-bold text-white">{client?.name || 'VIP Client'}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 sm:gap-4 text-center">
              <div className="bg-white/5 rounded-xl p-2.5 border border-white/10">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Total Tour Price
                </span>
                <span className="text-sm sm:text-base font-black text-white">
                  {formatMoney(totalTourPrice, selectedTrip.currency)}
                </span>
              </div>

              <div className="bg-white/5 rounded-xl p-2.5 border border-white/10">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Already Invoiced
                </span>
                <span className="text-sm sm:text-base font-black text-amber-300">
                  {formatMoney(totalInvoicedToDate, selectedTrip.currency)}
                </span>
                <span className="text-[9px] text-slate-400 block font-semibold">
                  {existingTourInvoices.length} invoice(s)
                </span>
              </div>

              <div className="bg-white/5 rounded-xl p-2.5 border border-white/10">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Un-invoiced Balance
                </span>
                <span
                  className={`text-sm sm:text-base font-black ${
                    remainingUninvoiced > 0 ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                >
                  {formatMoney(remainingUninvoiced, selectedTrip.currency)}
                </span>
              </div>
            </div>

            {/* Existing prior invoices list if any */}
            {existingTourInvoices.length > 0 && (
              <div className="pt-1 text-[11px] text-slate-300">
                <span className="font-bold text-amber-400">Existing Invoices on this Tour: </span>
                {existingTourInvoices.map((inv, idx) => (
                  <span key={inv.id} className="inline-block bg-white/10 px-2 py-0.5 rounded-md mr-1.5 mt-1 font-mono">
                    #{inv.invoiceNumber}: {formatMoney(inv.totalAmount, inv.currency)} ({inv.invoiceType || 'Standard'})
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* 2. Invoicing Type Selector: Full vs Part vs Balance */}
          <div>
            <label className="text-xs font-extrabold uppercase tracking-wider text-slate-700 block mb-2">
              Invoice Type &amp; Payment Structure
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Option 1: Full Payment */}
              <button
                type="button"
                onClick={() => setInvoiceType('full')}
                className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  invoiceType === 'full'
                    ? 'border-amber-500 bg-amber-50/40 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">Full Payment</span>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      invoiceType === 'full'
                        ? 'border-amber-600 bg-amber-500 text-slate-950'
                        : 'border-slate-300'
                    }`}
                  >
                    {invoiceType === 'full' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Invoice the entire tour amount in one single invoice (100%).
                </p>
                <div className="text-xs font-mono font-bold text-slate-900 mt-2">
                  {formatMoney(
                    remainingUninvoiced > 0 ? remainingUninvoiced : totalTourPrice,
                    selectedTrip.currency
                  )}
                </div>
              </button>

              {/* Option 2: Part Payment / Deposit */}
              <button
                type="button"
                onClick={() => setInvoiceType('part')}
                className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  invoiceType === 'part'
                    ? 'border-amber-500 bg-amber-50/40 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900">Part Payment / Deposit</span>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      invoiceType === 'part'
                        ? 'border-amber-600 bg-amber-500 text-slate-950'
                        : 'border-slate-300'
                    }`}
                  >
                    {invoiceType === 'part' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Invoice an initial installment or deposit. You can invoice the balance later.
                </p>
                <div className="text-xs font-bold text-amber-700 mt-2">
                  Pick % or custom amount
                </div>
              </button>

              {/* Option 3: Remaining Balance Invoice */}
              <button
                type="button"
                onClick={() => setInvoiceType('balance')}
                disabled={remainingUninvoiced <= 0}
                className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between ${
                  remainingUninvoiced <= 0
                    ? 'opacity-50 border-slate-100 bg-slate-50 cursor-not-allowed'
                    : invoiceType === 'balance'
                    ? 'border-emerald-500 bg-emerald-50/40 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black text-slate-900">Balance Invoice</span>
                    {existingTourInvoices.length > 0 && remainingUninvoiced > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase bg-emerald-100 text-emerald-800">
                        Ready
                      </span>
                    )}
                  </div>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      invoiceType === 'balance'
                        ? 'border-emerald-600 bg-emerald-500 text-white'
                        : 'border-slate-300'
                    }`}
                  >
                    {invoiceType === 'balance' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Invoice the exact remaining balance left after prior payments.
                </p>
                <div className="text-xs font-mono font-bold text-emerald-700 mt-2">
                  {formatMoney(remainingUninvoiced, selectedTrip.currency)}
                </div>
              </button>
            </div>
          </div>

          {/* Part Payment Customization Controls */}
          {invoiceType === 'part' && (
            <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-2xl space-y-3.5 animate-fade-in">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>Choose Part Payment / Deposit Calculation:</span>
                </span>
                <span className="text-[11px] font-bold text-amber-800">
                  Tour Total: {formatMoney(totalTourPrice, selectedTrip.currency)}
                </span>
              </div>

              {/* Preset percentage buttons */}
              <div className="flex flex-wrap gap-2">
                {[20, 25, 30, 40, 50].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => {
                      setPartPaymentMode('percentage');
                      setPercentageInput(pct);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      partPaymentMode === 'percentage' && percentageInput === pct
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {pct}% ({formatMoney(Math.round((totalTourPrice * pct) / 100), selectedTrip.currency)})
                  </button>
                ))}

                {selectedTrip.depositRequired > 0 && (
                  <button
                    type="button"
                    onClick={() => setPartPaymentMode('deposit')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      partPaymentMode === 'deposit'
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Tour Deposit ({formatMoney(selectedTrip.depositRequired, selectedTrip.currency)})
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setPartPaymentMode('custom')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    partPaymentMode === 'custom'
                      ? 'bg-amber-500 text-slate-950 shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Custom Amount
                </button>
              </div>

              {/* Custom amount input */}
              {partPaymentMode === 'custom' && (
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs font-bold text-slate-700">Enter Exact Amount:</span>
                  <div className="relative flex-1">
                    <input
                      type="number"
                      min="1"
                      max={totalTourPrice - 1}
                      value={customAmountInput}
                      onChange={(e) => setCustomAmountInput(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold"
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-600">{selectedTrip.currency}</span>
                </div>
              )}

              {/* Summary of this invoice & the future balance */}
              <div className="p-3 bg-white rounded-xl border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block">This Part Payment Invoice:</span>
                  <span className="text-sm font-black text-slate-900">
                    {formatMoney(calculatedInvoiceAmount, selectedTrip.currency)} ({percentCoveredByThisInvoice}%)
                  </span>
                </div>
                <div className="sm:text-right">
                  <span className="text-slate-500 block">Remaining for Subsequent Balance Invoice:</span>
                  <span className="text-sm font-black text-amber-700">
                    {formatMoney(balanceAfterThisInvoice, selectedTrip.currency)} ({(100 - percentCoveredByThisInvoice).toFixed(1)}%)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Balance Invoice Explanatory Callout */}
          {invoiceType === 'balance' && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 text-xs space-y-1 animate-fade-in">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Generating Balance Invoice for Remaining Tour Balance</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                This invoice will be issued for <strong>{formatMoney(remainingUninvoiced, selectedTrip.currency)}</strong>, covering the remaining {percentCoveredByThisInvoice}% of the tour package.
                {existingTourInvoices.length > 0 && ` References prior invoice(s): #${existingTourInvoices.map((i) => i.invoiceNumber).join(', ')}.`}
              </p>
            </div>
          )}

          {/* 3. Invoice Number, Dates & Terms */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase">Invoice #</label>
              <input
                type="text"
                required
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono font-bold"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase">Issue Date</label>
              <input
                type="date"
                required
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase">Due Date</label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-bold text-amber-900"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">
              Line Item Description (on Client PDF)
            </label>
            <input
              type="text"
              required
              value={customItemDescription}
              onChange={(e) => setCustomItemDescription(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-semibold text-slate-900"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Payment Terms &amp; Wire Memo</label>
            <input
              type="text"
              value={paymentTerms}
              onChange={(e) => setPaymentTerms(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting || calculatedInvoiceAmount <= 0}
              className="px-6 py-2.5 bg-slate-950 hover:bg-slate-800 text-amber-400 font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Receipt className="w-4 h-4 text-amber-400" />
              <span>
                {invoiceType === 'part'
                  ? `Create Part Payment Invoice (${formatMoney(calculatedInvoiceAmount, selectedTrip.currency)})`
                  : invoiceType === 'balance'
                  ? `Create Balance Invoice (${formatMoney(calculatedInvoiceAmount, selectedTrip.currency)})`
                  : `Create Full Tour Invoice (${formatMoney(calculatedInvoiceAmount, selectedTrip.currency)})`}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

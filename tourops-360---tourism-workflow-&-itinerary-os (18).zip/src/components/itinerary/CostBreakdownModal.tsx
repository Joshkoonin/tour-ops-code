import React from 'react';
import { DollarSign, X } from 'lucide-react';
import { Itinerary, ItineraryActivity, GeneralProjectedCostItem } from '../../types';

interface CostBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  type: 'activity' | 'general';
  data: (ItineraryActivity | GeneralProjectedCostItem)[];
  trip: Itinerary;
  convertCurrency: (amount: number, from: string, to: string) => number;
  formatMoney: (amount: number, currency: string) => string;
}

export const CostBreakdownModal: React.FC<CostBreakdownModalProps> = ({
  isOpen,
  onClose,
  title,
  type,
  data,
  trip,
  convertCurrency,
  formatMoney,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-base font-extrabold text-slate-900">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {data.map((item, index) => {
            const cost = type === 'activity' 
                ? ((item as ItineraryActivity).ourCost ?? (item as ItineraryActivity).costEstimate ?? 0)
                : ((item as GeneralProjectedCostItem).estimatedAmount ?? (item as GeneralProjectedCostItem).costEstimate ?? 0);
            const currency = type === 'activity' 
                ? (item as ItineraryActivity).currency || trip.currency
                : (item as GeneralProjectedCostItem).currency || trip.currency;
            
            return (
              <div key={index} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-800">{type === 'activity' ? (item as ItineraryActivity).title : (item as GeneralProjectedCostItem).title}</span>
                <span className="font-mono font-bold text-slate-900">{formatMoney(convertCurrency(cost, currency, 'USD'), 'USD')}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

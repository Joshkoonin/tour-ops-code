import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Check,
  Sparkles,
  Link as LinkIcon,
  Loader2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { compressAndReadImageFile, TRAVEL_HERO_PRESETS } from '../../utils/imageUtils';

interface HeroPhotoModalProps {
  isOpen: boolean;
  currentPhotoUrl?: string;
  tripTitle?: string;
  destination?: string;
  onClose: () => void;
  onSave: (newPhotoUrl: string) => void;
}

export const HeroPhotoModal: React.FC<HeroPhotoModalProps> = ({
  isOpen,
  currentPhotoUrl,
  tripTitle,
  destination,
  onClose,
  onSave,
}) => {
  const [photoUrl, setPhotoUrl] = useState<string>(
    currentPhotoUrl?.trim() ||
      'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1600&auto=format&fit=crop&q=80'
  );
  const [urlInput, setUrlInput] = useState<string>(currentPhotoUrl || '');
  const [activeTab, setActiveTab] = useState<'upload' | 'presets' | 'url'>('upload');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setErrorMessage(null);
    setSuccessNotice(null);

    try {
      const compressedDataUrl = await compressAndReadImageFile(file, 1600, 1000, 0.85);
      setPhotoUrl(compressedDataUrl);
      setUrlInput('');
      setSuccessNotice(`Photo "${file.name}" uploaded and optimized successfully!`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to upload photo. Please try a different image.');
    } finally {
      setIsProcessing(false);
      // Reset input value so same file can be re-selected if desired
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleApplyUrl = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!urlInput.trim()) {
      setErrorMessage('Please enter a valid image URL.');
      return;
    }
    setPhotoUrl(urlInput.trim());
    setErrorMessage(null);
    setSuccessNotice('Image URL applied to preview!');
  };

  const handleSelectPreset = (presetUrl: string) => {
    setPhotoUrl(presetUrl);
    setUrlInput(presetUrl);
    setErrorMessage(null);
    setSuccessNotice('Preset photo selected!');
  };

  const handleSaveAndConfirm = () => {
    if (!photoUrl.trim()) {
      setErrorMessage('Please select or upload a hero photo.');
      return;
    }
    onSave(photoUrl.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-hidden shadow-2xl border border-slate-200 flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 leading-tight">
                Change Itinerary Hero Photo
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {tripTitle ? `${tripTitle} • ` : ''}
                {destination || 'Tour Cover & Client Portal Banner'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {/* Live Hero Banner Preview */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Live Hero Preview (How Clients &amp; Guides See It)
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                16:9 High-Def Panorama
              </span>
            </div>

            <div className="relative h-48 sm:h-56 w-full rounded-2xl overflow-hidden shadow-md border border-slate-200 bg-slate-900 group">
              <img
                src={photoUrl}
                alt="Itinerary Hero Preview"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1600&auto=format&fit=crop&q=80';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/25 to-transparent flex flex-col justify-end p-4 text-white">
                <span className="text-[11px] font-black uppercase tracking-widest text-amber-300">
                  {destination || 'Luxury Private Journey'}
                </span>
                <h3 className="text-lg font-black drop-shadow-xs line-clamp-1">
                  {tripTitle || 'Custom Itinerary'}
                </h3>
              </div>
            </div>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Method Tabs */}
          <div className="flex border-b border-slate-200">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`pb-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'upload'
                  ? 'border-amber-500 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Photo from Device</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className={`pb-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'presets'
                  ? 'border-amber-500 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Curated Presets</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`pb-2.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'url'
                  ? 'border-amber-500 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <LinkIcon className="w-3.5 h-3.5" />
              <span>Paste Image URL</span>
            </button>
          </div>

          {/* Tab 1: Upload from Computer */}
          {activeTab === 'upload' && (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              <div
                onClick={() => !isProcessing && fileInputRef.current?.click()}
                className={`p-6 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                  isProcessing
                    ? 'border-amber-300 bg-amber-50/40 cursor-wait'
                    : 'border-slate-300 hover:border-amber-500 hover:bg-amber-50/20 bg-slate-50'
                }`}
              >
                {isProcessing ? (
                  <div className="flex flex-col items-center space-y-2 py-3">
                    <Loader2 className="w-8 h-8 text-amber-600 animate-spin" />
                    <span className="text-xs font-bold text-amber-900">
                      Optimizing and compressing high-res photo...
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Preparing retina resolution for fast loading
                    </span>
                  </div>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mb-2.5 shadow-2xs">
                      <Upload className="w-6 h-6" />
                    </div>
                    <span className="text-sm font-black text-slate-900">
                      Click to Browse &amp; Upload Photo
                    </span>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm">
                      Supports JPG, PNG, WebP, GIF, or camera photos from your computer or mobile
                      device. Auto-optimized for instant cloud sync.
                    </p>
                    <button
                      type="button"
                      className="mt-3.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5 text-amber-400" />
                      <span>Select Photo File</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Tab 2: Curated Presets */}
          {activeTab === 'presets' && (
            <div className="space-y-2">
              <p className="text-xs text-slate-500">
                Select a high-resolution professional travel photograph for this itinerary:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                {TRAVEL_HERO_PRESETS.map((preset) => {
                  const isSelected = photoUrl === preset.url;
                  return (
                    <button
                      type="button"
                      key={preset.id}
                      onClick={() => handleSelectPreset(preset.url)}
                      className={`group relative rounded-xl overflow-hidden border-2 text-left transition-all aspect-video cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 ring-2 ring-amber-400/50 shadow-sm'
                          : 'border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <img
                        src={preset.url}
                        alt={preset.title}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2 text-white">
                        <span className="text-[10px] font-bold leading-tight line-clamp-1">
                          {preset.title}
                        </span>
                        <span className="text-[9px] text-amber-300 font-semibold line-clamp-1">
                          {preset.destination}
                        </span>
                      </div>
                      {isSelected && (
                        <div className="absolute top-1.5 right-1.5 w-5 h-5 bg-amber-500 text-slate-950 rounded-full flex items-center justify-center font-black shadow-xs">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab 3: Direct URL */}
          {activeTab === 'url' && (
            <form onSubmit={handleApplyUrl} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase">
                  Image Web Address (URL)
                </label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:border-amber-500 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Preview URL</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Paste any public high-resolution HTTPS image link from Unsplash, Wikimedia, or your
                  company CDN.
                </p>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200/60 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveAndConfirm}
            disabled={isProcessing}
            className="px-5 py-2.5 bg-slate-950 hover:bg-slate-800 text-amber-400 font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Check className="w-4 h-4 text-amber-400 stroke-[3]" />
            <span>Apply &amp; Save Hero Photo</span>
          </button>
        </div>
      </div>
    </div>
  );
};

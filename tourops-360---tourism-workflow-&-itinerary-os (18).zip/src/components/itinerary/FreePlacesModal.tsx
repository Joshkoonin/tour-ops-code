import React, { useState } from 'react';
import { X, UserCheck, CheckCircle2 } from 'lucide-react';
import { Itinerary } from '../../types';

interface FreePlacesModalProps {
  isOpen: boolean;
  onClose: () => void;
  trip: Itinerary;
  onSave: (freePlaces: { count: number; agencyName?: string; note?: string }) => void;
}

export const FreePlacesModal: React.FC<FreePlacesModalProps> = ({
  isOpen,
  onClose,
  trip,
  onSave,
}) => {
  const [count, setCount] = useState(trip.freePlaces?.count || 0);
  const [agencyName, setAgencyName] = useState(trip.freePlaces?.agencyName || '');
  const [note, setNote] = useState(trip.freePlaces?.note || '');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-500 text-white flex items-center justify-center font-bold">
              <UserCheck className="w-4 h-4" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900">Configure Partner Free Places</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Number of Free Places</label>
            <input
              type="number"
              min="0"
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className="w-full mt-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900"
            />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Travel Agency Name</label>
            <input
              type="text"
              value={agencyName}
              onChange={(e) => setAgencyName(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
            />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Note</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button onClick={onClose} className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl">Cancel</button>
          <button
            onClick={() => onSave({ count, agencyName, note })}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4 text-indigo-400" />
            <span>Save Allocation</span>
          </button>
        </div>
      </div>
    </div>
  );
};

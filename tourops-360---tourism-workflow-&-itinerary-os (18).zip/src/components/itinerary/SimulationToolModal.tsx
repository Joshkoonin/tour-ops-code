import React, { useState, useMemo } from 'react';
import {
  X,
  Sparkles,
  Calculator,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  Plus,
  Trash2,
  RefreshCw,
  Info,
  DollarSign,
  Users,
  ShieldAlert,
  Sliders,
} from 'lucide-react';
import { Itinerary, PricingBand, CurrencyCode } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  calculatePricing,
  calculateTourFixedAndUnitCosts,
  calculateFreePlaceCosts,
  roundUpToCurrency,
  PricingCalculationResult,
} from '../../utils/financialCalculations';

interface SimulationToolModalProps {
  itinerary: Itinerary;
  onClose: () => void;
}

interface EditableBand {
  id: string;
  minGuests: number;
  maxGuests: number;
  pricePerGuest: number;
  freePlaces: number;
}

export const SimulationToolModal: React.FC<SimulationToolModalProps> = ({
  itinerary,
  onClose,
}) => {
  const { hotels, convertCurrency, formatMoney, updateItinerary } = useApp();
  const currency: CurrencyCode = itinerary.currency || 'USD';

  // Calculate actual tour cost structure (F and P) from current itinerary schedule
  const costStructure = useMemo(() => {
    return calculateTourFixedAndUnitCosts(itinerary, hotels, convertCurrency, currency);
  }, [itinerary, hotels, convertCurrency, currency]);

  const P_total = costStructure.totalPerPersonCost;
  const V = costStructure.perPersonActivityCosts + costStructure.generalPerPersonCosts;
  const H = costStructure.hotelPerPersonCosts;
  
  // Explicitly derive Fbase by removing existing free place allowance
  const existingAllowance = calculateFreePlaceCosts(itinerary, V, H);
  const Fbase = costStructure.totalFixedCost - existingAllowance.totalGlobalCost;

  // -------------------------------------------------------------
  // SECTION 2: EDITABLE PRICING SCALE & BANDS
  // -------------------------------------------------------------
  const [bands, setBands] = useState<EditableBand[]>(
    (itinerary.pricingBands || []).map((b, i) => ({
      id: `band-${i}`,
      minGuests: Math.max(1, b.minGuests),
      maxGuests: Math.max(1, b.maxGuests ?? b.minGuests),
      pricePerGuest: b.pricePerGuest,
      freePlaces: b.freePlaces ?? itinerary.freePlaces?.count ?? 0,
    }))
  );

  const [bandsValidationError, setBandsValidationError] = useState<string | null>(null);

  const validateBands = (list: EditableBand[]): string | null => {
    for (let i = 0; i < list.length; i++) {
      if (list[i].minGuests > list[i].maxGuests) return `Band ${i + 1}: Min > Max`;
      if (list[i].freePlaces < 0) return `Band ${i + 1}: Free places cannot be negative`;
    }
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        if (Math.max(list[i].minGuests, list[j].minGuests) <= Math.min(list[i].maxGuests, list[j].maxGuests)) {
          return `Bands ${i + 1} and ${j + 1} overlap`;
        }
      }
    }
    return null;
  };

  const handleBandChange = (id: string, field: keyof EditableBand, val: number) => {
    const updated = bands.map(b => b.id === id ? { ...b, [field]: val } : b);
    setBands(updated);
    setBandsValidationError(validateBands(updated));
  };

  const addBand = () => setBands([...bands, { id: `b-${Date.now()}`, minGuests: 1, maxGuests: 1, pricePerGuest: 0, freePlaces: 0 }]);
  const removeBand = (id: string) => setBands(bands.filter(b => b.id !== id));

  const pricingTableRows = useMemo(() => {
    const rows: any[] = [];
    bands.forEach((band, idx) => {
      for (let guests = band.minGuests; guests <= band.maxGuests; guests++) {
        const N = guests;
        const Q = band.freePlaces; // Using per-band free places
        const S = band.pricePerGuest;
        
        const revenue = N * S;
        
        // Free place costs: V (Non-hotel) + 2 * H (Twice hotel cost)
        const costPerFreePlace = V + (2 * H);
        const freePlaceCosts = Q * costPerFreePlace;
        
        // Total costs: Fixed costs + variable costs for N paying guests + variable costs for Q free guests
        // Variable cost per paying guest = V + H
        // Variable cost per free guest = V + 2H
        const totalCosts = Fbase + (N * (V + H)) + (Q * (V + 2 * H));
        
        if (guests === band.minGuests) {
            console.log('Simulation Debug:', {
                guests, Q, S, revenue,
                V, H, Fbase,
                costPerFreePlace,
                freePlaceCosts,
                totalCosts
            });
        }
        
        const profit = revenue - totalCosts;
        const margin = revenue === 0 ? null : (profit / revenue) * 100;
        const breakEven = totalCosts / N;

        rows.push({
          guests: N,
          freePlaces: Q,
          totalPeople: N + Q,
          salePrice: S,
          revenue: revenue,
          freePlaceCosts: freePlaceCosts,
          totalCosts: totalCosts,
          profit: profit,
          profitPerPerson: profit / N,
          marginPercent: margin,
          breakEven: breakEven,
        });
      }
    });
    return rows;
  }, [bands, Fbase, V, H]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-6xl w-full p-6 shadow-2xl border border-slate-200 space-y-6 max-h-[92vh] overflow-y-auto">
        <h2 className="text-xl font-black">Cost and Profit Simulation</h2>

        {/* 2. Pricing Bands */}
        <div className="space-y-3">
          <h3 className="font-bold">Pricing Bands</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '4rem 4rem 6rem 6rem 2rem', gap: '0.5rem' }} className="text-xs font-bold text-slate-500">
            <div>From</div><div>To</div><div>Price</div><div>Free Places</div><div></div>
          </div>
          {bands.map(b => (
            <div key={b.id} style={{ display: 'grid', gridTemplateColumns: '4rem 4rem 6rem 6rem 2rem', gap: '0.5rem', alignItems: 'center' }}>
              <input type="number" min="1" value={b.minGuests} onChange={e => handleBandChange(b.id, 'minGuests', parseInt(e.target.value))} className="w-full border p-1" />
              <input type="number" min="1" value={b.maxGuests} onChange={e => handleBandChange(b.id, 'maxGuests', parseInt(e.target.value))} className="w-full border p-1" />
              <input type="number" value={b.pricePerGuest} onChange={e => handleBandChange(b.id, 'pricePerGuest', Number(e.target.value))} className="w-full border p-1" />
              <input type="number" min="0" value={b.freePlaces} onChange={e => handleBandChange(b.id, 'freePlaces', parseInt(e.target.value))} className="w-full border p-1" />
              <button onClick={() => removeBand(b.id)} className="text-red-500 flex justify-center">X</button>
            </div>
          ))}
          <button onClick={addBand} className="px-2 py-1 bg-slate-200 rounded text-xs">Add Band</button>
        </div>

        {/* 3. Results Table */}
        <div className="overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr>
              <th>Paying</th><th>Free</th><th>Total</th><th>Price</th><th>Revenue</th><th>Free Cost</th><th>Total Cost</th><th>Profit</th><th>Profit/Pay</th><th>Margin</th><th>Break-even</th>
            </tr>
          </thead>
          <tbody>
            {pricingTableRows.map((r, i) => (
              <tr key={i} className={r.profit < 0 ? 'bg-red-50' : ''}>
                <td>{r.guests}</td>
                <td>{r.freePlaces}</td>
                <td>{r.totalPeople}</td>
                <td>{formatMoney(r.salePrice, currency)}</td>
                <td>{formatMoney(r.revenue, currency)}</td>
                <td>{formatMoney(r.freePlaceCosts, currency)}</td>
                <td>{formatMoney(r.totalCosts, currency)}</td>
                <td>{formatMoney(r.profit, currency)}</td>
                <td>{formatMoney(r.profitPerPerson, currency)}</td>
                <td>{r.marginPercent !== null ? r.marginPercent.toFixed(1) + '%' : 'N/A'}</td>
                <td>{formatMoney(r.breakEven, currency)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>

        <div className="flex gap-2">
          <button onClick={onClose} className="px-4 py-2 bg-slate-200 rounded-lg">Cancel</button>
          <button onClick={() => {
            if (bandsValidationError) {
              alert(bandsValidationError);
              return;
            }
            updateItinerary({
              ...itinerary,
              pricingBands: bands.map(b => ({
                minGuests: b.minGuests,
                maxGuests: b.maxGuests,
                pricePerGuest: b.pricePerGuest,
                freePlaces: b.freePlaces,
              }))
            }).then(() => onClose());
          }} className="px-4 py-2 bg-amber-500 text-white rounded-lg">Save Simulation</button>
        </div>
      </div>
    </div>
  );
};

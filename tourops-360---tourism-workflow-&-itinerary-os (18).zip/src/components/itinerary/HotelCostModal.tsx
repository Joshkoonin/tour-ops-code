import React, { useState } from 'react';
import { X, Building, DollarSign } from 'lucide-react';

interface HotelCostModalProps {
  hotelName: string;
  nights: { id: string; date: string; dayNumber: number }[];
  onConfirm: (config: { costBasis: 'global' | 'perPerson'; ourCost: number; currency: string }) => void;
  onCancel: () => void;
}

export const HotelCostModal: React.FC<HotelCostModalProps> = ({ hotelName, nights, onConfirm, onCancel }) => {
  const [costBasis, setCostBasis] = useState<'global' | 'perPerson'>('global');
  const [ourCost, setOurCost] = useState<number | ''>('');
  const [currency] = useState('USD'); // Default to USD for now based on project context

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ourCost === '' || ourCost < 0) return;
    onConfirm({ costBasis, ourCost: Number(ourCost), currency });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-slate-900">Configure Hotel Cost</h2>
          <button onClick={onCancel} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>
        
        <p className="text-sm text-slate-600">
          Enter the cost for <strong className="text-slate-900">{hotelName}</strong> for {nights.length} night{nights.length > 1 ? 's' : ''}.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Cost Basis *</label>
            <select
              value={costBasis}
              onChange={(e) => setCostBasis(e.target.value as 'global' | 'perPerson')}
              className="w-full mt-1 px-3 py-2 text-sm border border-slate-300 rounded-xl"
            >
              <option value="global">Our cost global (Total for group)</option>
              <option value="perPerson">Our cost per person</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 uppercase">Amount *</label>
            <div className="relative mt-1">
              <DollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="number"
                required
                min="0"
                value={ourCost}
                onChange={(e) => setOurCost(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl"
                placeholder="Enter nightly amount"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl">Cancel</button>
            <button type="submit" disabled={ourCost === ''} className="px-6 py-2 bg-slate-900 text-white font-bold text-sm rounded-xl hover:bg-black disabled:opacity-50">Confirm Hotel Night</button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Itinerary } from '../../types';

interface CopyItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  itinerary: Itinerary;
  onConfirm: (newName: string) => void;
}

export const CopyItineraryModal: React.FC<CopyItineraryModalProps> = ({
  isOpen,
  onClose,
  itinerary,
  onConfirm,
}) => {
  const [newName, setNewName] = useState(`${itinerary.title} (Copy)`);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">Duplicate Itinerary</h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded-full cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">New Title</label>
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all"
            autoFocus
          />
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-xl transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(newName)}
            className="flex-1 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl transition-colors cursor-pointer"
          >
            Create Copy
          </button>
        </div>
      </div>
    </div>
  );
};

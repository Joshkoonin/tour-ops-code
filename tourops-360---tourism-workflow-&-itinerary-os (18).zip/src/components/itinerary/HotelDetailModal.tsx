import React, { useState } from 'react';
import {
  X,
  Star,
  MapPin,
  Clock,
  Phone,
  Wifi,
  Sparkles,
  ShieldCheck,
  Building,
  Check,
  ExternalLink,
} from 'lucide-react';
import { HotelInfo } from '../../types';
import { useApp } from '../../context/AppContext';

interface HotelDetailModalProps {
  hotel: HotelInfo | null;
  onClose: () => void;
}

export const HotelDetailModal: React.FC<HotelDetailModalProps> = ({ hotel, onClose }) => {
  const { hasFullFinancialView, deleteHotel, updateHotel } = useApp();
  const [editingPrice, setEditingPrice] = useState(hotel?.pricePerNight || 0);

  if (!hotel) return null;

  const handleSavePrice = async () => {
    await updateHotel({ ...hotel, pricePerNight: editingPrice });
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/60 hover:bg-white text-slate-900 backdrop-blur-xs transition-colors z-[101]"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hotel Title */}
        <div className="p-6 sm:px-8 pt-8 pb-4">
          <div className="flex items-center space-x-2 mb-1.5">
            <div className="flex text-amber-500">
              {Array.from({ length: hotel.starRating }).map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-500" />
              ))}
            </div>
            <span className="text-xs bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
              {hotel.boardBasis}
            </span>
          </div>
          <h2 className="text-2xl font-bold font-serif-display text-slate-900">
            {hotel.name}
          </h2>
          <div className="flex items-center text-xs text-slate-500 mt-1 space-x-1">
            <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>{hotel.address}</span>
          </div>
        </div>


        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Key Specs Grid - Only show if data exists */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {hotel.roomType && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Room Category
                </div>
                <div className="text-xs font-bold text-slate-900 mt-1 truncate">
                  {hotel.roomType}
                </div>
              </div>
            )}
            {hotel.checkInTime && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Check-in / Out
                </div>
                <div className="text-xs font-bold text-slate-900 mt-1">
                  {hotel.checkInTime} / {hotel.checkOutTime}
                </div>
              </div>
            )}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Booking Reference
              </div>
              <div className="text-xs font-mono font-bold text-amber-700 mt-1">
                {hotel.confirmationRef || 'TO-DIRECT-CONFIRM'}
              </div>
            </div>
            {hasFullFinancialView && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Contract Rate ({hotel.currency})
                </div>
                <input
                  type="number"
                  value={editingPrice}
                  onChange={(e) => setEditingPrice(Number(e.target.value))}
                  onBlur={handleSavePrice}
                  className="w-full text-xs font-bold text-slate-900 mt-1 bg-white border border-slate-300 rounded-lg px-2 py-1"
                />
              </div>
            )}
          </div>

          {/* Description */}
          {hotel.description && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                Property Overview & Character
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed">{hotel.description}</p>
            </div>
          )}
          
          {/* Amenities & Highlight omitted for brevity in thought, but must keep in actual code */}
          {hotel.amenities && hotel.amenities.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Complimentary VIP Amenities & Inclusions</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {hotel.amenities.map((amenity, idx) => (
                  <div
                    key={idx}
                    className="flex items-center space-x-2 text-xs text-slate-800 bg-amber-50/50 border border-amber-100 px-3 py-2 rounded-lg"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="font-medium">{amenity}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Concierge Notes */}
          {hotel.conciergeNotes && (
            <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl border border-slate-800">
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Concierge Protocol & Room Directives</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-300">
                {hotel.conciergeNotes}
              </p>
            </div>
          )}

          {/* Gallery Thumbnails */}
          {hotel.galleryUrls && hotel.galleryUrls.filter(img => img && img.trim()).length > 1 && (
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                Property Gallery
              </div>
              <div className="grid grid-cols-3 gap-3">
                {hotel.galleryUrls.filter(img => img && img.trim()).map((img, i) => (
                  <img
                    key={i}
                    src={img.trim()}
                    alt={`${hotel.name} ${i + 1}`}
                    className="h-24 w-full object-cover rounded-xl border border-slate-200 shadow-2xs hover:opacity-90 transition-opacity"
                  />
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:px-8 border-t border-slate-200 bg-slate-50 flex items-center justify-between z-[102] relative">
          <span className="text-xs text-slate-500">
            Hotel verification status: <strong className="text-emerald-700">Contracted VIP Partner</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (window.confirm(`Are you sure you want to delete ${hotel.name}?`)) {
                  deleteHotel(hotel.id);
                  onClose();
                }
              }}
              className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-colors"
            >
              Delete Hotel
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors"
            >
              Close Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef } from 'react';
import {
  Plus,
  X,
  Calendar,
  MapPin,
  DollarSign,
  Users,
  Upload,
  Image as ImageIcon,
  Loader2,
  Sparkles,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, Itinerary, Client } from '../../types';
import { compressAndReadImageFile, TRAVEL_HERO_PRESETS } from '../../utils/imageUtils';

interface NewItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (tripId: string) => void;
}

export const NewItineraryModal: React.FC<NewItineraryModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  const { addClient, clients, hotels, addItinerary, staff } = useApp();

  const [tourName, setTourName] = useState('');
  const [title, setTitle] = useState('');
  const [destination, setDestination] = useState('');
  const [isCreatingNewClient, setIsCreatingNewClient] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientEmail, setNewClientEmail] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientCompany, setNewClientCompany] = useState('');
  const [startDate, setStartDate] = useState(
    new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0]
  );
  const [partySize, setPartySize] = useState(2);
  const [totalPrice, setTotalPrice] = useState(18500);
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [clientId, setClientId] = useState(clients[0]?.id || '');
  const [leadStaffId, setLeadStaffId] = useState(staff[0]?.id || '');
  const [daysCount, setDaysCount] = useState(5);
  const [pricingMode, setPricingMode] = useState<'package' | 'perPerson'>('package');
  const [guideName, setGuideName] = useState('Dr. Avi Ron');
  const [driverName, setDriverName] = useState('Ehud Luxury Chauffeur Fleet');
  const [overview, setOverview] = useState('');
  const [highlights, setHighlights] = useState<string[]>([]);
  const [newHighlightInput, setNewHighlightInput] = useState('');
  const [heroImage, setHeroImage] = useState(
    'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1200&auto=format&fit=crop&q=80'
  );
  const [isUploadingHeroPhoto, setIsUploadingHeroPhoto] = useState(false);
  const [heroUploadError, setHeroUploadError] = useState<string | null>(null);
  const heroFileInputRef = useRef<HTMLInputElement>(null);
  const [logoUrl, setLogoUrl] = useState('');

  const handleHeroFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingHeroPhoto(true);
    setHeroUploadError(null);
    try {
      const compressed = await compressAndReadImageFile(file, 1600, 1000, 0.85);
      setHeroImage(compressed);
    } catch (err: any) {
      setHeroUploadError(err.message || 'Failed to process photo.');
    } finally {
      setIsUploadingHeroPhoto(false);
      if (heroFileInputRef.current) heroFileInputRef.current.value = '';
    }
  };

  if (!isOpen) return null;

  const handleAddHighlight = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newHighlightInput.trim();
    if (!trimmed) return;
    if (!highlights.includes(trimmed)) {
      setHighlights([...highlights, trimmed]);
    }
    setNewHighlightInput('');
  };

  const handleRemoveHighlight = (index: number) => {
    setHighlights(highlights.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveTourName = tourName.trim() || title.trim();
    const effectiveTitle = title.trim() || effectiveTourName;
    if (!effectiveTourName || !destination) return;

    let finalClientId = clientId;
    if (isCreatingNewClient && newClientName.trim()) {
      const createdClient: Client = {
        id: `client-${Date.now()}`,
        name: newClientName.trim(),
        email: newClientEmail.trim() || 'client@example.com',
        phone: newClientPhone.trim() || '+1 555-0100',
        companyOrFamily: newClientCompany.trim() || undefined,
        nationality: 'International',
        vipTier: 'Gold VIP',
        dietaryRestrictions: [],
        preferences: [],
        emergencyContact: { name: 'Family Office', phone: '', relationship: 'Emergency' },
        notes: 'Created during itinerary design',
        createdAt: new Date().toISOString(),
      };
      await addClient(createdClient);
      finalClientId = createdClient.id;
    }

    if (!finalClientId && clients.length > 0) {
      finalClientId = clients[0].id;
    }

    // Generate initial days
    const days = [];
    const start = new Date(startDate);

    for (let i = 1; i <= daysCount; i++) {
      const curDate = new Date(start);
      curDate.setDate(curDate.getDate() + (i - 1));
      const dateStr = curDate.toISOString().split('T')[0];

      days.push({
        id: `day-${Date.now()}-${i}`,
        dayNumber: i,
        date: dateStr,
        title: `Day ${i}: Highlights & Exploration`,
        summary: 'Bespoke guided engagements and fine dining.',
        hotelId: undefined,
        hotelName: undefined,
        activities: [
          {
            id: `act-${Date.now()}-${i}-1`,
            timeSlot: '09:30 - 12:30',
            startTime: '09:30',
            endTime: '12:30',
            title: 'Curated Morning Walking & Cultural Seminar',
            description: 'Private escorted visit with priority fast-track access.',
            location: destination,
            included: true,
            costEstimate: 0,
            currency,
            category: 'Sightseeing' as const,
          },
        ],
      });
    }

    const endD = new Date(start);
    endD.setDate(endD.getDate() + (daysCount - 1));

    const newTrip: Itinerary = {
      id: `trip-${Date.now()}`,
      code: `TO-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      tourName: effectiveTourName,
      title: effectiveTitle,
      destination,
      startDate,
      endDate: endD.toISOString().split('T')[0],
      clientId: finalClientId,
      leadStaffId: leadStaffId || staff[0]?.id || '',
      partySize: Number(partySize),
      pricingMode,
      currency,
      totalClientPrice: Number(totalPrice),
      depositRequired: Math.round(Number(totalPrice) * 0.4),
      heroImage,
      logoUrl: logoUrl.trim() || undefined,
      guideName: guideName.trim() || undefined,
      driverName: driverName.trim() || undefined,
      status: 'Proposed',
      overview: overview.trim(),
      highlights: highlights,
      inclusions: [],
      exclusions: ['International business class flights', 'Discretionary gratuities'],
      days,
      lastUpdated: new Date().toISOString(),
    };

    addItinerary(newTrip);
    onCreated(newTrip.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">Design New Private Itinerary</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase flex items-center justify-between">
                <span>Tour Name *</span>
                <span className="text-[10px] text-amber-600 font-semibold lowercase">project name</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Smith Family Mediterranean Odyssey 2026"
                value={tourName}
                onChange={(e) => {
                  setTourName(e.target.value);
                  if (!title) setTitle(e.target.value);
                }}
                className="w-full mt-1 px-3 py-2 text-xs border border-amber-300 bg-amber-50/30 rounded-lg font-bold text-slate-900 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase flex items-center justify-between">
                <span>Itinerary Title / Subtitle</span>
                <span className="text-[10px] text-slate-400 lowercase">dossier label</span>
              </label>
              <input
                type="text"
                placeholder="e.g. 7-Day Swiss Alps Grand Retreat & Helitour"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Destination *</label>
              <input
                type="text"
                required
                placeholder="e.g. Jerusalem, Galilee & Tel Aviv (Israel)"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-600 uppercase">Assigned Client *</label>
                <button
                  type="button"
                  onClick={() => setIsCreatingNewClient(!isCreatingNewClient)}
                  className="text-[11px] font-bold text-amber-600 hover:text-amber-700 underline cursor-pointer"
                >
                  {isCreatingNewClient ? '← Select Existing' : '+ Quick Add Client'}
                </button>
              </div>

              {!isCreatingNewClient ? (
                <select
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white outline-none font-medium"
                >
                  {clients.length === 0 ? (
                    <option value="">-- No clients registered --</option>
                  ) : (
                    clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.companyOrFamily ? `(${c.companyOrFamily})` : ''}
                      </option>
                    ))
                  )}
                </select>
              ) : (
                <div className="mt-1 p-2.5 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                  <div className="text-[10px] font-extrabold uppercase tracking-wider text-amber-900">
                    New Client Registration
                  </div>
                  <input
                    type="text"
                    required={isCreatingNewClient}
                    placeholder="Client Full Name *"
                    value={newClientName}
                    onChange={(e) => setNewClientName(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-amber-300 rounded-lg font-bold text-slate-900 outline-none"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="email"
                      placeholder="Email address"
                      value={newClientEmail}
                      onChange={(e) => setNewClientEmail(e.target.value)}
                      className="w-full px-2 py-1 text-[11px] bg-white border border-amber-200 rounded-lg outline-none"
                    />
                    <input
                      type="text"
                      placeholder="Phone / WhatsApp"
                      value={newClientPhone}
                      onChange={(e) => setNewClientPhone(e.target.value)}
                      className="w-full px-2 py-1 text-[11px] bg-white border border-amber-200 rounded-lg outline-none"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Company or Family Office (optional)"
                    value={newClientCompany}
                    onChange={(e) => setNewClientCompany(e.target.value)}
                    className="w-full px-2 py-1 text-[11px] bg-white border border-amber-200 rounded-lg outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-600 uppercase">
              Dedicated Tour Concierge
            </label>
            <select
              value={leadStaffId}
              onChange={(e) => setLeadStaffId(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-medium"
            >
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} &bull; {s.role} ({s.department})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-600 uppercase">
                Journey Overview (Bespoke Client Narrative)
              </label>
              <span className="text-[11px] text-slate-400 font-medium">Leave blank or write custom text</span>
            </div>
            <textarea
              rows={2}
              placeholder="Write your bespoke journey overview for the client rather than pre-populating generic themes..."
              value={overview}
              onChange={(e) => setOverview(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-amber-500 outline-none"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-600 uppercase">
                Signature Highlights (Decide what if any to include)
              </label>
              <span className="text-[11px] text-slate-400 font-medium">Optional &bull; Zero themes by default</span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Type signature highlight and click Add..."
                value={newHighlightInput}
                onChange={(e) => setNewHighlightInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddHighlight();
                  }
                }}
                className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-amber-500 outline-none"
              />
              <button
                type="button"
                onClick={handleAddHighlight}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
              >
                + Add
              </button>
            </div>
            {highlights.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {highlights.map((h, i) => (
                  <span
                    key={i}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 border border-amber-200 text-amber-950 text-xs rounded-lg"
                  >
                    <span>{h}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveHighlight(i)}
                      className="text-amber-700 hover:text-red-600 font-bold ml-1 cursor-pointer"
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-slate-400 italic mt-1">
                No signature highlights added. The client view will show a clean layout without forced themes.
              </p>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Days Duration</label>
              <input
                type="number"
                min={1}
                max={30}
                value={daysCount}
                onChange={(e) => setDaysCount(Number(e.target.value))}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Party Size</label>
              <input
                type="number"
                min={1}
                value={partySize}
                onChange={(e) => setPartySize(Number(e.target.value))}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Guide & Driver Assignment Section */}
          <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-2.5">
            <div className="flex items-center space-x-1.5 text-xs font-extrabold text-amber-950 uppercase tracking-wider">
              <span>Tour Operations Crew: Guide &amp; Chauffeur</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 uppercase">Dedicated Tour Guide</label>
                <input
                  type="text"
                  placeholder="e.g. Dr. Avi Ron"
                  value={guideName}
                  onChange={(e) => setGuideName(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs bg-white border border-amber-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-amber-500/20 outline-none"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 uppercase">Dedicated Chauffeur / Driver</label>
                <input
                  type="text"
                  placeholder="e.g. Ehud Luxury Fleet"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs bg-white border border-amber-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-amber-500/20 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Pricing Mode</label>
              <select
                value={pricingMode}
                onChange={(e) => setPricingMode(e.target.value as 'package' | 'perPerson')}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900"
              >
                <option value="package">One cost for all participants</option>
                <option value="perPerson">Per person cost</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">
                {pricingMode === 'package' ? 'Total Package Price' : 'Per Person Price'}
              </label>
              <input
                type="number"
                value={totalPrice}
                onChange={(e) => setTotalPrice(Number(e.target.value))}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 uppercase">Billing Currency</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-lg"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="ILS">ILS (₪)</option>
                <option value="CHF">CHF (Fr)</option>
              </select>
            </div>
          </div>

          {/* Hero Photo Section with Device Upload Button */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-amber-500" />
                <span>Hero Photo (Tour Cover Banner)</span>
              </label>
              <span className="text-[10px] text-slate-400 font-medium">
                Displayed on itinerary cover &amp; live client portal
              </span>
            </div>

            {/* Live Preview & Upload Control */}
            <div className="relative h-28 sm:h-36 w-full rounded-xl overflow-hidden border border-slate-200 shadow-inner bg-slate-900 group">
              <img
                src={heroImage}
                alt="Hero Preview"
                className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1200&auto=format&fit=crop&q=80';
                }}
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors flex items-center justify-center p-3">
                <input
                  ref={heroFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleHeroFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => heroFileInputRef.current?.click()}
                  disabled={isUploadingHeroPhoto}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-transform hover:scale-105 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isUploadingHeroPhoto ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Optimizing Photo...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                      <span>Upload Photo from Device</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {heroUploadError && (
              <p className="text-xs text-rose-600 font-semibold">{heroUploadError}</p>
            )}

            {/* Quick Travel Photography Presets */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Or Pick Destination Photo Preset:</span>
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {TRAVEL_HERO_PRESETS.slice(0, 5).map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setHeroImage(preset.url)}
                    className={`px-2.5 py-1 text-[11px] rounded-lg font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                      heroImage === preset.url
                        ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-2xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>{preset.title.split(' ')[0]}</span>
                    {heroImage === preset.url && <Check className="w-3 h-3 stroke-[3]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Fallback Direct URL */}
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">
                Custom Image Web URL
              </label>
              <input
                type="url"
                value={heroImage}
                onChange={(e) => setHeroImage(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full mt-0.5 px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-600 uppercase">
              Particular Itinerary Logo URL (Optional)
            </label>
            <input
              type="url"
              placeholder="https://example.com/client-or-partner-logo.png (leave blank if none)"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              className="w-full mt-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 text-white font-bold text-xs rounded-lg shadow-xs"
            >
              Create &amp; Open Designer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

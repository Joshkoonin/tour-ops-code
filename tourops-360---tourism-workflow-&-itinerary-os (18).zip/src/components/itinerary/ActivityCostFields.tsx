import React from 'react';
import { DollarSign, Check, Users, Globe } from 'lucide-react';
import { CurrencyCode } from '../../types';

export type ActivityCostBasis = 'global' | 'perPerson' | 'noCost';

interface ActivityCostFieldsProps {
  costBasis: ActivityCostBasis;
  amount: number | string; // preserve entered string/number, allowing decimals and zero
  currency: CurrencyCode;
  onBasisChange: (basis: ActivityCostBasis) => void;
  onAmountChange: (value: number | string) => void;
  errorMessage?: string | null;
  compact?: boolean;
}

export const ActivityCostFields: React.FC<ActivityCostFieldsProps> = ({
  costBasis,
  amount,
  currency,
  onBasisChange,
  onAmountChange,
  errorMessage,
  compact = false,
}) => {
  return (
    <div className={`space-y-2 ${compact ? 'p-2.5' : 'p-3.5'} bg-slate-50/80 rounded-2xl border border-slate-200`}>
      <div className="flex items-center justify-between">
        <label className="text-[10px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
          <DollarSign className="w-3.5 h-3.5 text-amber-600" />
          <span>Activity Cost to Agency (Our Cost) &amp; Basis</span>
        </label>
        <span className="text-[10px] font-mono font-bold text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded">
          Currency: {currency}
        </span>
      </div>

      {/* 3 Mutually Exclusive Toggle Choices */}
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <button
          type="button"
          onClick={() => {
            onBasisChange('global');
            if (amount === '' || amount === undefined || Number(amount) === 0) {
              onAmountChange(amount === '' ? '' : Number(amount));
            }
          }}
          className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
            costBasis === 'global'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
          title="Fixed total cost for the whole group, independent of participant count"
        >
          <Globe className="w-3 h-3 text-amber-400 shrink-0" />
          <span className="truncate">Our cost global</span>
        </button>

        <button
          type="button"
          onClick={() => {
            onBasisChange('perPerson');
            if (amount === '' || amount === undefined || Number(amount) === 0) {
              onAmountChange(amount === '' ? '' : Number(amount));
            }
          }}
          className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
            costBasis === 'perPerson'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
          title="Unit cost multiplied by participant count"
        >
          <Users className="w-3 h-3 text-emerald-400 shrink-0" />
          <span className="truncate">Our cost per person</span>
        </button>

        <button
          type="button"
          onClick={() => {
            onBasisChange('noCost');
            onAmountChange(0);
          }}
          className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
            costBasis === 'noCost'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
          title="Explicitly zero cost to company ($0)"
        >
          <Check className="w-3 h-3 shrink-0" />
          <span className="truncate">No cost</span>
        </button>
      </div>

      {/* Amount Input (Hidden when No Cost is selected) */}
      {costBasis !== 'noCost' ? (
        <div className="space-y-1 pt-1">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 font-mono">
                {currency}
              </span>
              <input
                type="number"
                min="0"
                step="any"
                placeholder={costBasis === 'global' ? '0.00 (Total fixed group cost)' : '0.00 (Unit cost per person)'}
                value={amount === 0 ? '0' : (amount ?? '')}
                onChange={(e) => {
                  const val = e.target.value;
                  onAmountChange(val === '' ? '' : val);
                }}
                className={`w-full pl-12 pr-3 py-1.5 text-xs font-mono font-bold bg-white border rounded-xl outline-none focus:ring-2 focus:ring-amber-400 ${
                  errorMessage ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                }`}
              />
            </div>
            <span className="text-[11px] font-semibold text-slate-500 shrink-0">
              {costBasis === 'global' ? 'for whole group' : 'per guest'}
            </span>
          </div>

          <p className="text-[10px] text-slate-500 leading-tight">
            {costBasis === 'global' ? (
              <span><strong>Global fixed cost:</strong> Applies once to the entire tour regardless of participant count (e.g. guide fee, vessel charter).</span>
            ) : (
              <span><strong>Per-person unit cost:</strong> Multiplied by participant count in tour cost simulations (e.g. entry ticket, tasting menu).</span>
            )}
          </p>

          {errorMessage && (
            <p className="text-[11px] font-bold text-rose-600 animate-fade-in flex items-center gap-1">
              <span>⚠</span> {errorMessage}
            </p>
          )}
        </div>
      ) : (
        <div className="p-2.5 bg-emerald-50/80 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-900 text-xs font-bold">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Explicitly saved as No Cost ($0.00 {currency}). Amount input hidden.</span>
        </div>
      )}
    </div>
  );
};

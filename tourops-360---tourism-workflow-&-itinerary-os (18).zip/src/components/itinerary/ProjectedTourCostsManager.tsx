import React, { useState, useMemo } from 'react';
import {
  DollarSign,
  TrendingUp,
  Plus,
  Trash2,
  Edit2,
  Bus,
  Compass,
  Car,
  Plane,
  Ticket,
  ShieldCheck,
  Building,
  Info,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Tag,
  AlertCircle,
  Briefcase,
  Utensils,
  Layers,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  Itinerary,
  GeneralProjectedCostItem,
  ProjectedCostCategory,
  CurrencyCode,
} from '../../types';
import { getTourContractRevenue } from '../../utils/financialCalculations';

interface ProjectedTourCostsManagerProps {
  trip: Itinerary;
  isOpenDefault?: boolean;
  onClose?: () => void;
}

export const ProjectedTourCostsManager: React.FC<ProjectedTourCostsManagerProps> = ({
  trip,
  isOpenDefault = false,
  onClose,
}) => {
  const { suppliers, convertCurrency, formatMoney, updateItinerary, hasFullFinancialView } =
    useApp();

  const [isExpanded, setIsExpanded] = useState(isOpenDefault);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ProjectedCostCategory>('Transport & Fleet');
  const [costEstimate, setCostEstimate] = useState<number | ''>(2500);
  const [currency, setCurrency] = useState<CurrencyCode>(trip.currency || 'USD');
  const [supplierId, setSupplierId] = useState('');
  const [notes, setNotes] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // If user does not have full financial view, render nothing (Strict governance)
  if (!hasFullFinancialView) {
    return null;
  }

  const generalCosts = trip.generalProjectedCosts || [];

  // Calculate Specific Activities Projected Costs (Sum of all day.activities.costEstimate)
  const activitiesWithCost = useMemo(() => {
    const list: { dayNum: number; dayTitle: string; actTitle: string; cost: number; currency: CurrencyCode; costUSD: number }[] = [];
    trip.days.forEach((day) => {
      day.activities.forEach((act) => {
        if (act.costEstimate && act.costEstimate > 0) {
          const actCurr = act.currency || trip.currency || 'USD';
          const costUSD = convertCurrency(act.costEstimate, actCurr, 'USD');
          list.push({
            dayNum: day.dayNumber,
            dayTitle: day.title,
            actTitle: act.title,
            cost: act.costEstimate,
            currency: actCurr,
            costUSD,
          });
        }
      });
    });
    return list;
  }, [trip.days, trip.currency, convertCurrency]);

  const totalSpecificCostsUSD = useMemo(() => {
    return activitiesWithCost.reduce((sum, item) => sum + item.costUSD, 0);
  }, [activitiesWithCost]);

  // Calculate General Projected Costs (Bus, Guide, etc.)
  const totalGeneralCostsUSD = useMemo(() => {
    return generalCosts.reduce((sum, item) => {
      const usd = convertCurrency(item.costEstimate || 0, item.currency || trip.currency || 'USD', 'USD');
      return sum + usd;
    }, 0);
  }, [generalCosts, trip.currency, convertCurrency]);

  // Total Projected Tour Costs
  const totalProjectedCostsUSD = totalSpecificCostsUSD + totalGeneralCostsUSD;

  // Tour Revenue (Selling Price)
  const revenueUSD = convertCurrency(getTourContractRevenue(trip), trip.currency || 'USD', 'USD');

  // Projected Tour Profit
  const projectedProfitUSD = revenueUSD - totalProjectedCostsUSD;
  const projectedMarginPercent = revenueUSD > 0 ? (projectedProfitUSD / revenueUSD) * 100 : 0;

  // Presets helper
  const handleApplyPreset = (
    presetTitle: string,
    presetCategory: ProjectedCostCategory,
    defaultAmount: number
  ) => {
    setTitle(presetTitle);
    setCategory(presetCategory);
    setCostEstimate(defaultAmount);
    setIsAddingNew(true);
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Transport & Fleet');
    setCostEstimate(2500);
    setCurrency(trip.currency || 'USD');
    setSupplierId('');
    setNotes('');
    setEditingItemId(null);
    setIsAddingNew(false);
  };

  const handleStartEdit = (item: GeneralProjectedCostItem) => {
    setEditingItemId(item.id);
    setTitle(item.title);
    setCategory(item.category);
    setCostEstimate(item.costEstimate);
    setCurrency(item.currency);
    setSupplierId(item.supplierId || '');
    setNotes(item.notes || '');
    setIsAddingNew(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || costEstimate === '' || costEstimate < 0) return;

    let updatedList: GeneralProjectedCostItem[];

    if (editingItemId) {
      updatedList = generalCosts.map((item) =>
        item.id === editingItemId
          ? {
              ...item,
              title: title.trim(),
              category,
              costEstimate: Number(costEstimate),
              currency,
              supplierId: supplierId || undefined,
              notes: notes.trim() || undefined,
            }
          : item
      );
    } else {
      const newItem: GeneralProjectedCostItem = {
        id: `cost-${Date.now()}`,
        title: title.trim(),
        category,
        costEstimate: Number(costEstimate),
        currency,
        supplierId: supplierId || undefined,
        notes: notes.trim() || undefined,
        createdAt: new Date().toISOString(),
      };
      updatedList = [...generalCosts, newItem];
    }

    updateItinerary({
      ...trip,
      generalProjectedCosts: updatedList,
      lastUpdated: new Date().toISOString(),
    });

    setToastMsg(
      editingItemId
        ? `Updated general cost item: "${title.trim()}"`
        : `Added general cost item: "${title.trim()}"`
    );
    setTimeout(() => setToastMsg(null), 3500);
    resetForm();
  };

  const handleDeleteItem = (itemId: string, itemTitle: string) => {
    const updatedList = generalCosts.filter((item) => item.id !== itemId);
    updateItinerary({
      ...trip,
      generalProjectedCosts: updatedList,
      lastUpdated: new Date().toISOString(),
    });
    setToastMsg(`Removed cost item: "${itemTitle}"`);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const getCategoryIcon = (cat: ProjectedCostCategory) => {
    switch (cat) {
      case 'Transport & Fleet':
        return <Bus className="w-4 h-4 text-blue-600" />;
      case 'Guide / Tour Director':
        return <Compass className="w-4 h-4 text-emerald-600" />;
      case 'Accommodations':
        return <Building className="w-4 h-4 text-sky-600" />;
      case 'Security & VIP Handling':
        return <ShieldCheck className="w-4 h-4 text-rose-600" />;
      case 'Catering & Dining':
        return <Utensils className="w-4 h-4 text-orange-600" />;
      case 'Attractions & Permits':
        return <Ticket className="w-4 h-4 text-amber-600" />;
      case 'General Logistics':
        return <Layers className="w-4 h-4 text-slate-600" />;
      default:
        return <DollarSign className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Banner / Card Header */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950">
                Full Financial View
              </span>
              <span className="text-xs text-slate-300 font-medium">
                {trip.status === 'Proposed' ? 'Proposal Financials & Projected Margin' : 'Tour Projected Budget'}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <DollarSign className="w-6 h-6 text-amber-400" />
              <span>Projected Tour Profit &amp; Budget Planner</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Calculate projected profits by itemizing specific activity expenses and whole-tour general costs (such as bus hire or tour guide honorarium).
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 backdrop-blur-xs cursor-pointer"
            >
              <span>{isExpanded ? 'Hide Details' : 'Manage Projected Costs'}</span>
              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-white rounded-xl transition-colors"
              >
                &times;
              </button>
            )}
          </div>
        </div>

        {/* Financial KPI Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mt-5 pt-5 border-t border-slate-700/60">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              Client Selling Price
            </div>
            <div className="text-base sm:text-lg font-black text-white mt-1">
              ${formatMoney(revenueUSD, 'USD')}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {trip.totalClientPrice.toLocaleString()} {trip.currency}
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              Specific Item Costs
            </div>
            <div className="text-base sm:text-lg font-black text-amber-400 mt-1">
              ${formatMoney(totalSpecificCostsUSD, 'USD')}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {activitiesWithCost.length} {activitiesWithCost.length === 1 ? 'activity' : 'activities'}
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              General Tour Costs
            </div>
            <div className="text-base sm:text-lg font-black text-amber-400 mt-1">
              ${formatMoney(totalGeneralCostsUSD, 'USD')}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {generalCosts.length} whole-tour {generalCosts.length === 1 ? 'item' : 'items'}
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
              Total Projected Cost
            </div>
            <div className="text-base sm:text-lg font-black text-rose-300 mt-1">
              ${formatMoney(totalProjectedCostsUSD, 'USD')}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Items + Bus + Guide
            </div>
          </div>

          <div
            className={`p-3 rounded-2xl border col-span-2 lg:col-span-1 ${
              projectedProfitUSD >= 0
                ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                : 'bg-rose-500/20 border-rose-400/40 text-rose-300'
            }`}
          >
            <div className="text-[10px] font-bold uppercase tracking-wider opacity-80">
              Projected Tour Profit
            </div>
            <div className="text-lg sm:text-xl font-black mt-1">
              {projectedProfitUSD >= 0 ? '+' : '-'}${formatMoney(Math.abs(projectedProfitUSD), 'USD')}
            </div>
            <div className="text-[10px] font-extrabold mt-0.5">
              {projectedMarginPercent.toFixed(1)}% Projected Margin
            </div>
          </div>
        </div>

        {/* Accounting Separation Assurance Notice */}
        <div className="mt-4 p-2.5 bg-slate-950/40 border border-slate-700/60 rounded-xl text-[11px] text-slate-300 flex items-start gap-2">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <span>
            <strong>Isolated Proposal Ledger:</strong> These projected costs are used strictly to analyze tour profit for this quote. They do <strong>not</strong> impact overall business financial costs, accounts payable, or company P&amp;L until this tour is confirmed and vendor invoices are officially registered.
          </span>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{toastMsg}</span>
          </div>
          <button onClick={() => setToastMsg(null)} className="text-emerald-700 font-bold">
            &times;
          </button>
        </div>
      )}

      {/* Expandable Management Area */}
      {isExpanded && (
        <div className="p-5 sm:p-6 space-y-6">
          {/* Quick Presets Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-amber-600" />
                <span>Quick Add Whole-Tour Cost Presets</span>
              </span>
              <span className="text-[11px] text-slate-400">1-click populated fields</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset('Dedicated Tour Bus / Luxury Coach Hire', 'Transport & Fleet', 3200)
                }
                className="px-3 py-1.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-950 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-slate-200"
              >
                <Bus className="w-3.5 h-3.5 text-blue-600" />
                <span>+ Bus / Coach Hire</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset('Lead Licensed Tour Guide Honorarium', 'Guide / Tour Director', 2100)
                }
                className="px-3 py-1.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-950 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-slate-200"
              >
                <Compass className="w-3.5 h-3.5 text-emerald-600" />
                <span>+ Tour Guide Hire</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset('Dedicated Chauffeur & Vehicle', 'Transport & Fleet', 1800)
                }
                className="px-3 py-1.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-950 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-slate-200"
              >
                <Car className="w-3.5 h-3.5 text-amber-600" />
                <span>+ Dedicated Driver</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset('Airport VIP Host & Luggage Transfers', 'Transport & Fleet', 650)
                }
                className="px-3 py-1.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-950 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-slate-200"
              >
                <Plane className="w-3.5 h-3.5 text-purple-600" />
                <span>+ Airport VIP Transfer</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Tour Operations Contingency Reserve (5%)',
                    'General Logistics',
                    Math.round(revenueUSD * 0.05)
                  )
                }
                className="px-3 py-1.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-950 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-slate-200"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span>+ 5% Contingency (${Math.round(revenueUSD * 0.05)})</span>
              </button>
            </div>
          </div>

          {/* Form to Add / Edit General Cost Item */}
          {isAddingNew && (
            <form
              onSubmit={handleSaveItem}
              className="p-4 sm:p-5 bg-amber-50/50 rounded-2xl border-2 border-amber-300 space-y-4 animate-scale-in"
            >
              <div className="flex items-center justify-between pb-2 border-b border-amber-200">
                <h3 className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-amber-700" />
                  <span>{editingItemId ? 'Edit General Projected Cost' : 'Add General Projected Cost Item'}</span>
                </h3>
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-xs font-bold text-slate-500 hover:text-slate-800"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="lg:col-span-2">
                  <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                    Cost Item Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dedicated 50-Seat Luxury Bus for entire tour"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold bg-white border border-amber-300 rounded-xl outline-none focus:ring-2 focus:ring-amber-400"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                    Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ProjectedCostCategory)}
                    className="w-full px-3 py-2 text-xs font-bold bg-white border border-amber-300 rounded-xl outline-none"
                  >
                    <option value="Transport & Fleet">🚌 Transport &amp; Fleet</option>
                    <option value="Guide / Tour Director">👤 Guide / Tour Director</option>
                    <option value="Accommodations">🏨 Accommodations</option>
                    <option value="Security & VIP Handling">🛡️ Security &amp; VIP Handling</option>
                    <option value="Catering & Dining">🍽️ Catering &amp; Dining</option>
                    <option value="Attractions & Permits">🎟️ Attractions &amp; Permits</option>
                    <option value="General Logistics">📦 General Logistics</option>
                    <option value="Other">💼 Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                    Projected Amount &amp; Currency *
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="number"
                      required
                      min="0"
                      step="any"
                      placeholder="0.00"
                      value={costEstimate}
                      onChange={(e) => setCostEstimate(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs font-bold bg-white border border-amber-300 rounded-xl outline-none"
                    />
                    <select
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                      className="px-2 py-2 text-xs font-bold bg-white border border-amber-300 rounded-xl outline-none"
                    >
                      <option value="USD">USD</option>
                      <option value="ILS">ILS</option>
                      <option value="EUR">EUR</option>
                      <option value="GBP">GBP</option>
                    </select>
                  </div>
                </div>

                <div className="lg:col-span-2">
                  <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                    Assign Supplier (Optional)
                  </label>
                  <select
                    value={supplierId}
                    onChange={(e) => setSupplierId(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold bg-white border border-slate-300 rounded-xl outline-none"
                  >
                    <option value="">-- No Direct Supplier Linked --</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.category})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="lg:col-span-2">
                  <label className="text-[10px] font-bold text-slate-700 uppercase block mb-1">
                    Internal Notes / Quotation Details
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Quoted by fleet dispatch; includes driver overnight & tolls"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingItemId ? 'Save Changes' : 'Add Cost to Proposal'}</span>
                </button>
              </div>
            </form>
          )}

          {/* General Projected Costs Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <span>Whole-Tour General Projected Costs ({generalCosts.length})</span>
                <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                  Total: ${formatMoney(totalGeneralCostsUSD, 'USD')}
                </span>
              </h3>
              {!isAddingNew && (
                <button
                  type="button"
                  onClick={() => setIsAddingNew(true)}
                  className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-400" />
                  <span>+ Add General Cost</span>
                </button>
              )}
            </div>

            {generalCosts.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 border border-dashed border-slate-300 rounded-2xl space-y-2">
                <p className="text-xs text-slate-500">
                  No general whole-tour costs added yet. Add items such as dedicated bus charter, tour guide fees, or vehicle transfers.
                </p>
                <button
                  type="button"
                  onClick={() => setIsAddingNew(true)}
                  className="px-4 py-1.5 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-xs hover:bg-amber-400"
                >
                  + Add First General Cost Item
                </button>
              </div>
            ) : (
              <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100">
                {generalCosts.map((item) => {
                  const supplier = suppliers.find((s) => s.id === item.supplierId);
                  const itemUSD = convertCurrency(item.costEstimate, item.currency, 'USD');

                  return (
                    <div
                      key={item.id}
                      className="p-3.5 sm:p-4 bg-white hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-xl bg-slate-100 shrink-0 mt-0.5">
                          {getCategoryIcon(item.category)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-slate-900 text-sm">{item.title}</span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                              {item.category}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 mt-1">
                            {supplier && (
                              <span className="flex items-center gap-1 text-slate-700 font-semibold">
                                <Building className="w-3 h-3 text-slate-400" />
                                <span>{supplier.name}</span>
                              </span>
                            )}
                            {item.notes && <span className="italic">{item.notes}</span>}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                        <div className="text-right">
                          <div className="font-black text-slate-900 text-sm">
                            ${formatMoney(itemUSD, 'USD')}
                          </div>
                          {item.currency !== 'USD' && (
                            <div className="text-[10px] text-slate-400">
                              {item.costEstimate.toLocaleString()} {item.currency}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleStartEdit(item)}
                            className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg transition-colors"
                            title="Edit cost item"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteItem(item.id, item.title)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete cost item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Specific Daily Activities Projected Costs Breakdown */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <span>Specific Daily Activity Costs ({activitiesWithCost.length})</span>
                <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                  Total: ${formatMoney(totalSpecificCostsUSD, 'USD')}
                </span>
              </h3>
              <span className="text-[11px] text-slate-400">Set per activity in days</span>
            </div>

            {activitiesWithCost.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                No specific activity costs set yet. Edit any activity in the itinerary days to add item projected costs.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {activitiesWithCost.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-center justify-between text-xs"
                  >
                    <div className="truncate mr-2">
                      <div className="text-[10px] font-bold text-amber-800">Day {item.dayNum}</div>
                      <div className="font-extrabold text-slate-900 truncate">{item.actTitle}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-black text-slate-900">${formatMoney(item.costUSD, 'USD')}</div>
                      {item.currency !== 'USD' && (
                        <div className="text-[9px] text-slate-400">
                          {item.cost.toLocaleString()} {item.currency}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

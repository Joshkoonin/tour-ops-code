import React, { useState } from 'react';
import { X, Check } from 'lucide-react';

interface FieldEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  field: string;
  value: string | number;
  type: 'text' | 'number' | 'date';
  onSave: (value: string | number) => void;
}

export const FieldEditorModal: React.FC<FieldEditorModalProps> = ({
  isOpen,
  onClose,
  title,
  field,
  value,
  type,
  onSave,
}) => {
  const [tempValue, setTempValue] = useState(value);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6">
          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">{field}</label>
          <input
            type={type}
            value={tempValue}
            onChange={(e) => setTempValue(type === 'number' ? Number(e.target.value) : e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
          />
        </div>
        <div className="px-6 py-4 bg-slate-50 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onSave(tempValue);
              onClose();
            }}
            className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-lg flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            Confirm Change
          </button>
        </div>
      </div>
    </div>
  );
};

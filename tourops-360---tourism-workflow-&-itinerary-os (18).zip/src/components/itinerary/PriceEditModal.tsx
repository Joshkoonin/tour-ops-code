import React, { useState } from 'react';
import { Save } from 'lucide-react';

interface PriceEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPrice: number;
  currency: string;
  pricingMode: 'package' | 'perPerson';
  partySize: number;
  onSave: (newPrice: number, pricingMode: 'package' | 'perPerson', partySize: number) => void;
}

export const PriceEditModal: React.FC<PriceEditModalProps> = ({
  isOpen,
  onClose,
  currentPrice,
  currency,
  pricingMode,
  partySize,
  onSave,
}) => {
  const [price, setPrice] = useState(currentPrice);
  const [mode, setMode] = useState<'package' | 'perPerson'>(pricingMode);
  const [size, setSize] = useState(partySize);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl space-y-4">
        <h2 className="text-lg font-black text-slate-900">Update Trip Details</h2>
        <div>
          <label className="text-xs font-bold text-slate-600 uppercase">Pricing Mode</label>
          <select value={mode} onChange={(e) => setMode(e.target.value as 'package' | 'perPerson')} className="w-full mt-1 px-3 py-2 text-sm border border-slate-300 rounded-lg">
            <option value="package">One cost for all participants</option>
            <option value="perPerson">Per person cost</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-bold text-slate-600 uppercase">Party Size</label>
          <input type="number" min="1" value={size} onChange={(e) => setSize(Number(e.target.value))} className="w-full mt-1 px-3 py-2 text-sm border border-slate-300 rounded-lg" />
        </div>
        <div>
          <label className="text-xs font-bold text-slate-600 uppercase">
            {mode === 'package' ? `Total Package Price (${currency})` : `Price Per Person (${currency})`}
          </label>
          <input
            type="number"
            step="any"
            min="0"
            value={price}
            onChange={(e) => setPrice(e.target.value === '' ? 0 : Number(e.target.value))}
            className="w-full mt-1 px-3 py-2 text-sm border border-slate-300 rounded-lg"
          />
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
          <button
            onClick={() => {
              onSave(price, mode, size);
              onClose();
            }}
            className="px-4 py-1.5 bg-slate-900 text-white font-bold text-xs rounded-lg flex items-center gap-1"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save</span>
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Receipt,
  Plus,
  DollarSign,
  TrendingUp,
  Building,
  PieChart,
  Filter,
  CheckCircle2,
  Trash2,
  Tag,
  Calendar,
  Download,
  Coins,
  Edit2,
  X,
  Lock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CurrencyCode, Expense, ExpenseCategory } from '../../types';

const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Hotel / Lodging',
  'Private Guide & Expert',
  'Vehicle & Chauffeur',
  'Attractions & Permits',
  'Meals & Wine',
  'Flights / Trains',
  'Office & Admin',
  'Software & Marketing',
  'Insurance & Legal',
  'Other',
];

export const GeneralExpensesHub: React.FC = () => {
  const {
    expenses,
    addExpense,
    updateExpense,
    deleteExpense,
    supplierInvoices,
    convertCurrency,
    formatMoney,
    hasFullFinancialView,
  } = useApp();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Office & Admin');
  const [amount, setAmount] = useState<number>(1500);
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Pending' | 'Reimbursed'>('Paid');
  const [paymentMethod, setPaymentMethod] = useState<'Company Card' | 'Wire Transfer' | 'Petty Cash' | 'Direct Debit'>('Wire Transfer');
  const [receiptRef, setReceiptRef] = useState<string>(`GEN-${Date.now().toString().slice(-4)}`);
  const [notes, setNotes] = useState<string>('');

  // General Overhead Expenses (either marked isGeneralOverhead or no tripId)
  const generalExpenses = expenses.filter((e) => e.isGeneralOverhead || !e.tripId);

  const filteredExpenses = generalExpenses.filter((e) => {
    if (categoryFilter !== 'ALL' && e.category !== categoryFilter) return false;
    if (searchTerm.trim() && !e.title.toLowerCase().includes(searchTerm.toLowerCase()) && !e.receiptRef?.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    return true;
  });

  const totalGeneralExpensesUSD = generalExpenses.reduce((sum, e) => {
    return sum + convertCurrency(e.amount, e.currency, 'USD');
  }, 0);

  const overheadSupplierInvoicesUSD = supplierInvoices
    .filter((inv) => inv.isGeneralOverhead || !inv.tripId || inv.tripId === 'general-overhead')
    .reduce((sum, inv) => {
      const usd = convertCurrency(inv.amount, inv.currency, 'USD');
      return inv.isCredit ? sum - usd : sum + usd;
    }, 0);

  const totalCorporateOverheadsUSD = totalGeneralExpensesUSD + overheadSupplierInvoicesUSD;

  const handleOpenAddModal = (expToEdit?: Expense) => {
    if (expToEdit) {
      setEditingExpense(expToEdit);
      setTitle(expToEdit.title);
      setCategory(expToEdit.category);
      setAmount(expToEdit.amount);
      setCurrency(expToEdit.currency);
      setDate(expToEdit.date);
      setPaymentStatus(expToEdit.paymentStatus);
      setPaymentMethod(expToEdit.paymentMethod);
      setReceiptRef(expToEdit.receiptRef || `GEN-${Date.now().toString().slice(-4)}`);
      setNotes(expToEdit.notes || '');
    } else {
      setEditingExpense(null);
      setTitle('');
      setCategory('Office & Admin');
      setAmount(1500);
      setCurrency('USD');
      setDate(new Date().toISOString().split('T')[0]);
      setPaymentStatus('Paid');
      setPaymentMethod('Wire Transfer');
      setReceiptRef(`GEN-${Date.now().toString().slice(-4)}`);
      setNotes('');
    }
    setIsAddModalOpen(true);
  };

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) return;

    if (editingExpense) {
      const updated: Expense = {
        ...editingExpense,
        title: title.trim(),
        category,
        amount: Number(amount),
        currency,
        convertedAmountUSD: convertCurrency(Number(amount), currency, 'USD'),
        date,
        paymentStatus,
        paymentMethod,
        receiptRef,
        isGeneralOverhead: true,
        notes: notes.trim() || undefined,
      };
      updateExpense(updated);
    } else {
      const newExp: Expense = {
        id: `exp-${Date.now()}`,
        title: title.trim(),
        category,
        amount: Number(amount),
        currency,
        convertedAmountUSD: convertCurrency(Number(amount), currency, 'USD'),
        date,
        paymentStatus,
        paymentMethod,
        receiptRef,
        isGeneralOverhead: true,
        tripId: undefined,
        notes: notes.trim() || undefined,
      };
      addExpense(newExp);
    }

    setIsAddModalOpen(false);
    setEditingExpense(null);
  };

  if (!hasFullFinancialView) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-sm text-slate-600 flex items-center gap-3 shadow-xs">
          <Lock className="w-5 h-5 text-amber-600 shrink-0" />
          <span>General Corporate Expenses and P&amp;L Overheads are restricted to <strong>Full Financial View</strong> staff members.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-100 text-indigo-900">
              Corporate P&amp;L Module
            </span>
            <span className="text-xs text-slate-500 font-medium">Automatic Period &amp; Overall Impact</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
            General Expenses &amp; Corporate Overheads
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Log, modify, or remove general corporate overheads. All expenses listed here automatically count toward company profit and loss across any relevant period and overall.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={() => handleOpenAddModal()}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Record General Expense</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Total General Expenses Recorded
          </span>
          <div className="text-2xl font-black text-slate-900 mt-1">
            {generalExpenses.length} items
          </div>
          <span className="text-xs text-slate-500 mt-0.5 block">Active corporate overhead entries</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            General Expenses (USD Equivalent)
          </span>
          <div className="text-2xl font-black text-rose-700 mt-1">
            {formatMoney(totalGeneralExpensesUSD, 'USD')}
          </div>
          <span className="text-xs text-slate-500 mt-0.5 block">Deducted from company net profit</span>
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-3xl shadow-md border border-slate-800">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
            Total Corporate Overheads (Inc. Invoices)
          </span>
          <div className="text-2xl font-black text-amber-400 mt-1">
            {formatMoney(totalCorporateOverheadsUSD, 'USD')}
          </div>
          <span className="text-xs text-slate-300 mt-0.5 block">Applied to overall P&amp;L statement</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 outline-none"
          >
            <option value="ALL">All Categories ({generalExpenses.length})</option>
            {EXPENSE_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <input
            type="text"
            placeholder="Search by title or receipt ref..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800 outline-none w-full sm:w-64"
          />
        </div>

        <div className="text-xs text-slate-500 font-semibold">
          Showing {filteredExpenses.length} of {generalExpenses.length} general expenses
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        {filteredExpenses.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Receipt className="w-10 h-10 mx-auto text-slate-300" />
            <div className="text-sm font-bold text-slate-700">No general expenses recorded yet</div>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Click &quot;Record General Expense&quot; above to add company overheads such as rent, subscriptions, or utilities that automatically factor into P&amp;L.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-extrabold uppercase tracking-wider">
                <tr>
                  <th className="px-5 py-3.5">Expense Title &amp; Ref</th>
                  <th className="px-5 py-3.5">Category</th>
                  <th className="px-5 py-3.5">Date</th>
                  <th className="px-5 py-3.5">Payment Method</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5 text-right">Amount</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredExpenses.map((exp) => {
                  const usd = convertCurrency(exp.amount, exp.currency, 'USD');

                  return (
                    <tr key={exp.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-extrabold text-slate-900">{exp.title}</div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono font-bold text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                            {exp.receiptRef || 'NO-REF'}
                          </span>
                          {exp.notes && (
                            <span className="text-slate-500 text-[11px] truncate max-w-xs" title={exp.notes}>
                              {exp.notes}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                          {exp.category}
                        </span>
                      </td>

                      <td className="px-5 py-4 font-mono text-slate-600">
                        {exp.date}
                      </td>

                      <td className="px-5 py-4 font-medium text-slate-700">
                        {exp.paymentMethod}
                      </td>

                      <td className="px-5 py-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                          exp.paymentStatus === 'Paid'
                            ? 'bg-emerald-100 text-emerald-900'
                            : exp.paymentStatus === 'Reimbursed'
                            ? 'bg-blue-100 text-blue-900'
                            : 'bg-yellow-100 text-yellow-900'
                        }`}>
                          {exp.paymentStatus}
                        </span>
                      </td>

                      <td className="px-5 py-4 text-right">
                        <div className="font-mono font-black text-slate-900 text-sm">
                          {exp.amount.toLocaleString()} {exp.currency}
                        </div>
                        {exp.currency !== 'USD' && (
                          <div className="text-[10px] text-slate-400 font-mono">
                            ~{formatMoney(usd, 'USD')}
                          </div>
                        )}
                      </td>

                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleOpenAddModal(exp)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Edit General Expense"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteExpense(exp.id)}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete General Expense"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">
                {editingExpense ? 'Edit General Corporate Expense' : 'Record General Corporate Expense'}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg text-lg leading-none cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 uppercase block mb-1">Expense Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Headquarters Monthly Office Rent, AWS Cloud Hosting..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Category *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    {EXPENSE_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Receipt / Ref #</label>
                  <input
                    type="text"
                    value={receiptRef}
                    onChange={(e) => setReceiptRef(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Amount *</label>
                  <input
                    type="number"
                    required
                    step="any"
                    min="0"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Currency *</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="ILS">ILS (₪)</option>
                    <option value="CHF">CHF (Fr)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Status</label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                    <option value="Reimbursed">Reimbursed</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 uppercase block mb-1">Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Wire Transfer">Wire Transfer</option>
                    <option value="Company Card">Company Card</option>
                    <option value="Petty Cash">Petty Cash</option>
                    <option value="Direct Debit">Direct Debit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 uppercase block mb-1">Notes &amp; Details</label>
                <textarea
                  rows={2}
                  placeholder="Billing period, vendor invoice details..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 outline-none focus:bg-white focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-[11px] text-amber-900 font-medium">
                ✓ This expense will automatically be counted towards the company&apos;s profit and loss across any relevant period and overall.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>{editingExpense ? 'Update Expense' : 'Save Expense'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

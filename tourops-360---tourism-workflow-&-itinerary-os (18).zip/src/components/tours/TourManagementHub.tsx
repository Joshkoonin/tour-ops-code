import React, { useState, useMemo } from 'react';
import {
  Briefcase,
  Compass,
  DollarSign,
  TrendingUp,
  Receipt,
  Calendar,
  Users,
  MapPin,
  Building,
  CheckCircle2,
  Clock,
  AlertCircle,
  Plus,
  Printer,
  ExternalLink,
  ChevronDown,
  Filter,
  CreditCard,
  Trash2,
  User,
  Share2,
  FileText,
  ArrowRight,
  ShieldCheck,
  Percent,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  CurrencyCode,
  Itinerary,
  SupplierInvoice,
  SupplierInvoiceStatus,
  Invoice,
} from '../../types';
import { ProjectedTourCostsManager } from '../itinerary/ProjectedTourCostsManager';
import { CreateTourInvoiceModal } from '../invoicing/CreateTourInvoiceModal';
import { TourStatusSelector } from '../common/TourStatusSelector';
import { getTourContractRevenue } from '../../utils/financialCalculations';

export const TourManagementHub: React.FC = () => {
  const {
    itineraries,
    selectedTripId,
    setSelectedTripId,
    clients,
    suppliers,
    staff,
    invoices,
    supplierInvoices,
    expenses,
    addSupplierInvoice,
    markSupplierInvoicePaid,
    deleteSupplierInvoice,
    addInvoice,
    formatMoney,
    convertCurrency,
    openClientPortal,
    setActiveView,
    hasFullFinancialView,
    currentUser,
    firebaseUser,
  } = useApp();

  // Selected tour ID fallback
  const activeTourId = selectedTripId || itineraries[0]?.id || '';
  const currentTour = itineraries.find((t) => t.id === activeTourId) || itineraries[0];

  // Active tour client
  const client = clients.find((c) => c.id === currentTour?.clientId);
  const leadStaff = staff.find((s) => s.id === currentTour?.leadStaffId);

  // Filter supplier invoices belonging to this specific tour
  const tourSupplierInvoices = useMemo(() => {
    if (!currentTour) return [];
    return supplierInvoices.filter((inv) => inv.tripId === currentTour.id);
  }, [supplierInvoices, currentTour]);

  // Filter client invoices belonging to this specific tour
  const tourClientInvoices = useMemo(() => {
    if (!currentTour) return [];
    return invoices.filter((inv) => inv.tripId === currentTour.id);
  }, [invoices, currentTour]);

  // Filter project expenses belonging to this specific tour
  const tourExpenses = useMemo(() => {
    if (!currentTour) return [];
    return expenses.filter((e) => e.tripId === currentTour.id);
  }, [expenses, currentTour]);

  // Income calculations
  // Total client package price in tour currency and converted to USD
  const packagePriceUSD = currentTour
    ? convertCurrency(getTourContractRevenue(currentTour), currentTour.currency, 'USD')
    : 0;

  // Total invoiced across client invoices for this tour
  const totalInvoicedUSD = tourClientInvoices.reduce((sum, inv) => {
    const val = convertCurrency(inv.totalAmount, inv.currency, 'USD');
    return inv.isCreditNote ? sum - val : sum + val;
  }, 0);

  // Income actually received (cash collected) for this tour
  const totalIncomeReceivedUSD = tourClientInvoices.reduce((sum, inv) => {
    return sum + convertCurrency(inv.amountPaid, inv.currency, 'USD');
  }, 0);

  const totalClientBalanceDueUSD = Math.max(0, totalInvoicedUSD - totalIncomeReceivedUSD);

  // Supplier invoices costs for this tour (accounting for credits)
  const totalSupplierCostsUSD = tourSupplierInvoices.reduce((sum, inv) => {
    const val = convertCurrency(inv.amount, inv.currency, 'USD');
    return inv.isCredit ? sum - val : sum + val;
  }, 0);

  const totalSupplierPaidUSD = tourSupplierInvoices
    .filter((inv) => inv.status === 'Paid')
    .reduce((sum, inv) => {
      const val = convertCurrency(inv.amount, inv.currency, 'USD');
      return inv.isCredit ? sum - val : sum + val;
    }, 0);

  const totalSupplierOutstandingUSD = Math.max(0, totalSupplierCostsUSD - totalSupplierPaidUSD);

  // Direct project expenses
  const totalDirectExpensesUSD = tourExpenses.reduce((sum, exp) => {
    return sum + convertCurrency(exp.amount, exp.currency, 'USD');
  }, 0);

  // Total Direct Costs = Supplier Invoices + Direct Expenses
  const totalTourCostsUSD = totalSupplierCostsUSD + totalDirectExpensesUSD;

  // Running Profit & Loss Calculations
  // Effective revenue base (uses Total Invoiced if available, otherwise package price)
  const effectiveRevenueUSD = totalInvoicedUSD > 0 ? totalInvoicedUSD : packagePriceUSD;
  const runningGrossProfitUSD = effectiveRevenueUSD - totalTourCostsUSD;
  const runningGrossMarginPercent =
    effectiveRevenueUSD > 0 ? Math.round((runningGrossProfitUSD / effectiveRevenueUSD) * 1000) / 10 : 0;

  // Cash-basis running profit: Cash collected minus Cash paid out
  const cashBasisProfitUSD = totalIncomeReceivedUSD - (totalSupplierPaidUSD + totalDirectExpensesUSD);

  // Tab view inside the tour management hub
  const [activeTab, setActiveTab] = useState<'pnl' | 'supplier-invoices' | 'income' | 'all'>('pnl');

  // Modal State for adding supplier invoice directly to this tour
  const [isAddSupplierInvoiceOpen, setIsAddSupplierInvoiceOpen] = useState(false);
  const [supplierInvNum, setSupplierInvNum] = useState('');
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [supplierIssueDate, setSupplierIssueDate] = useState(new Date().toISOString().split('T')[0]);
  const [supplierDueDate, setSupplierDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [supplierAmount, setSupplierAmount] = useState<number>(1500);
  const [supplierCurrency, setSupplierCurrency] = useState<CurrencyCode>(currentTour?.currency || 'USD');
  const [supplierDesc, setSupplierDesc] = useState('');
  const [supplierStatus, setSupplierStatus] = useState<SupplierInvoiceStatus>('Pending Review');
  const [isSupplierCredit, setIsSupplierCredit] = useState(false);
  const [supplierNotes, setSupplierNotes] = useState('');

  // Tour Invoicing Modal State (Full or Part Payment & Balance)
  const [isCreateTourInvoiceOpen, setIsCreateTourInvoiceOpen] = useState(false);
  const [defaultTourInvoiceType, setDefaultTourInvoiceType] = useState<'full' | 'part' | 'balance'>('full');

  // Tour invoicing stats in tour's native currency
  const tourInvoicedInTourCurrency = useMemo(() => {
    if (!currentTour) return 0;
    return tourClientInvoices.reduce((sum, inv) => {
      const amt =
        inv.currency === currentTour.currency
          ? inv.totalAmount
          : convertCurrency(inv.totalAmount, inv.currency, currentTour.currency);
      return sum + (inv.isCreditNote ? -amt : amt);
    }, 0);
  }, [tourClientInvoices, currentTour, convertCurrency]);

  const uninvoicedTourBalance = Math.max(0, (currentTour?.totalClientPrice || 0) - tourInvoicedInTourCurrency);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleOpenAddSupplierInvoice = () => {
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const sup = suppliers[0];
    setSupplierInvNum(`INV-${sup ? sup.name.slice(0, 3).toUpperCase() : 'SUP'}-${randNum}`);
    setSupplierId(sup?.id || '');
    setSupplierIssueDate(new Date().toISOString().split('T')[0]);
    const d = new Date();
    d.setDate(d.getDate() + 14);
    setSupplierDueDate(d.toISOString().split('T')[0]);
    setSupplierAmount(1800);
    setSupplierCurrency(currentTour?.currency || 'USD');
    setSupplierDesc(`Operational tour service for ${currentTour?.tourName || currentTour?.title}`);
    setSupplierStatus('Pending Review');
    setIsSupplierCredit(false);
    setSupplierNotes('');
    setIsAddSupplierInvoiceOpen(true);
  };

  const handleSaveSupplierInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTour || !supplierInvNum.trim() || !supplierId) return;

    const newInvoice: SupplierInvoice = {
      id: `sinv-${Date.now()}`,
      invoiceNumber: supplierInvNum.trim(),
      supplierId,
      tripId: currentTour.id, // Explicitly tagged as belonging to this specific tour!
      issueDate: supplierIssueDate,
      dueDate: supplierDueDate,
      amount: Number(supplierAmount) || 0,
      currency: supplierCurrency,
      description: supplierDesc.trim(),
      status: supplierStatus,
      isCredit: isSupplierCredit,
      paymentReminderEnabled: true,
      notes: supplierNotes.trim() || undefined,
      createdByStaffId: currentUser?.id,
      createdByUid: firebaseUser?.uid,
      createdBy: currentUser?.name || firebaseUser?.displayName || 'Operations Team',
    };

    addSupplierInvoice(newInvoice, true);
    setIsAddSupplierInvoiceOpen(false);
    showToast(
      `Supplier invoice ${newInvoice.invoiceNumber} linked to "${currentTour.tourName || currentTour.title}". Displayed here and in the master Supplier Invoices list!`
    );
  };

  if (!currentTour) {
    return (
      <div className="p-8 max-w-7xl mx-auto text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-100 flex items-center justify-center text-amber-700">
          <Briefcase className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">No Tours Registered Yet</h2>
        <p className="text-sm text-slate-500">Create your first itinerary to open its tour management area.</p>
        <button
          onClick={() => setActiveView('itineraries')}
          className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
        >
          Go to Itineraries
        </button>
      </div>
    );
  }

  const tourDisplayName = currentTour.tourName || currentTour.title;

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 bg-slate-900 text-amber-300 border border-amber-500/30 rounded-2xl shadow-2xl flex items-center gap-3 animate-fade-in text-xs font-bold">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Breadcrumb & Tour Selector Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 flex items-center gap-1">
              <Briefcase className="w-3 h-3" />
              <span>Tour Operations Hub</span>
            </span>
            <span className="text-xs text-slate-500 font-medium font-mono">{currentTour.code}</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-1 flex items-center gap-2">
            <span>{tourDisplayName}</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Dedicated tour management workspace &bull; Running Profit &amp; Loss &bull; Supplier invoices &bull; Income received
          </p>
        </div>

        {/* Tour Switcher Dropdown & Action Buttons */}
        <div className="flex items-center flex-wrap gap-2.5">
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-2xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Switch Tour:</span>
            <select
              value={currentTour.id}
              onChange={(e) => setSelectedTripId(e.target.value)}
              className="text-xs font-bold text-slate-900 bg-transparent outline-none cursor-pointer"
            >
              {itineraries.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.code} - {t.tourName || t.title}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Print Running P&L Statement for this tour"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span>Print Tour P&amp;L</span>
          </button>

          <button
            onClick={() => {
              setSelectedTripId(currentTour.id);
              setActiveView('builder');
            }}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Open Itinerary Builder</span>
          </button>
        </div>
      </div>

      {/* Tour Meta Overview Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="space-y-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
              Tour Client &amp; Dossier
            </span>
            <div className="text-sm font-extrabold text-slate-900">{client?.name || 'Private VIP Client'}</div>
            <div className="text-xs text-slate-500">{client?.email || client?.phone || 'Direct Engagement'}</div>
            {client?.companyOrFamily && (
              <span className="inline-block mt-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                {client.companyOrFamily}
              </span>
            )}
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
              Dates &amp; Geography
            </span>
            <div className="flex items-center text-xs font-bold text-slate-900 gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-500" />
              <span>{currentTour.startDate} &rarr; {currentTour.endDate}</span>
            </div>
            <div className="flex items-center text-xs text-slate-600 gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span className="truncate">{currentTour.destination}</span>
            </div>
            <div className="text-[11px] text-slate-500">
              {currentTour.days.length} Days &bull; {currentTour.partySize} Guests
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
              Operations Crew
            </span>
            <div className="text-xs text-slate-800">
              <span className="font-bold">Guide:</span> {currentTour.guideName || 'Specialist Guide Assigned'}
            </div>
            <div className="text-xs text-slate-800">
              <span className="font-bold">Chauffeur:</span> {currentTour.driverName || 'Executive Transport Assigned'}
            </div>
            <div className="text-[11px] text-slate-500">
              <span className="font-semibold">Concierge:</span> {leadStaff?.name || 'Tour Director'}
            </div>
          </div>

          <div className="space-y-1.5 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block mb-1">
                Tour Lifecycle Status
              </span>
              <TourStatusSelector tour={currentTour} size="md" showQuickActions={true} />
            </div>
            <button
              onClick={() => openClientPortal(currentTour.id)}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Preview Live Client Portal</span>
            </button>
          </div>
        </div>
      </div>

      {/* If Tour is Proposed, show the Projected Tour Profit & Costs Manager for Full Financial View */}
      {hasFullFinancialView && currentTour.status === 'Proposed' && (
        <div className="space-y-4">
          <ProjectedTourCostsManager trip={currentTour} isOpenDefault={true} />
        </div>
      )}

      {/* Tour Financial Dashboard & Running Profit & Loss Highlight KPIs */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>Running Profit &amp; Loss (P&amp;L) for {tourDisplayName}</span>
          </h2>
          <span className="text-xs text-slate-500 font-medium">All figures calculated in live real-time</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Income Received vs Invoiced */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider">Income Received (Cash)</span>
              <DollarSign className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-black text-emerald-700">
              ${totalIncomeReceivedUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
            </div>
            <div className="mt-2 text-xs text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
              <span>Total Invoiced:</span>
              <span className="font-bold text-slate-900">
                ${(totalInvoicedUSD > 0 ? totalInvoicedUSD : packagePriceUSD).toLocaleString()}
              </span>
            </div>
            <div className="text-[11px] text-amber-700 font-semibold mt-0.5 flex items-center justify-between">
              <span>Balance Due from Client:</span>
              <span>${totalClientBalanceDueUSD.toLocaleString()}</span>
            </div>
          </div>

          {/* Card 2: Total Supplier Invoices & Direct Costs */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider">Total Tour Costs</span>
              <Receipt className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl font-black text-slate-900">
              ${totalTourCostsUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
            </div>
            <div className="mt-2 text-xs text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
              <span>Supplier Invoices ({tourSupplierInvoices.length}):</span>
              <span className="font-bold">${totalSupplierCostsUSD.toLocaleString()}</span>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center justify-between mt-0.5">
              <span>Direct Expenses ({tourExpenses.length}):</span>
              <span>${totalDirectExpensesUSD.toLocaleString()}</span>
            </div>
          </div>

          {/* Card 3: Running Gross Profit */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider">Running Gross Profit</span>
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div
              className={`text-2xl font-black ${
                runningGrossProfitUSD >= 0 ? 'text-emerald-700' : 'text-red-600'
              }`}
            >
              ${runningGrossProfitUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
            </div>
            <div className="mt-2 text-xs text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
              <span>Gross Margin:</span>
              <span
                className={`font-black ${
                  runningGrossMarginPercent >= 25 ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {runningGrossMarginPercent}%
              </span>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center justify-between mt-0.5">
              <span>Based on:</span>
              <span>Invoiced Revenue</span>
            </div>
          </div>

          {/* Card 4: Running Cash Position on Tour */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider">Running Cash Flow</span>
              <CreditCard className="w-4 h-4 text-blue-600" />
            </div>
            <div
              className={`text-2xl font-black ${
                cashBasisProfitUSD >= 0 ? 'text-blue-700' : 'text-amber-700'
              }`}
            >
              ${cashBasisProfitUSD.toLocaleString()} <span className="text-xs font-bold text-slate-500">USD</span>
            </div>
            <div className="mt-2 text-xs text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
              <span>Suppliers Paid Out:</span>
              <span className="font-bold">${totalSupplierPaidUSD.toLocaleString()}</span>
            </div>
            <div className="text-[11px] text-amber-700 font-semibold flex items-center justify-between mt-0.5">
              <span>Supplier Unpaid Bills:</span>
              <span>${totalSupplierOutstandingUSD.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs navigation for Tour Management Details */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('pnl')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all cursor-pointer ${
            activeTab === 'pnl'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Running P&amp;L Statement
        </button>
        <button
          onClick={() => setActiveTab('supplier-invoices')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'supplier-invoices'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Tour Supplier Invoices</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-100 text-slate-700">
            {tourSupplierInvoices.length}
          </span>
        </button>
        <button
          onClick={() => setActiveTab('income')}
          className={`pb-3 px-4 text-xs font-extrabold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'income'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Client Income &amp; Invoices</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-100 text-slate-700">
            {tourClientInvoices.length}
          </span>
        </button>
      </div>

      {/* TAB 1: Detailed Running P&L Statement */}
      {activeTab === 'pnl' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Running Profit &amp; Loss Statement &bull; {tourDisplayName}
              </h3>
              <p className="text-xs text-slate-500">
                Project Code: {currentTour.code} | Client: {client?.name || 'VIP Client'} | Dates: {currentTour.startDate} to {currentTour.endDate}
              </p>
            </div>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Statement</span>
            </button>
          </div>

          {/* Structured P&L Table */}
          <div className="space-y-4 text-xs font-medium">
            {/* 1. Operating Revenue */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 font-bold uppercase tracking-wider text-[11px] text-slate-700 flex justify-between">
                <span>1. Operating Tour Revenue (Invoiced to Client)</span>
                <span>Amount (USD)</span>
              </div>
              <div className="divide-y divide-slate-100">
                {tourClientInvoices.length > 0 ? (
                  tourClientInvoices.map((inv) => (
                    <div key={inv.id} className="px-4 py-2.5 flex justify-between items-center text-slate-700">
                      <div>
                        <span className="font-bold font-mono text-slate-900">{inv.invoiceNumber}</span>
                        {inv.isCreditNote && (
                          <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-red-100 text-red-700">
                            Credit Note
                          </span>
                        )}
                        <span className="text-slate-500 text-[11px] ml-2">Issued {inv.issueDate}</span>
                      </div>
                      <span className={`font-mono font-bold ${inv.isCreditNote ? 'text-red-600' : 'text-slate-900'}`}>
                        {inv.isCreditNote ? '-' : ''}${convertCurrency(inv.totalAmount, inv.currency, 'USD').toLocaleString()}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-2.5 flex justify-between items-center text-slate-700">
                    <div>
                      <span className="font-bold">Agreed Package Price (Contracted Value)</span>
                      <span className="text-slate-500 text-[11px] ml-2">({currentTour.totalClientPrice.toLocaleString()} {currentTour.currency})</span>
                    </div>
                    <span className="font-mono font-bold text-slate-900">
                      ${packagePriceUSD.toLocaleString()}
                    </span>
                  </div>
                )}
                <div className="px-4 py-2.5 bg-emerald-50/50 flex justify-between font-extrabold text-emerald-950">
                  <span>Total Tour Revenue</span>
                  <span className="font-mono text-sm">${effectiveRevenueUSD.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* 2. Direct Tour Supplier Costs */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 font-bold uppercase tracking-wider text-[11px] text-slate-700 flex justify-between">
                <span>2. Direct Tour Supplier Costs &amp; Vendor Bills</span>
                <span>Amount (USD)</span>
              </div>
              <div className="divide-y divide-slate-100">
                {tourSupplierInvoices.length > 0 ? (
                  tourSupplierInvoices.map((inv) => {
                    const sup = suppliers.find((s) => s.id === inv.supplierId);
                    const costUSD = convertCurrency(inv.amount, inv.currency, 'USD');
                    return (
                      <div key={inv.id} className="px-4 py-2.5 flex justify-between items-center text-slate-700">
                        <div>
                          <span className="font-bold font-mono text-slate-900">{inv.invoiceNumber}</span>
                          <span className="text-slate-800 font-semibold ml-2">{sup?.name || 'Supplier'}</span>
                          {inv.isCredit && (
                            <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-100 text-emerald-800">
                              Vendor Credit / Return
                            </span>
                          )}
                          <span className="text-slate-400 text-[10px] ml-2">({inv.status})</span>
                          <div className="text-[11px] text-slate-500">{inv.description}</div>
                        </div>
                        <span className={`font-mono font-bold ${inv.isCredit ? 'text-emerald-700' : 'text-slate-900'}`}>
                          {inv.isCredit ? '-' : ''}${costUSD.toLocaleString()}
                        </span>
                      </div>
                    );
                  })
                ) : (
                  <div className="px-4 py-3 text-slate-400 text-center italic">
                    No supplier invoices marked for this tour yet. Click "+ Add Supplier Invoice to this Tour" below.
                  </div>
                )}
                {tourExpenses.length > 0 &&
                  tourExpenses.map((exp) => (
                    <div key={exp.id} className="px-4 py-2.5 flex justify-between items-center text-slate-700">
                      <div>
                        <span className="font-bold">{exp.title}</span>
                        <span className="text-slate-500 text-[11px] ml-2">({exp.category})</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900">
                        ${convertCurrency(exp.amount, exp.currency, 'USD').toLocaleString()}
                      </span>
                    </div>
                  ))}
                <div className="px-4 py-2.5 bg-amber-50/50 flex justify-between font-extrabold text-amber-950">
                  <span>Total Direct Costs</span>
                  <span className="font-mono text-sm">${totalTourCostsUSD.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* 3. Net Gross Profit Summary */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Running Gross Profit on this Tour
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  Calculated as: Total Tour Revenue (${effectiveRevenueUSD.toLocaleString()}) minus Total Direct Costs (${totalTourCostsUSD.toLocaleString()})
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-black text-amber-300 font-mono">
                  ${runningGrossProfitUSD.toLocaleString()} USD
                </div>
                <div className="text-xs font-bold text-emerald-400">
                  Gross Margin: {runningGrossMarginPercent}%
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Specific Supplier Invoices for this Tour */}
      {activeTab === 'supplier-invoices' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-amber-600" />
                <span>Supplier Invoices Marked for {tourDisplayName}</span>
              </h3>
              <p className="text-xs text-slate-500">
                These invoices are specifically tracked here and are also visible in the overall master Supplier Invoices list.
              </p>
            </div>
            <button
              onClick={handleOpenAddSupplierInvoice}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Add Supplier Invoice to this Tour</span>
            </button>
          </div>

          {tourSupplierInvoices.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-100 flex items-center justify-center text-amber-700">
                <Receipt className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No Supplier Invoices Tagged to this Tour Yet</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                When you receive a bill from a guide, hotel, transfer company, or venue, add it here or mark it in the main Supplier Invoices hub to track your exact project costs.
              </p>
              <button
                onClick={handleOpenAddSupplierInvoice}
                className="px-4 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                + Add First Invoice for this Tour
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Invoice # &amp; Description</th>
                    <th className="px-4 py-3">Supplier</th>
                    <th className="px-4 py-3">Due Date</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tourSupplierInvoices.map((inv) => {
                    const sup = suppliers.find((s) => s.id === inv.supplierId);
                    const isPaid = inv.status === 'Paid';
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3.5">
                          <div className="font-extrabold text-slate-900 font-mono text-xs flex items-center gap-1.5">
                            <span>{inv.invoiceNumber}</span>
                            {inv.isCredit && (
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-100 text-emerald-800">
                                Credit Note
                              </span>
                            )}
                          </div>
                          <div className="text-slate-600 font-medium text-[11px] mt-0.5">
                            {inv.description}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Issued: {inv.issueDate}
                          </div>
                        </td>

                        <td className="px-4 py-3.5">
                          <div className="font-bold text-slate-900">{sup?.name || 'Vendor'}</div>
                          <div className="text-[10px] text-slate-400">{sup?.category}</div>
                        </td>

                        <td className="px-4 py-3.5 font-bold text-slate-800">
                          {inv.dueDate}
                        </td>

                        <td className="px-4 py-3.5">
                          <div className="font-black text-slate-900 text-sm">
                            {formatMoney(inv.amount, inv.currency)}
                          </div>
                          {inv.currency !== 'USD' && (
                            <div className="text-[10px] text-slate-400 font-semibold">
                              ≈ ${convertCurrency(inv.amount, inv.currency, 'USD').toLocaleString()} USD
                            </div>
                          )}
                        </td>

                        <td className="px-4 py-3.5">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider inline-block ${
                              inv.status === 'Paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : inv.status === 'Approved'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </td>

                        <td className="px-4 py-3.5 text-right space-x-1.5">
                          {!isPaid && (
                            <button
                              onClick={() => markSupplierInvoicePaid(inv.id, 'Bank Wire')}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] rounded-lg cursor-pointer"
                            >
                              Mark Paid
                            </button>
                          )}
                          <button
                            onClick={() => deleteSupplierInvoice(inv.id)}
                            className="p-1 text-slate-400 hover:text-red-600 rounded-lg cursor-pointer"
                            title="Delete Invoice"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Client Income & Invoices for this Tour */}
      {activeTab === 'income' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                <span>Income Received &amp; Client Invoices for {tourDisplayName}</span>
              </h3>
              <p className="text-xs text-slate-500">
                Track payments collected directly from the client against this tour.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setDefaultTourInvoiceType(tourClientInvoices.length > 0 && uninvoicedTourBalance > 0 ? 'balance' : 'full');
                  setIsCreateTourInvoiceOpen(true);
                }}
                className="px-3.5 py-2 bg-slate-950 hover:bg-slate-800 text-amber-400 font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400 stroke-[3]" />
                <span>+ Create Tour Invoice</span>
              </button>

              <button
                onClick={() => {
                  setActiveView('invoicing');
                }}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Client Invoicing Hub</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-2xl">
            <div>
              <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Agreed Package Price</span>
              <span className="text-lg font-black text-slate-900">
                ${packagePriceUSD.toLocaleString()} USD
              </span>
              <span className="text-[11px] text-slate-500 font-semibold block">
                ({formatMoney(currentTour.totalClientPrice, currentTour.currency)})
              </span>
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Income Received (Paid)</span>
              <span className="text-lg font-black text-emerald-700">
                ${totalIncomeReceivedUSD.toLocaleString()} USD
              </span>
              <span className="text-[11px] text-slate-500 font-semibold block">
                Across {tourClientInvoices.length} invoice(s)
              </span>
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Outstanding Unpaid</span>
              <span className="text-lg font-black text-amber-700">
                ${totalClientBalanceDueUSD.toLocaleString()} USD
              </span>
              {uninvoicedTourBalance > 0 && (
                <span className="text-[11px] text-emerald-700 font-bold block">
                  Un-invoiced: {formatMoney(uninvoicedTourBalance, currentTour.currency)}
                </span>
              )}
            </div>
          </div>

          {/* Part Payment Invoiced & Balance Ready Banner */}
          {tourClientInvoices.length > 0 && uninvoicedTourBalance > 0 && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2 text-emerald-950 font-black text-xs uppercase tracking-wider">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  <span>Part Payment Invoiced &bull; Balance Ready to Invoice</span>
                </div>
                <p className="text-xs text-slate-700">
                  Total Tour Price: <strong>{formatMoney(currentTour.totalClientPrice, currentTour.currency)}</strong> &bull; Already Invoiced: <strong>{formatMoney(tourInvoicedInTourCurrency, currentTour.currency)}</strong>.
                  Remaining tour balance to invoice: <strong className="text-emerald-800 font-mono text-sm">{formatMoney(uninvoicedTourBalance, currentTour.currency)}</strong>.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setDefaultTourInvoiceType('balance');
                  setIsCreateTourInvoiceOpen(true);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Generate Balance Invoice ({formatMoney(uninvoicedTourBalance, currentTour.currency)})</span>
              </button>
            </div>
          )}

          {tourClientInvoices.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-3">
              <Receipt className="w-10 h-10 text-slate-300 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-800">No client invoices issued yet for this tour</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Agreed Package Value: {formatMoney(currentTour.totalClientPrice, currentTour.currency)}. You can create an invoice for full payment or an initial deposit/part payment.
                </p>
              </div>
              <div className="flex justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setDefaultTourInvoiceType('full');
                    setIsCreateTourInvoiceOpen(true);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-amber-400 font-extrabold text-xs rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-400 stroke-[3]" />
                  <span>Create Tour Invoice (Full or Part Payment)</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Invoice #</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Issue Date</th>
                    <th className="px-4 py-3">Total Invoiced</th>
                    <th className="px-4 py-3">Amount Received</th>
                    <th className="px-4 py-3">Balance Due</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tourClientInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 font-mono font-extrabold text-slate-900">
                        {inv.invoiceNumber}
                        {inv.isCreditNote && (
                          <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-red-100 text-red-700">
                            Credit Note
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {inv.invoiceType === 'deposit' || inv.invoiceType === 'part' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-200">
                            Part Payment {inv.partPaymentPercentage ? `(${inv.partPaymentPercentage}%)` : ''}
                          </span>
                        ) : inv.invoiceType === 'balance' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-900 border border-emerald-200">
                            Balance Invoice
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-blue-100 text-blue-900 border border-blue-200">
                            Full Payment
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-600">{inv.issueDate}</td>
                      <td className="px-4 py-3 font-bold font-mono">
                        {formatMoney(inv.totalAmount, inv.currency)}
                      </td>
                      <td className="px-4 py-3 font-bold font-mono text-emerald-700">
                        {formatMoney(inv.amountPaid, inv.currency)}
                      </td>
                      <td className="px-4 py-3 font-bold font-mono text-amber-700">
                        {formatMoney(inv.balanceDue, inv.currency)}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inv.status === 'Partially Paid'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {(inv.invoiceType === 'deposit' || inv.invoiceType === 'part') && uninvoicedTourBalance > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setDefaultTourInvoiceType('balance');
                              setIsCreateTourInvoiceOpen(true);
                            }}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold rounded-lg text-[11px] transition-colors inline-flex items-center gap-1 cursor-pointer"
                            title="Generate balance invoice for this tour"
                          >
                            <Receipt className="w-3 h-3 text-emerald-600" />
                            <span>Invoice Balance</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modal: Add Supplier Invoice to this Tour */}
      {isAddSupplierInvoiceOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  + Add Supplier Invoice to Tour
                </h3>
                <p className="text-xs text-emerald-700 font-bold mt-0.5">
                  Locked to Tour: {tourDisplayName} ({currentTour.code})
                </p>
              </div>
              <button
                onClick={() => setIsAddSupplierInvoiceOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold p-1"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveSupplierInvoice} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Invoice # *</label>
                  <input
                    type="text"
                    required
                    value={supplierInvNum}
                    onChange={(e) => setSupplierInvNum(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Supplier / Vendor *</label>
                  <select
                    value={supplierId}
                    onChange={(e) => setSupplierId(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-medium"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Issue Date *</label>
                  <input
                    type="date"
                    required
                    value={supplierIssueDate}
                    onChange={(e) => setSupplierIssueDate(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Due Date *</label>
                  <input
                    type="date"
                    required
                    value={supplierDueDate}
                    onChange={(e) => setSupplierDueDate(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Amount *</label>
                  <input
                    type="number"
                    min={0}
                    step={10}
                    required
                    value={supplierAmount}
                    onChange={(e) => setSupplierAmount(Number(e.target.value))}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-black text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Currency *</label>
                  <select
                    value={supplierCurrency}
                    onChange={(e) => setSupplierCurrency(e.target.value as CurrencyCode)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-bold"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="ILS">ILS (₪)</option>
                    <option value="CHF">CHF (CHF)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 uppercase">Description / Services *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VIP Guiding services & luxury transfer fees"
                  value={supplierDesc}
                  onChange={(e) => setSupplierDesc(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase">Status</label>
                  <select
                    value={supplierStatus}
                    onChange={(e) => setSupplierStatus(e.target.value as SupplierInvoiceStatus)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl font-medium"
                  >
                    <option value="Pending Review">Pending Review</option>
                    <option value="Approved">Approved</option>
                    <option value="Paid">Paid</option>
                    <option value="Draft">Draft</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={isSupplierCredit}
                      onChange={(e) => setIsSupplierCredit(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600"
                    />
                    <span>Is Supplier Credit / Refund</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 uppercase">Internal Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Wired via bank confirmation #9921"
                  value={supplierNotes}
                  onChange={(e) => setSupplierNotes(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddSupplierInvoiceOpen(false)}
                  className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Save &amp; Link to Tour
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Tour Invoice Modal (Full, Part Payment, or Balance) */}
      {isCreateTourInvoiceOpen && currentTour && (
        <CreateTourInvoiceModal
          isOpen={isCreateTourInvoiceOpen}
          preselectedTripId={currentTour.id}
          defaultInvoiceType={defaultTourInvoiceType}
          onClose={() => setIsCreateTourInvoiceOpen(false)}
          onInvoiceCreated={(newInv) => {
            const typeLabel =
              newInv.invoiceType === 'deposit' || newInv.invoiceType === 'part'
                ? `Part Payment (${newInv.partPaymentPercentage}%)`
                : newInv.invoiceType === 'balance'
                ? 'Balance'
                : 'Full Payment';
            showToast(
              `Created ${typeLabel} Invoice #${newInv.invoiceNumber} for "${currentTour.tourName || currentTour.title}"!`
            );
          }}
        />
      )}
    </div>
  );
};

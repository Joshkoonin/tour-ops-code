import { Itinerary, ItineraryActivity, Expense, CurrencyCode } from '../types';

export function resolveSavedActivityCost(
  activity: ItineraryActivity,
  trip: Itinerary,
  expenses: Expense[],
  convertCurrency: (
    amount: number,
    from: CurrencyCode,
    to: CurrencyCode
  ) => number
): number | undefined {
  // If explicitly designated as No Cost, never look up legacy estimates or expenses
  if (activity.costBasis === 'noCost' || (activity.costBasis === undefined && activity.ourCost === 0 && (activity.costEstimate === 0 || activity.costEstimate === undefined))) {
    return 0;
  }

  if (activity.ourCost != null) return activity.ourCost;
  if (activity.costEstimate != null) return activity.costEstimate;

  const expense = activity.expenseId
    ? expenses.find(
        (e) =>
          e.id === activity.expenseId &&
          e.tripId === trip.id &&
          !e.isGeneralOverhead
      )
    : undefined;

  if (!expense) return undefined;

  return convertCurrency(
    expense.amount,
    expense.currency,
    activity.currency || trip.currency
  );
}

export function resolveActivityCostBasis(
  activity: ItineraryActivity
): 'global' | 'perPerson' | 'noCost' {
  if (activity.costBasis === 'noCost' || (activity.ourCost === 0 && activity.costBasis === undefined && (activity.costEstimate === 0 || activity.costEstimate === undefined))) {
    return 'noCost';
  }
  if (activity.costBasis === 'perPerson') {
    return 'perPerson';
  }
  return 'global';
}

import { CurrencyCode, HotelInfo, Itinerary, ItineraryActivity, SupplierInvoice, Expense } from '../types';

export interface PricingCalculationResult {
  guests: number;
  salePrice: number;
  fixedContribution: number;
  unitCost: number;
  costPerPerson: number;
  totalCost: number;
  revenue: number;
  profit: number;
  profitPerPerson: number;
  marginPercent: number | null;
}

/**
 * Shared pricing calculation function implementing the exact formula specification
 */
export function calculatePricing(
  fixedCost: number,
  unitCost: number,
  guests: number,
  salePrice: number
): PricingCalculationResult {
  if (!Number.isInteger(guests) || guests <= 0) {
    throw new Error('Enter a positive whole number of guests.');
  }
  if (![fixedCost, unitCost, salePrice].every((x) => Number.isFinite(x) && x >= 0)) {
    throw new Error('Enter valid nonnegative amounts.');
  }
  const fixedContribution = fixedCost / guests;
  const costPerPerson = fixedContribution + unitCost;
  const totalCost = fixedCost + unitCost * guests;
  const revenue = salePrice * guests;
  const profit = revenue - totalCost;
  return {
    guests,
    salePrice,
    fixedContribution,
    unitCost,
    costPerPerson,
    totalCost,
    revenue,
    profit,
    profitPerPerson: profit / guests,
    marginPercent: revenue === 0 ? null : (profit / revenue) * 100,
  };
}

/**
 * Rounds up to the currency's smallest unit (e.g. cents / 0.01 for USD, 1 for JPY)
 * to ensure break-even prices are never underquoted due to rounding down.
 */
export function roundUpToCurrency(amount: number, currency: CurrencyCode = 'USD'): number {
  if (!Number.isFinite(amount)) return 0;
  const decimals = currency === 'JPY' ? 0 : 2;
  const factor = Math.pow(10, decimals);
  return Math.ceil(amount * factor) / factor;
}

export interface CostBreakdownItem {
  id: string;
  title: string;
  category: string;
  amount: number;
  currency: CurrencyCode;
  dayNumber?: number;
  details?: string;
  isMissing?: boolean;
}

export interface CostWarning {
  id: string;
  message: string;
  severity: 'warning' | 'info';
}

export interface TourCostSummary {
  targetCurrency: CurrencyCode;
  globalActivityCosts: number;
  generalFixedCosts: number;
  totalFixedCost: number; // F
  perPersonActivityCosts: number;
  generalPerPersonCosts: number;
  hotelPerPersonCosts: number;
  totalPerPersonCost: number; // P
  fixedBreakdown: CostBreakdownItem[];
  unitBreakdown: CostBreakdownItem[];
  warnings: CostWarning[];
}

/**
 * Calculates base tour costs.
 */
function _calculateBaseCosts(
  itinerary: Itinerary,
  hotels: HotelInfo[] = [],
  convertCurrency: (amount: number, from: CurrencyCode, to: CurrencyCode) => number,
  currency: CurrencyCode
) {
  let globalActivityCosts = 0;
  let generalFixedCosts = 0;
  let perPersonActivityCosts = 0;
  let generalPerPersonCosts = 0;
  let hotelPerPersonCosts = 0;

  const fixedBreakdown: CostBreakdownItem[] = [];
  const unitBreakdown: CostBreakdownItem[] = [];
  const warnings: CostWarning[] = [];

  // 1. Activity Costs (F vs P)
  (itinerary.days || []).forEach((day) => {
    (day.activities || []).forEach((act) => {
      const basis = act.costBasis || 'global';
      if (basis === 'noCost' || (act.costBasis === undefined && act.ourCost === 0 && (act.costEstimate === 0 || act.costEstimate === undefined))) {
        return;
      }

      const rawAmount = act.ourCost ?? act.costEstimate;
      if (rawAmount === undefined || rawAmount === null) {
        warnings.push({
          id: `warn-act-missing-${act.id}`,
          message: `Day ${day.dayNumber}: "${act.title}" has no cost specified.`,
          severity: 'warning',
        });
        return;
      }

      const converted = convertCurrency(rawAmount, act.currency || itinerary.currency, currency);

      if (basis === 'perPerson') {
        perPersonActivityCosts += converted;
        unitBreakdown.push({
          id: act.id,
          title: act.title,
          category: act.category || 'Activity',
          amount: converted,
          currency,
          dayNumber: day.dayNumber,
          details: 'Per-person activity cost',
        });
      } else {
        globalActivityCosts += converted;
        fixedBreakdown.push({
          id: act.id,
          title: act.title,
          category: act.category || 'Activity',
          amount: converted,
          currency,
          dayNumber: day.dayNumber,
          details: 'Global group cost',
        });
      }
    });
  });

  // 2. General Projected Costs (F vs P)
  (itinerary.generalProjectedCosts || []).forEach((item) => {
    const rawCost = item.estimatedAmount ?? item.costEstimate ?? 0;
    const converted = convertCurrency(rawCost, item.currency || itinerary.currency, currency);

    if (item.costBasis === 'perPerson') {
      generalPerPersonCosts += converted;
      unitBreakdown.push({
        id: item.id,
        title: item.title,
        category: item.category || 'General Cost',
        amount: converted,
        currency,
        details: 'General cost (Per person basis)',
      });
    } else {
      generalFixedCosts += converted;
      fixedBreakdown.push({
        id: item.id,
        title: item.title,
        category: item.category || 'General Cost',
        amount: converted,
        currency,
        details: 'Whole-group fixed service (e.g. VIP Coach, Guide)',
      });
    }
  });

  // 3. Hotel Costs (P)
  (itinerary.days || []).forEach((day) => {
    if (day.costBasis && day.ourCost !== undefined) {
      const converted = convertCurrency(day.ourCost, itinerary.currency, currency);
      
      if (day.costBasis === 'global') {
        globalActivityCosts += converted;
        fixedBreakdown.push({
          id: `hotel-fixed-${day.id}`,
          title: `${day.hotelName || 'Hotel'} (Night ${day.dayNumber}) - Global`,
          category: 'Accommodations',
          amount: converted,
          currency,
          dayNumber: day.dayNumber,
          details: 'Global nightly hotel cost',
        });
      } else {
        hotelPerPersonCosts += converted;
        unitBreakdown.push({
          id: `hotel-unit-${day.id}`,
          title: `${day.hotelName || 'Hotel'} (Night ${day.dayNumber}) - Per Person`,
          category: 'Accommodations',
          amount: converted,
          currency,
          dayNumber: day.dayNumber,
          details: 'Per-person nightly hotel cost',
        });
      }
    } else if (day.hotelId) {
      warnings.push({
        id: `warn-hotel-missing-cost-${day.id}`,
        message: `Day ${day.dayNumber}: Hotel assigned to "${day.hotelName || day.hotelId}" but no explicit cost is confirmed.`,
        severity: 'warning',
      });
    }
  });

  return {
    globalActivityCosts,
    generalFixedCosts,
    perPersonActivityCosts,
    generalPerPersonCosts,
    hotelPerPersonCosts,
    fixedBreakdown,
    unitBreakdown,
    warnings,
  };
}

/**
 * Calculates F (Total Fixed / Global Tour Costs) and P (Total Per-Person Variable Costs)
 * including twin-sharing hotel stays and general projected items.
 */
export function calculateTourFixedAndUnitCosts(
  itinerary: Itinerary,
  hotels: HotelInfo[] = [],
  convertCurrency: (amount: number, from: CurrencyCode, to: CurrencyCode) => number,
  targetCurrency?: CurrencyCode
): TourCostSummary {
  const currency = targetCurrency || itinerary.currency || 'USD';
  const base = _calculateBaseCosts(itinerary, hotels, convertCurrency, currency);

  const P_total = base.perPersonActivityCosts + base.generalPerPersonCosts + base.hotelPerPersonCosts;
  const V = base.perPersonActivityCosts + base.generalPerPersonCosts; // Non-hotel variable costs
  const H = base.hotelPerPersonCosts;

  const freePlaces = calculateFreePlaceCosts(itinerary, V, H);
  const totalFixedCost = base.globalActivityCosts + base.generalFixedCosts + freePlaces.totalGlobalCost;
  const totalPerPersonCost = P_total;

  const fixedBreakdownWithFreePlaces = [
    ...base.fixedBreakdown,
    ...(freePlaces.totalGlobalCost > 0 ? [{
      id: 'free-places-allowance',
      title: 'Partner Free Places Allowance',
      category: 'General Logistics',
      amount: freePlaces.totalGlobalCost,
      currency,
      details: `Includes ${freePlaces.freePlacesCount} places`,
    }] : [])
  ];

  return {
    targetCurrency: currency,
    globalActivityCosts: base.globalActivityCosts,
    generalFixedCosts: base.generalFixedCosts,
    totalFixedCost,
    perPersonActivityCosts: base.perPersonActivityCosts,
    generalPerPersonCosts: base.generalPerPersonCosts,
    hotelPerPersonCosts: base.hotelPerPersonCosts,
    totalPerPersonCost,
    fixedBreakdown: fixedBreakdownWithFreePlaces,
    unitBreakdown: base.unitBreakdown,
    warnings: base.warnings,
  };
}

/**
 * Calculates total tour contract revenue based on pricing mode.
 */
export function getTourContractRevenue(itinerary: Itinerary): number {
  const price = itinerary.totalClientPrice ?? 0;
  
  if (!Number.isFinite(price) || price < 0) return 0;
  
  if (itinerary.pricingMode === 'perPerson') {
    const partySize = itinerary.partySize;
    if (typeof partySize !== 'number' || !Number.isFinite(partySize) || partySize < 0) {
      return 0;
    }
    return price * partySize;
  }
  
  return price;
}

export interface SimulationResult {
  totalRevenue: number;
  totalCost: number;
  profit: number;
  margin: number;
}

export const calculateScenario = (
  itinerary: Itinerary,
  guestCount: number,
  hotels: HotelInfo[] = [],
  convertCurrency: (amount: number, from: CurrencyCode, to: CurrencyCode) => number = (amt) => amt
): SimulationResult => {
  if (guestCount <= 0) {
    return { totalRevenue: 0, totalCost: 0, profit: 0, margin: 0 };
  }

  const { totalFixedCost, totalPerPersonCost } = calculateTourFixedAndUnitCosts(
    itinerary,
    hotels,
    convertCurrency,
    itinerary.currency
  );

  let salePricePerPerson = itinerary.partySize > 0 ? itinerary.totalClientPrice / itinerary.partySize : itinerary.totalClientPrice;

  if (itinerary.pricingBands && itinerary.pricingBands.length > 0) {
    const band = itinerary.pricingBands.find(
      (b) => guestCount >= b.minGuests && (!b.maxGuests || guestCount <= b.maxGuests)
    );
    if (band) {
      salePricePerPerson = band.pricePerGuest;
    }
  }

  const result = calculatePricing(totalFixedCost, totalPerPersonCost, guestCount, salePricePerPerson);

  return {
    totalRevenue: result.revenue,
    totalCost: result.totalCost,
    profit: result.profit,
    margin: result.marginPercent ?? 0,
  };
};

/**
 * Calculates the cost for free places based on P (non-hotel per-person costs)
 * and H (per-person hotel costs).
 * 
 * Cost per free place = P + (2 × H)
 * Total global free-place cost = N × [P + (2 × H)]
 */
export function calculateFreePlaceCosts(
  itinerary: Itinerary,
  V: number,
  H: number
): { costPerFreePlace: number; totalGlobalCost: number; freePlacesCount: number } {
  const freePlacesCount = itinerary.freePlaces?.count || 0;
  
  const costPerFreePlace = V + (2 * H);
  const totalGlobalCost = freePlacesCount * costPerFreePlace;

  return {
    costPerFreePlace,
    totalGlobalCost,
    freePlacesCount
  };
}

/**
 * Checks if a tour is eligible for profit reporting based on its status.
 */
export function isTourEligibleForProfitReporting(tour: Itinerary): boolean {
  return [
    'Confirmed',
    'In Progress',
    'completed but not cost reconciled',
    'completed and reconciled',
  ].includes(tour.status);
}

/**
 * Calculates management direct costs for a tour, combining projected and actual costs with deduplication.
 */
export function calculateManagementDirectCostsForTour(
  itinerary: Itinerary,
  invoices: SupplierInvoice[],
  expenses: Expense[],
  convertCurrency: (amount: number, from: CurrencyCode, to: CurrencyCode) => number,
  currency: CurrencyCode
): number {
  const projected = calculateTourFixedAndUnitCosts(itinerary, [], convertCurrency, currency);
  const partySize = itinerary.partySize || 1;

  const tourSupInvoices = invoices.filter(i => i.tripId === itinerary.id && !i.isGeneralOverhead);
  const tourExp = expenses.filter(e => e.tripId === itinerary.id && !e.isGeneralOverhead);
  
  const linkedInvoiceIds = tourSupInvoices.filter(i => i.linkedCostId).map(i => i.linkedCostId);
  const linkedExpenseIds = tourExp.filter(e => e.linkedCostId).map(e => e.linkedCostId);
  const allLinkedIds = [...linkedInvoiceIds, ...linkedExpenseIds];
  
  // Costs are: (Projected items not replaced) + (Actual linked items) + (Actual unlinked extra expenses)
  
  // 1. Projected items not replaced
  const unlinkedFixedCosts = projected.fixedBreakdown
    .filter(item => !allLinkedIds.includes(item.id))
    .reduce((sum, item) => sum + item.amount, 0);
    
  const unlinkedUnitCosts = projected.unitBreakdown
    .filter(item => !allLinkedIds.includes(item.id))
    .reduce((sum, item) => sum + item.amount, 0);
    
  const projectedSum = unlinkedFixedCosts + (unlinkedUnitCosts * partySize);
  
  // 2. Actual linked items
  const actualLinkedUSD = [...tourSupInvoices, ...tourExp]
    .filter(item => item.linkedCostId && allLinkedIds.includes(item.linkedCostId))
    .reduce((sum, item) => {
      const amount = ('amount' in item) ? item.amount : 0;
      const cur = ('currency' in item) ? item.currency : currency;
      return sum + convertCurrency(amount, cur, currency);
    }, 0);
    
  // 3. Actual unlinked extra expenses (if they don't have a linkedCostId but are trip-linked)
  const actualUnlinkedExtraUSD = [...tourSupInvoices, ...tourExp]
    .filter(item => !item.linkedCostId)
    .reduce((sum, item) => {
      const amount = ('amount' in item) ? item.amount : 0;
      const cur = ('currency' in item) ? item.currency : currency;
      return sum + convertCurrency(amount, cur, currency);
    }, 0);
    
  return projectedSum + actualLinkedUSD + actualUnlinkedExtraUSD;
}

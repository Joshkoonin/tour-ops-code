/**
 * Utility functions for client-side image uploading, resizing, and compression.
 * Ensures uploaded photos stay well within Firestore's 1MB document limit
 * while maintaining high visual fidelity for hero tour photography.
 */

export interface TravelPhotoPreset {
  id: string;
  title: string;
  destination: string;
  url: string;
}

export const TRAVEL_HERO_PRESETS: TravelPhotoPreset[] = [
  {
    id: 'jerusalem-old-city',
    title: 'Jerusalem Golden Vista',
    destination: 'Jerusalem & Levant',
    url: 'https://images.unsplash.com/photo-1544971587-b842c27f8e14?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dead-sea-sunset',
    title: 'Dead Sea Minerals & Sunset',
    destination: 'Dead Sea & Judean Desert',
    url: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'tel-aviv-coast',
    title: 'Tel Aviv Mediterranean Promenade',
    destination: 'Tel Aviv & Coastline',
    url: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'petra-treasury',
    title: 'Petra Treasury & Canyons',
    destination: 'Petra & Southern Jordan',
    url: 'https://images.unsplash.com/photo-1579606032822-261907e5b12a?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'galilee-hills',
    title: 'Sea of Galilee & Rolling Green Hills',
    destination: 'Galilee & Golan Heights',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'alps-peaks',
    title: 'Alpine Panoramic Vista',
    destination: 'Swiss Alps & Europe',
    url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'amalfi-coast',
    title: 'Amalfi Cliffside Luxury',
    destination: 'Italian Riviera & Mediterranean',
    url: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'desert-wadi-rum',
    title: 'Wadi Rum Desert Dunes',
    destination: 'Desert Safari & Bedouin Camp',
    url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=1600&auto=format&fit=crop&q=80',
  },
];

/**
 * Reads a user-selected File, resizes it using HTML5 Canvas to a maximum dimension
 * (default 1600px width), and compresses to a high-quality JPEG Data URL.
 * Produces crisp hero photos typically around 80KB - 250KB, ensuring smooth performance
 * and preventing Firestore document quota overflow.
 */
export async function compressAndReadImageFile(
  file: File,
  maxWidth = 1600,
  maxHeight = 1000,
  quality = 0.85
): Promise<string> {
  return new Promise((resolve, reject) => {
    // If not an image, reject
    if (!file.type.startsWith('image/')) {
      return reject(new Error('Please select a valid image file (JPG, PNG, WebP, etc.).'));
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read file from disk.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Failed to parse uploaded image.'));
      img.onload = () => {
        try {
          let { width, height } = img;

          // Calculate aspect-ratio scaling
          if (width > maxWidth || height > maxHeight) {
            const widthRatio = maxWidth / width;
            const heightRatio = maxHeight / height;
            const scale = Math.min(widthRatio, heightRatio);
            width = Math.round(width * scale);
            height = Math.round(height * scale);
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            // Fallback to raw data url if 2D context fails
            return resolve(reader.result as string);
          }

          // Enable high-quality smoothing
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);

          // Use jpeg compression for photos
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        } catch (err) {
          // If canvas tainted or error occurs, fall back to original reader result
          resolve(reader.result as string);
        }
      };

      img.src = reader.result as string;
    };

    reader.readAsDataURL(file);
  });
}

export const compressImageToWebBanner = compressAndReadImageFile;

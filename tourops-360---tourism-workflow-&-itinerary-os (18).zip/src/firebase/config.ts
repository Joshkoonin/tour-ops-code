import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getAnalytics, isSupported } from 'firebase/analytics';
import rawFirebaseConfig from '../../firebase-applet-config.json';

// Web app's Firebase configuration pointing to the new project "tour-flowpro-ipcs"
// Supports both firebase-applet-config.json and optional Vite environment variables
export const firebaseConfig = {
  apiKey: import.meta.env?.VITE_FIREBASE_API_KEY || rawFirebaseConfig.apiKey || "AIzaSyA6Ff098R2aMdXDf5mkHLZhaSLahSwpK1Y",
  authDomain: import.meta.env?.VITE_FIREBASE_AUTH_DOMAIN || rawFirebaseConfig.authDomain || "tour-flowpro-ipcs.firebaseapp.com",
  projectId: "tour-flowpro-ipcs",
  storageBucket: import.meta.env?.VITE_FIREBASE_STORAGE_BUCKET || rawFirebaseConfig.storageBucket || "tour-flowpro-ipcs.firebasestorage.app",
  messagingSenderId: import.meta.env?.VITE_FIREBASE_MESSAGING_SENDER_ID || rawFirebaseConfig.messagingSenderId || "956682084907",
  appId: import.meta.env?.VITE_FIREBASE_APP_ID || rawFirebaseConfig.appId || "1:956682084907:web:af9709535e489f99ab006e",
  measurementId: import.meta.env?.VITE_FIREBASE_MEASUREMENT_ID || rawFirebaseConfig.measurementId || "",
  firestoreDatabaseId: "(default)",
};

// Initialize Firebase App instance
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Verify that app.options.projectId is tour-flowpro-ipcs; stop with a clear error otherwise
const activeProjectId = app.options.projectId;
if (activeProjectId !== 'tour-flowpro-ipcs') {
  const errMsg = `[TourOps 360 Fatal Error] Invalid Firebase project ID: "${activeProjectId}". Expected "tour-flowpro-ipcs". Halting initialization.`;
  console.error(errMsg);
  throw new Error(errMsg);
}

// Initialize Analytics if supported in current environment and measurementId is present
export let analytics: any = null;
if (typeof window !== 'undefined' && firebaseConfig.measurementId) {
  isSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  }).catch(() => {});
}

// Explicitly initialise Firestore with getFirestore(app, '(default)'), independently of the generated database ID
export const db = getFirestore(app, '(default)');

// Log the actual project and database used
console.log(`[TourOps 360] Active Firebase Project: "${activeProjectId}", Firestore Database: "(default)"`);
console.log('Initializing Firestore with database ID: (default)');

// Authentication service instance
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Helper to determine if live credentials have replaced the placeholders
export function isFirebaseConfigured(): boolean {
  const key = firebaseConfig.apiKey || '';
  const appId = firebaseConfig.appId || '';
  return Boolean(
    key &&
    !key.includes('PASTE_YOUR_') &&
    !key.includes('[') &&
    appId &&
    !appId.includes('PASTE_YOUR_') &&
    !appId.includes('[')
  );
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<boolean> {
  if (!isFirebaseConfigured()) {
    console.info(
      '[TourOps 360] Pointing cleanly to Firebase project "tour-flowpro-ipcs". (Awaiting active API Key / App ID).'
    );
    return false;
  }
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && (error.message.includes('the client is offline') || error.message.includes('unavailable'))) {
      console.info(
        '[TourOps 360] Cloud Firestore for project "tour-flowpro-ipcs" is currently offline. Running in offline workflow mode.'
      );
      return false;
    }
    // Any other response (e.g. document does not exist, or security rules evaluation) indicates Firestore server connectivity
    console.info('[TourOps 360] Connection verified:', error instanceof Error ? error.message : error);
    return true;
  }
}

export { signInWithPopup, signOut };

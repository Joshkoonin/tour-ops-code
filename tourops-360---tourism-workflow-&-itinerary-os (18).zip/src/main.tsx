import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Immediate purge of obsolete PWA caches to prevent stale bundle lock-in
if (typeof window !== 'undefined' && 'caches' in window) {
  caches.keys().then((keys) => {
    for (const key of keys) {
      if (key !== 'tourops360-cache-v2') {
        caches.delete(key);
      }
    }
  }).catch(() => {});
}

// Register service worker for installable PWA experience and ensure updates are checked
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        console.log('[TourOps 360 PWA] Service worker registered:', reg.scope);
        reg.update();
      })
      .catch((err) => {
        console.warn('[TourOps 360 PWA] Service worker registration ignored:', err);
      });
  });
}

createRoot(document.getElementById('root')!).render(<App />);
